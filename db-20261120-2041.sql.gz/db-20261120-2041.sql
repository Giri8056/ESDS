-- MySQL dump 10.13  Distrib 8.4.13, for Linux (x86_64)
--
-- Host: localhost    Database: espocrm
-- ------------------------------------------------------
-- Server version	8.4.13

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `account`
--

DROP TABLE IF EXISTS `account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `account` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(249) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `website` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `industry` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sic_code` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `billing_address_street` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `billing_address_city` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `billing_address_state` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `billing_address_country` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `billing_address_postal_code` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipping_address_street` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipping_address_city` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipping_address_state` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipping_address_country` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipping_address_postal_code` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `is_locked` tinyint NOT NULL DEFAULT '0',
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `stream_updated_at` datetime DEFAULT NULL,
  `campaign_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `assigned_user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `version_number` bigint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_CREATED_AT_ID` (`created_at`,`id`),
  KEY `IDX_CREATED_AT` (`created_at`,`deleted`),
  KEY `IDX_NAME` (`name`,`deleted`),
  KEY `IDX_ASSIGNED_USER` (`assigned_user_id`,`deleted`),
  KEY `IDX_CAMPAIGN_ID` (`campaign_id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`),
  KEY `IDX_ASSIGNED_USER_ID` (`assigned_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account`
--

LOCK TABLES `account` WRITE;
/*!40000 ALTER TABLE `account` DISABLE KEYS */;
INSERT INTO `account` VALUES ('4a097347c0ebd6aff','CineMax',0,'www.cinemaxx.com','Customer','Entertainment & Leisure',NULL,'chennai','Chennai','TN','India','600122',NULL,NULL,NULL,NULL,NULL,'Cinemax is the SuperMall',0,'2026-11-20 20:16:23','2026-11-20 20:16:23','2026-11-20 20:16:23',NULL,'8975be1e209554aaf',NULL,NULL,1),('f3041c7f637e8df79','BizTest Co',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2026-11-20 20:35:26','2026-11-20 20:35:49','2026-11-20 20:35:29',NULL,'8975be1e209554aaf','8975be1e209554aaf',NULL,1),('fad196603b025835e','Acme Corp',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2026-11-20 11:53:11','2026-11-20 11:53:11','2026-11-20 19:51:08',NULL,'8975be1e209554aaf',NULL,NULL,1);
/*!40000 ALTER TABLE `account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `account_contact`
--

DROP TABLE IF EXISTS `account_contact`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `account_contact` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `account_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_inactive` tinyint DEFAULT '0',
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_ACCOUNT_ID_CONTACT_ID` (`account_id`,`contact_id`),
  KEY `IDX_ACCOUNT_ID` (`account_id`),
  KEY `IDX_CONTACT_ID` (`contact_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account_contact`
--

LOCK TABLES `account_contact` WRITE;
/*!40000 ALTER TABLE `account_contact` DISABLE KEYS */;
INSERT INTO `account_contact` VALUES (1,'4a097347c0ebd6aff','8795e37e5d45d44a3','cinemax',0,0);
/*!40000 ALTER TABLE `account_contact` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `account_document`
--

DROP TABLE IF EXISTS `account_document`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `account_document` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `account_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `document_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_ACCOUNT_ID_DOCUMENT_ID` (`account_id`,`document_id`),
  KEY `IDX_ACCOUNT_ID` (`account_id`),
  KEY `IDX_DOCUMENT_ID` (`document_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account_document`
--

LOCK TABLES `account_document` WRITE;
/*!40000 ALTER TABLE `account_document` DISABLE KEYS */;
/*!40000 ALTER TABLE `account_document` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `account_portal_user`
--

DROP TABLE IF EXISTS `account_portal_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `account_portal_user` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `account_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_USER_ID_ACCOUNT_ID` (`user_id`,`account_id`),
  KEY `IDX_USER_ID` (`user_id`),
  KEY `IDX_ACCOUNT_ID` (`account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account_portal_user`
--

LOCK TABLES `account_portal_user` WRITE;
/*!40000 ALTER TABLE `account_portal_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `account_portal_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `account_target_list`
--

DROP TABLE IF EXISTS `account_target_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `account_target_list` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `account_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_list_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `opted_out` tinyint DEFAULT '0',
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_ACCOUNT_ID_TARGET_LIST_ID` (`account_id`,`target_list_id`),
  KEY `IDX_ACCOUNT_ID` (`account_id`),
  KEY `IDX_TARGET_LIST_ID` (`target_list_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account_target_list`
--

LOCK TABLES `account_target_list` WRITE;
/*!40000 ALTER TABLE `account_target_list` DISABLE KEYS */;
/*!40000 ALTER TABLE `account_target_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `action_history_record`
--

DROP TABLE IF EXISTS `action_history_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `action_history_record` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint DEFAULT '0',
  `number` bigint unsigned NOT NULL AUTO_INCREMENT,
  `target_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `action` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `ip_address` varchar(39) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `auth_token_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `auth_log_record_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_NUMBER` (`number`),
  KEY `IDX_TARGET` (`target_type`,`target_id`),
  KEY `IDX_USER_ID` (`user_id`),
  KEY `IDX_AUTH_TOKEN_ID` (`auth_token_id`),
  KEY `IDX_AUTH_LOG_RECORD_ID` (`auth_log_record_id`)
) ENGINE=InnoDB AUTO_INCREMENT=145 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `action_history_record`
--

LOCK TABLES `action_history_record` WRITE;
/*!40000 ALTER TABLE `action_history_record` DISABLE KEYS */;
INSERT INTO `action_history_record` VALUES ('0442aab10512f5982',0,49,'CAttendance',NULL,'create','2026-11-20 12:55:42','100.64.0.3','5155e3286aeb73c25','8975be1e209554aaf','358da851518a0b673','bfb616935928b0eed'),('04e4016a107ea8c25',0,118,'Lead',NULL,'update','2026-11-20 20:28:30','100.64.0.10','064cbaa61185d2fb2','8975be1e209554aaf','358da851518a0b673','bfb616935928b0eed'),('0d9ccf10d9034bff0',0,104,'Opportunity',NULL,'read','2026-11-20 20:10:38','100.64.0.8','27b31c65ef0c038b5','8975be1e209554aaf','358da851518a0b673','bfb616935928b0eed'),('0e2e2af620318382a',0,81,'User',NULL,'read','2026-11-20 19:34:14','100.64.0.9','3a9d2245f7f443cd5','8975be1e209554aaf','358da851518a0b673','bfb616935928b0eed'),('1090be241eb47e0d9',0,61,'User',NULL,'read','2026-11-20 19:17:59','100.64.0.6','3a9d2245f7f443cd5','8975be1e209554aaf','358da851518a0b673','bfb616935928b0eed'),('1153f2a422ae3b449',0,90,'User',NULL,'read','2026-11-20 19:43:40','100.64.0.6','3a9d2245f7f443cd5','3a9d2245f7f443cd5','0d41473af61914185','c4df400812bcca492'),('13beeb92248692c14',0,89,'User',NULL,'read','2026-11-20 19:43:13','100.64.0.8','3a9d2245f7f443cd5','3a9d2245f7f443cd5','0d41473af61914185','c4df400812bcca492'),('14eaff153125ea37c',0,71,'Role',NULL,'read','2026-11-20 19:27:45','100.64.0.8','76786855438bb890a','8975be1e209554aaf','358da851518a0b673','bfb616935928b0eed'),('150b76801a29c3981',0,54,'Team',NULL,'read','2026-11-20 19:07:50','100.64.0.7','d7b229038af2056a8','8975be1e209554aaf','358da851518a0b673','bfb616935928b0eed'),('19ca762c1b9f748fd',0,85,'CJob',NULL,'read','2026-11-20 19:36:57','100.64.0.6','26a23642611410415','8975be1e209554aaf','358da851518a0b673','bfb616935928b0eed'),('1a0c2ec4565f35363',0,95,'CJob',NULL,'create','2026-11-20 19:51:08','100.64.0.6','1beaa2ed6d39769fc','8975be1e209554aaf','358da851518a0b673','bfb616935928b0eed'),('1acd84085acb22613',0,43,'CAttendance',NULL,'update','2026-11-20 12:52:58','100.64.0.6','cc6593c4a6bf438fe','8975be1e209554aaf','358da851518a0b673','bfb616935928b0eed'),('1cd71a2723c38005f',0,53,'Team',NULL,'create','2026-11-20 19:07:49','100.64.0.3','d7b229038af2056a8','8975be1e209554aaf','358da851518a0b673','bfb616935928b0eed'),('1dcac4727251d9a2e',0,9,'CAttendance',NULL,'create','2026-11-20 12:02:13','100.64.0.4','66e3ae57755bf451c','8975be1e209554aaf','d2b25d505a04d515c','0e3e392bb709b421c'),('2342f3e75e7d114ee',0,35,'CAttendance',NULL,'read','2026-11-20 12:41:24','100.64.0.3','3d1bcfdd0d782c3e7','8975be1e209554aaf','358da851518a0b673','bfb616935928b0eed'),('2ba9d3fb76364d47b',0,65,'User',NULL,'read','2026-11-20 19:20:07','100.64.0.4','fc6e11cea4752c54f','8975be1e209554aaf','358da851518a0b673','bfb616935928b0eed'),('2da3bde39f9acde69',0,111,'Opportunity',NULL,'create','2026-11-20 20:16:23','100.64.0.7','7c97eb7ee580bd504','8975be1e209554aaf','358da851518a0b673','bfb616935928b0eed'),('2da9e98a78b9f215e',0,144,'Account',NULL,'delete','2026-11-20 20:35:49','172.18.0.1','f3041c7f637e8df79','8975be1e209554aaf',NULL,'da2f8b19ef958701b'),('2e01378588684818d',0,60,'User',NULL,'read','2026-11-20 19:17:52','100.64.0.13','fc6e11cea4752c54f','8975be1e209554aaf','358da851518a0b673','bfb616935928b0eed'),('2fb9c352540353da0',0,24,'CAttendance',NULL,'update','2026-11-20 12:28:57','172.18.0.1','66e3ae57755bf451c','8975be1e209554aaf',NULL,'99398762935b77c76'),('2fe5097fe2eab27dc',0,20,'CWorkOrder',NULL,'create','2026-11-20 12:16:43','172.18.0.1','6582eaf57ed8dac2c','8975be1e209554aaf',NULL,'e72e6141df9f67790'),('313f8077db4cc2cf6',0,86,'DashboardTemplate',NULL,'create','2026-11-20 19:40:24','100.64.0.2','5b0224715472ad4e8','8975be1e209554aaf','358da851518a0b673','bfb616935928b0eed'),('316e8a1541d66df02',0,59,'User',NULL,'create','2026-11-20 19:17:51','100.64.0.13','fc6e11cea4752c54f','8975be1e209554aaf','358da851518a0b673','bfb616935928b0eed'),('3387c802b5b96f670',0,79,'Team',NULL,'update','2026-11-20 19:33:55','100.64.0.11','d7b229038af2056a8','8975be1e209554aaf','358da851518a0b673','bfb616935928b0eed'),('3488e55257db2c8b5',0,52,'WorkingTimeCalendar',NULL,'create','2026-11-20 19:07:38','100.64.0.11','0e7b49eaf73de54e3','8975be1e209554aaf','358da851518a0b673','bfb616935928b0eed'),('34d3b5262d47a16a4',0,67,'User',NULL,'update','2026-11-20 19:20:17','100.64.0.5','fc6e11cea4752c54f','8975be1e209554aaf','358da851518a0b673','bfb616935928b0eed'),('37d5c23845cc78bd4',0,44,'CJob',NULL,'create','2026-11-20 12:54:30','100.64.0.7','bee574c7672667f9a','8975be1e209554aaf','358da851518a0b673','bfb616935928b0eed'),('37eca2852e1ba9e7f',0,131,'CInvoice',NULL,'read','2026-11-20 20:35:30','172.18.0.1','d393fc43249460ea6','8975be1e209554aaf',NULL,'e46294d4578ff482e'),('37f951298c00eb048',0,100,'Opportunity',NULL,'create','2026-11-20 20:09:58','100.64.0.7','27b31c65ef0c038b5','8975be1e209554aaf','358da851518a0b673','bfb616935928b0eed'),('38171fb871d893163',0,40,'CAttendance',NULL,'create','2026-11-20 12:52:22','100.64.0.24','5062dab9aa60940ed','8975be1e209554aaf','36e84f0576c673650','15fb0f073e4103a57'),('38bcdbe8bffeb9b1b',0,1,'Account',NULL,'create','2026-11-20 11:53:11','172.18.0.1','fad196603b025835e','8975be1e209554aaf',NULL,'6fc41ae6feeab5f57'),('3920982a5feb9f7ba',0,47,'CJob',NULL,'read','2026-11-20 12:55:29','100.64.0.1','bee574c7672667f9a','8975be1e209554aaf','358da851518a0b673','bfb616935928b0eed'),('3c070920abab4e45f',0,92,'CJob',NULL,'read','2026-11-20 19:44:59','100.64.0.2','26a23642611410415','3a9d2245f7f443cd5','0d41473af61914185','c4df400812bcca492'),('4094c3265b0d876b1',0,22,'CAMC',NULL,'read','2026-11-20 12:18:39','100.64.0.11','d766f3eec4a784423','8975be1e209554aaf','358da851518a0b673','bfb616935928b0eed'),('42e56ddb00ad03601',0,91,'CAMC',NULL,'read','2026-11-20 19:44:55','100.64.0.5','d766f3eec4a784423','3a9d2245f7f443cd5','0d41473af61914185','c4df400812bcca492'),('4878983577dec4fd0',0,107,'Lead',NULL,'read','2026-11-20 20:15:13','100.64.0.9','064cbaa61185d2fb2','8975be1e209554aaf','358da851518a0b673','bfb616935928b0eed'),('4962db1f4c064010a',0,33,'CAttendance',NULL,'read','2026-11-20 12:40:56','100.64.0.5','bac44286bee36cd47','8975be1e209554aaf','358da851518a0b673','bfb616935928b0eed'),('4b383dec129801b69',0,105,'Lead',NULL,'create','2026-11-20 20:14:53','100.64.0.10','064cbaa61185d2fb2','8975be1e209554aaf','358da851518a0b673','bfb616935928b0eed'),('4ed5c204fbff87fec',0,114,'CAttendance',NULL,'create','2026-11-20 20:25:43','100.64.0.10','82fe88e78a9f0023e','3a9d2245f7f443cd5','0d41473af61914185','c4df400812bcca492'),('505774582fbeac003',0,87,'DashboardTemplate',NULL,'read','2026-11-20 19:40:24','100.64.0.5','5b0224715472ad4e8','8975be1e209554aaf','358da851518a0b673','bfb616935928b0eed'),('506a9ae5838ad22cc',0,45,'CJob',NULL,'read','2026-11-20 12:54:30','100.64.0.6','bee574c7672667f9a','8975be1e209554aaf','358da851518a0b673','bfb616935928b0eed'),('5121b8b702c6f5e62',0,32,'CAttendance',NULL,'read','2026-11-20 12:40:54','100.64.0.6','bac44286bee36cd47','8975be1e209554aaf','358da851518a0b673','bfb616935928b0eed'),('523d4b5ba1c45a156',0,138,'CInvoice',NULL,'read','2026-11-20 20:35:40','172.18.0.1','d393fc43249460ea6','8975be1e209554aaf',NULL,'54cd0834da9d97d78'),('57ffa8b6c9c65cfe7',0,93,'Note',NULL,'create','2026-11-20 19:45:10','100.64.0.13','532aa970883a8d753','3a9d2245f7f443cd5','0d41473af61914185','c4df400812bcca492'),('58156a1d6f803a20d',0,120,'CAMC',NULL,'create','2026-11-20 20:35:27','172.18.0.1','2d70128fccb163450','8975be1e209554aaf',NULL,'c05b5ab2e26587ea3'),('59dbf72b5bbfc3d68',0,106,'Lead',NULL,'read','2026-11-20 20:14:53','100.64.0.10','064cbaa61185d2fb2','8975be1e209554aaf','358da851518a0b673','bfb616935928b0eed'),('5af8d4d41434f01f1',0,129,'CPartService',NULL,'update','2026-11-20 20:35:29','172.18.0.1','6f8e92f43265d908e','8975be1e209554aaf',NULL,'cf04f7b7a0b8f778c'),('5d51c5214f4a06c05',0,3,'CAttendance',NULL,'create','2026-11-20 11:53:29','172.18.0.1','343d90807238b187e','8975be1e209554aaf',NULL,'61e8cacf406748a2f'),('5f7b98a95cfbbc03e',0,137,'CInvoice',NULL,'update','2026-11-20 20:35:40','172.18.0.1','d393fc43249460ea6','8975be1e209554aaf',NULL,'3b083faca5c31522a'),('5fdeb3d55ec1c439f',0,51,'LayoutSet',NULL,'create','2026-11-20 19:06:55','100.64.0.12','d66569f305a169ea6','8975be1e209554aaf','358da851518a0b673','bfb616935928b0eed'),('60c9395db5b516b89',0,50,'CAttendance',NULL,'update','2026-11-20 17:08:57','100.64.0.12','5155e3286aeb73c25','8975be1e209554aaf','358da851518a0b673','bfb616935928b0eed'),('650813c82b368677f',0,34,'CAttendance',NULL,'read','2026-11-20 12:41:22','100.64.0.15','3d1bcfdd0d782c3e7','8975be1e209554aaf','358da851518a0b673','bfb616935928b0eed'),('65669dd033e3201b7',0,68,'User',NULL,'read','2026-11-20 19:20:17','100.64.0.4','fc6e11cea4752c54f','8975be1e209554aaf','358da851518a0b673','bfb616935928b0eed'),('673b1241d0d4ab545',0,30,'CAttendance',NULL,'create','2026-11-20 12:40:34','100.64.0.8','bac44286bee36cd47','8975be1e209554aaf','b881e63e93c44e013','b50ca2b08c49e2c53'),('67c1c5da0a00b684a',0,5,'CWorkOrder',NULL,'read','2026-11-20 11:54:24','100.64.0.27','6d060c6e1e1181f59','8975be1e209554aaf','08f9050a5c8ea25b4','c28ece90422ce7b35'),('680450b5a7cd0b9b1',0,7,'CAttendance',NULL,'create','2026-11-20 12:01:06','100.64.0.33','3d1bcfdd0d782c3e7','8975be1e209554aaf','f8169207aeb86a16a','77a7a4c6ff888b829'),('6bf41a7534b29a2f5',0,55,'Team',NULL,'create','2026-11-20 19:09:02','100.64.0.10','ec10c8c9d8816d7ed','8975be1e209554aaf','358da851518a0b673','bfb616935928b0eed'),('6c26bc9de27cded50',0,13,'CAMC',NULL,'update','2026-11-20 12:10:56','172.18.0.1','d766f3eec4a784423','8975be1e209554aaf',NULL,'ce0bfcbd27f3115dc'),('6cff8a8e76b3612f2',0,80,'User',NULL,'read','2026-11-20 19:34:13','100.64.0.11','3a9d2245f7f443cd5','8975be1e209554aaf','358da851518a0b673','bfb616935928b0eed'),('6e7b96c7825ad4d54',0,58,'User',NULL,'read','2026-11-20 19:10:12','100.64.0.5','3a9d2245f7f443cd5','8975be1e209554aaf','358da851518a0b673','bfb616935928b0eed'),('70f53800a33b2e619',0,31,'CAttendance',NULL,'update','2026-11-20 12:40:37','100.64.0.9','bac44286bee36cd47','8975be1e209554aaf','bfcd331482a98c566','a8ad383f73770f065'),('728fdeceffdc612f4',0,115,'CDailyHours',NULL,'read','2026-11-20 20:26:19','100.64.0.9','a8233979e9a34d612','8975be1e209554aaf','358da851518a0b673','bfb616935928b0eed'),('7347d338d5001b5a2',0,69,'Attachment',NULL,'create','2026-11-20 19:20:59','100.64.0.1','bb2a40cc24997e887','8975be1e209554aaf','358da851518a0b673','bfb616935928b0eed'),('73a588d326568b773',0,136,'CInvoice',NULL,'read','2026-11-20 20:35:39','172.18.0.1','d393fc43249460ea6','8975be1e209554aaf',NULL,'af6f516bb82c291d8'),('758330dfdf5fa9ce5',0,125,'CPartService',NULL,'create','2026-11-20 20:35:28','172.18.0.1','6f8e92f43265d908e','8975be1e209554aaf',NULL,'dde6591d25eb01513'),('759c643322e77f554',0,48,'CJob',NULL,'update','2026-11-20 12:55:35','100.64.0.6','bee574c7672667f9a','8975be1e209554aaf','358da851518a0b673','bfb616935928b0eed'),('7992cee1b26a9300c',0,2,'CWorkOrder',NULL,'create','2026-11-20 11:53:12','172.18.0.1','6d060c6e1e1181f59','8975be1e209554aaf',NULL,'4c09927d27a830f52'),('7ad2402e9e227832e',0,10,'CAMC',NULL,'create','2026-11-20 12:10:47','172.18.0.1','d766f3eec4a784423','8975be1e209554aaf',NULL,'3fb69b410327dfc13'),('7b886b4bda556efa4',0,119,'Account',NULL,'create','2026-11-20 20:35:26','172.18.0.1','f3041c7f637e8df79','8975be1e209554aaf',NULL,'e5f97260008598201'),('7d04e2264999dd78c',0,11,'CWorkOrder',NULL,'update','2026-11-20 12:10:47','172.18.0.1','76b672d24f8bb255e','8975be1e209554aaf',NULL,'ca2bd544ccf1cd949'),('824568871aec5c021',0,64,'User',NULL,'update','2026-11-20 19:20:05','100.64.0.9','3a9d2245f7f443cd5','8975be1e209554aaf','358da851518a0b673','bfb616935928b0eed'),('872e0304e591748a8',0,16,'CAMC',NULL,'read','2026-11-20 12:11:44','100.64.0.14','d766f3eec4a784423','8975be1e209554aaf','7b38d64f39ae46d2b','59cdce47475b2a50d'),('89b66a736b321df5b',0,76,'Role',NULL,'update','2026-11-20 19:32:37','100.64.0.1','76786855438bb890a','8975be1e209554aaf','358da851518a0b673','bfb616935928b0eed'),('8b1919eb2811f651c',0,28,'CAttendance',NULL,'delete','2026-11-20 12:28:59','172.18.0.1','5cf9a1253b321c9ae','8975be1e209554aaf',NULL,'baae291fa0bb46622'),('8b2b739a24fd6b383',0,17,'CAMC',NULL,'read','2026-11-20 12:12:50','100.64.0.2','d766f3eec4a784423','8975be1e209554aaf','358da851518a0b673','bfb616935928b0eed'),('8e265c0422c3d92f7',0,127,'CInvoice',NULL,'create','2026-11-20 20:35:29','172.18.0.1','d393fc43249460ea6','8975be1e209554aaf',NULL,'abd3752ce3c3162a0'),('8e53d6fe258382bd8',0,36,'CAttendance',NULL,'update','2026-11-20 12:41:32','100.64.0.15','3d1bcfdd0d782c3e7','8975be1e209554aaf','358da851518a0b673','bfb616935928b0eed'),('8eb6621b8d9ffe9bd',0,14,'CAMC',NULL,'update','2026-11-20 12:10:56','172.18.0.1','d766f3eec4a784423','8975be1e209554aaf',NULL,'370f1bcb04a37296f'),('913d8a5550af20261',0,25,'CAttendance',NULL,'update','2026-11-20 12:28:57','172.18.0.1','3d1bcfdd0d782c3e7','8975be1e209554aaf',NULL,'ad6c932739975afd4'),('94f91f95fa12eea12',0,72,'User',NULL,'read','2026-11-20 19:28:48','100.64.0.6','3a9d2245f7f443cd5','8975be1e209554aaf','358da851518a0b673','bfb616935928b0eed'),('9597e6a4c5d725987',0,18,'CAMC',NULL,'read','2026-11-20 12:15:29','100.64.0.9','d766f3eec4a784423','8975be1e209554aaf','358da851518a0b673','bfb616935928b0eed'),('97184d02e59144778',0,98,'User',NULL,'read','2026-11-20 20:00:47','100.64.0.2','3a9d2245f7f443cd5','3a9d2245f7f443cd5','0d41473af61914185','c4df400812bcca492'),('99c523ba2e0c82433',0,39,'CAttendance',NULL,'update','2026-11-20 12:45:50','172.18.0.1','343d90807238b187e','8975be1e209554aaf',NULL,'0dbb409b1fdd8cb56'),('9b98f980d162a9a35',0,142,'CJob',NULL,'delete','2026-11-20 20:35:48','172.18.0.1','9b77a6adb5eeeeada','8975be1e209554aaf',NULL,'6849a99d875995cdb'),('9ba050aca1ae70c7f',0,140,'CEstimation',NULL,'delete','2026-11-20 20:35:46','172.18.0.1','bf551c7f371c4cc8e','8975be1e209554aaf',NULL,'42bcec8e84c8ff013'),('9ce969ecfde95e3f2',0,75,'Role',NULL,'read','2026-11-20 19:32:01','100.64.0.9','76786855438bb890a','8975be1e209554aaf','358da851518a0b673','bfb616935928b0eed'),('a31ef67f3e62c7fd1',0,112,'Lead',NULL,'read','2026-11-20 20:16:24','100.64.0.5','064cbaa61185d2fb2','8975be1e209554aaf','358da851518a0b673','bfb616935928b0eed'),('a79b4936175de09e7',0,8,'CAttendance',NULL,'update','2026-11-20 12:01:16','100.64.0.34','3d1bcfdd0d782c3e7','8975be1e209554aaf','405b307d474c58ef5','4346dae5be93a61c8'),('a89b8940f2a1f7329',0,38,'CDailyHours',NULL,'read','2026-11-20 12:41:43','100.64.0.4','d5c431f4b034b4b8b','8975be1e209554aaf','358da851518a0b673','bfb616935928b0eed'),('aa9653f41e8c1d089',0,73,'User',NULL,'update','2026-11-20 19:29:03','100.64.0.13','3a9d2245f7f443cd5','8975be1e209554aaf','358da851518a0b673','bfb616935928b0eed'),('aa9d5ee4da43cebde',0,99,'DashboardTemplate',NULL,'update','2026-11-20 20:06:22','100.64.0.7','5b0224715472ad4e8','8975be1e209554aaf','358da851518a0b673','bfb616935928b0eed'),('af1331ed908ff9917',0,74,'User',NULL,'read','2026-11-20 19:31:12','100.64.0.5','3a9d2245f7f443cd5','3a9d2245f7f443cd5','0d41473af61914185','c4df400812bcca492'),('b28955eadd8840d09',0,84,'CJob',NULL,'create','2026-11-20 19:36:57','100.64.0.1','26a23642611410415','8975be1e209554aaf','358da851518a0b673','bfb616935928b0eed'),('b46d93ae813cd3be1',0,103,'Opportunity',NULL,'update','2026-11-20 20:10:31','100.64.0.12','27b31c65ef0c038b5','8975be1e209554aaf','358da851518a0b673','bfb616935928b0eed'),('b7706c815c821872f',0,15,'CAMC',NULL,'read','2026-11-20 12:11:40','100.64.0.20','d766f3eec4a784423','8975be1e209554aaf','7b38d64f39ae46d2b','59cdce47475b2a50d'),('bd6db99ce7e6f1069',0,94,'CJob',NULL,'read','2026-11-20 19:50:28','100.64.0.13','bee574c7672667f9a','8975be1e209554aaf','358da851518a0b673','bfb616935928b0eed'),('be187a86510917853',0,19,'CJob',NULL,'create','2026-11-20 12:16:43','172.18.0.1','5172ba6f3bf9cf278','8975be1e209554aaf',NULL,'82a7c063fb34110c5'),('bee2cc7e0dd4862d3',0,133,'CPartService',NULL,'delete','2026-11-20 20:35:31','172.18.0.1','9bbc99d1aaa7e1a4b','8975be1e209554aaf',NULL,'739094dfbc4cc5681'),('c21a599d527a8ded2',0,57,'User',NULL,'create','2026-11-20 19:10:11','100.64.0.4','3a9d2245f7f443cd5','8975be1e209554aaf','358da851518a0b673','bfb616935928b0eed'),('c2c7d00ceb7ad052a',0,26,'CAttendance',NULL,'update','2026-11-20 12:28:58','172.18.0.1','343d90807238b187e','8975be1e209554aaf',NULL,'d25b361d4d45310a8'),('c3580e141027e737e',0,29,'CAttendance',NULL,'update','2026-11-20 12:39:57','100.64.0.5','66e3ae57755bf451c','8975be1e209554aaf','eb9a534dbac9e0c53','a6693062b9c26f48c'),('c890cd754c99c3324',0,143,'CAMC',NULL,'delete','2026-11-20 20:35:48','172.18.0.1','2d70128fccb163450','8975be1e209554aaf',NULL,'53e57c4028c020187'),('c98d231015471b483',0,63,'User',NULL,'read','2026-11-20 19:19:13','100.64.0.13','3a9d2245f7f443cd5','8975be1e209554aaf','358da851518a0b673','bfb616935928b0eed'),('ca04a4c07fc20bb26',0,110,'Contact',NULL,'create','2026-11-20 20:16:23','100.64.0.7','8795e37e5d45d44a3','8975be1e209554aaf','358da851518a0b673','bfb616935928b0eed'),('cb01c911541dc9887',0,122,'CWorkOrder',NULL,'create','2026-11-20 20:35:27','172.18.0.1','9256dd2bc6c0ed35e','8975be1e209554aaf',NULL,'2c7857da59bb8f7e2'),('cb29a5edae16437dd',0,4,'CWorkOrder',NULL,'read','2026-11-20 11:54:15','100.64.0.12','6d060c6e1e1181f59','8975be1e209554aaf','08f9050a5c8ea25b4','c28ece90422ce7b35'),('cb8c6f2786dd8f251',0,77,'User',NULL,'read','2026-11-20 19:32:44','100.64.0.12','3a9d2245f7f443cd5','8975be1e209554aaf','358da851518a0b673','bfb616935928b0eed'),('cc319fe31a9857881',0,128,'CPartService',NULL,'update','2026-11-20 20:35:29','172.18.0.1','9bbc99d1aaa7e1a4b','8975be1e209554aaf',NULL,'dd22a49e92e0b30c7'),('cc708567e1fd5aa49',0,141,'CWorkOrder',NULL,'delete','2026-11-20 20:35:47','172.18.0.1','9256dd2bc6c0ed35e','8975be1e209554aaf',NULL,'d7845747f9f404342'),('ccc52a539f1e592f7',0,37,'CDailyHours',NULL,'read','2026-11-20 12:41:40','100.64.0.15','d5c431f4b034b4b8b','8975be1e209554aaf','358da851518a0b673','bfb616935928b0eed'),('cda6471968ba31ac3',0,135,'CInvoice',NULL,'update','2026-11-20 20:35:39','172.18.0.1','d393fc43249460ea6','8975be1e209554aaf',NULL,'36991967dbb10e5ba'),('d0e99eea65b6c1b7a',0,46,'CJob',NULL,'read','2026-11-20 12:55:14','100.64.0.6','bee574c7672667f9a','8975be1e209554aaf','358da851518a0b673','bfb616935928b0eed'),('d4abfeab59edbd4d2',0,12,'CAMC',NULL,'update','2026-11-20 12:10:56','172.18.0.1','d766f3eec4a784423','8975be1e209554aaf',NULL,'e98361717d71b22e4'),('d5362a0b79482d560',0,97,'DashboardTemplate',NULL,'update','2026-11-20 20:00:33','100.64.0.1','5b0224715472ad4e8','8975be1e209554aaf','358da851518a0b673','bfb616935928b0eed'),('d7af9214a5c9811fe',0,6,'CWorkOrder',NULL,'create','2026-11-20 12:00:30','172.18.0.1','76b672d24f8bb255e','8975be1e209554aaf',NULL,'08a24444a907bef8f'),('da001d471a09cc26d',0,82,'User',NULL,'update','2026-11-20 19:34:21','100.64.0.4','3a9d2245f7f443cd5','8975be1e209554aaf','358da851518a0b673','bfb616935928b0eed'),('db83f71c54f1b53fc',0,101,'Opportunity',NULL,'read','2026-11-20 20:09:59','100.64.0.2','27b31c65ef0c038b5','8975be1e209554aaf','358da851518a0b673','bfb616935928b0eed'),('db92b0626fbd32783',0,21,'CJob',NULL,'update','2026-11-20 12:16:43','172.18.0.1','5172ba6f3bf9cf278','8975be1e209554aaf',NULL,'854a6bcdb519642b8'),('dc4ff98c72ee3b495',0,27,'CAttendance',NULL,'create','2026-11-20 12:28:58','172.18.0.1','5cf9a1253b321c9ae','8975be1e209554aaf',NULL,'df1cbc3cf67cec1bc'),('e107ceb9ac4a8b2de',0,108,'Lead',NULL,'read','2026-11-20 20:15:14','100.64.0.5','064cbaa61185d2fb2','8975be1e209554aaf','358da851518a0b673','bfb616935928b0eed'),('e23fa692002e2386f',0,70,'Role',NULL,'create','2026-11-20 19:27:44','100.64.0.6','76786855438bb890a','8975be1e209554aaf','358da851518a0b673','bfb616935928b0eed'),('e50a98c11cf9e81d8',0,78,'Team',NULL,'read','2026-11-20 19:33:47','100.64.0.10','d7b229038af2056a8','8975be1e209554aaf','358da851518a0b673','bfb616935928b0eed'),('e7b8bf51af4561216',0,56,'Team',NULL,'read','2026-11-20 19:09:02','100.64.0.8','ec10c8c9d8816d7ed','8975be1e209554aaf','358da851518a0b673','bfb616935928b0eed'),('e90a815e81e4f84c3',0,113,'Opportunity',NULL,'read','2026-11-20 20:16:51','100.64.0.11','7c97eb7ee580bd504','8975be1e209554aaf','358da851518a0b673','bfb616935928b0eed'),('e9d9cd854314e0eb5',0,116,'CDailyHours',NULL,'read','2026-11-20 20:26:21','100.64.0.10','a8233979e9a34d612','8975be1e209554aaf','358da851518a0b673','bfb616935928b0eed'),('eab4d8f17b8e00faf',0,66,'User',NULL,'read','2026-11-20 19:20:09','100.64.0.11','fc6e11cea4752c54f','8975be1e209554aaf','358da851518a0b673','bfb616935928b0eed'),('eb9df92fbc3657db4',0,126,'CEstimation',NULL,'read','2026-11-20 20:35:28','172.18.0.1','bf551c7f371c4cc8e','8975be1e209554aaf',NULL,'ec23c8640fc7701d8'),('ebb47bee8a2556261',0,139,'CInvoice',NULL,'delete','2026-11-20 20:35:45','172.18.0.1','d393fc43249460ea6','8975be1e209554aaf',NULL,'1772aa29899ffda27'),('ec996aa09b9898c3c',0,88,'DashboardTemplate',NULL,'update','2026-11-20 19:41:10','100.64.0.1','5b0224715472ad4e8','8975be1e209554aaf','358da851518a0b673','bfb616935928b0eed'),('ecc8286d20e576f32',0,83,'User',NULL,'read','2026-11-20 19:34:21','100.64.0.4','3a9d2245f7f443cd5','8975be1e209554aaf','358da851518a0b673','bfb616935928b0eed'),('ee7d3359ffb0351d4',0,134,'CEstimation',NULL,'read','2026-11-20 20:35:31','172.18.0.1','bf551c7f371c4cc8e','8975be1e209554aaf',NULL,'2507c7d73709867b7'),('eeee9fa600fc24663',0,42,'CAttendance',NULL,'create','2026-11-20 12:52:53','100.64.0.7','cc6593c4a6bf438fe','8975be1e209554aaf','358da851518a0b673','bfb616935928b0eed'),('ef916d616ba9af8ef',0,123,'CEstimation',NULL,'create','2026-11-20 20:35:28','172.18.0.1','bf551c7f371c4cc8e','8975be1e209554aaf',NULL,'eb41a279f0338f5e0'),('f24fa8eff65c0db5b',0,132,'CInvoice',NULL,'read','2026-11-20 20:35:31','172.18.0.1','d393fc43249460ea6','8975be1e209554aaf',NULL,'20c4de1163c82ad52'),('f2d6b73f3ba6ab168',0,117,'Lead',NULL,'read','2026-11-20 20:28:26','100.64.0.8','064cbaa61185d2fb2','8975be1e209554aaf','358da851518a0b673','bfb616935928b0eed'),('f35fac2078eb168e7',0,23,'CAMC',NULL,'read','2026-11-20 12:19:32','100.64.0.1','d766f3eec4a784423','8975be1e209554aaf','358da851518a0b673','bfb616935928b0eed'),('f47f3717972e2491e',0,130,'CInvoice',NULL,'read','2026-11-20 20:35:30','172.18.0.1','d393fc43249460ea6','8975be1e209554aaf',NULL,'887066f592263a780'),('f5fbf24eacc0ef3c0',0,124,'CPartService',NULL,'create','2026-11-20 20:35:28','172.18.0.1','9bbc99d1aaa7e1a4b','8975be1e209554aaf',NULL,'d5906dddc78e1cc2c'),('f5fd63050020c95a8',0,102,'Opportunity',NULL,'read','2026-11-20 20:10:15','100.64.0.8','27b31c65ef0c038b5','8975be1e209554aaf','358da851518a0b673','bfb616935928b0eed'),('f753f8dea1e05ea64',0,109,'Account',NULL,'create','2026-11-20 20:16:23','100.64.0.7','4a097347c0ebd6aff','8975be1e209554aaf','358da851518a0b673','bfb616935928b0eed'),('f79d4e5a78f7aebf5',0,41,'CAttendance',NULL,'update','2026-11-20 12:52:51','100.64.0.1','5062dab9aa60940ed','8975be1e209554aaf','358da851518a0b673','bfb616935928b0eed'),('f815ce4b120ee4e67',0,96,'CJob',NULL,'read','2026-11-20 19:51:09','100.64.0.11','1beaa2ed6d39769fc','8975be1e209554aaf','358da851518a0b673','bfb616935928b0eed'),('fc9974da7755c3355',0,62,'User',NULL,'update','2026-11-20 19:18:03','100.64.0.8','3a9d2245f7f443cd5','8975be1e209554aaf','358da851518a0b673','bfb616935928b0eed'),('fd54a0d31374b5c2f',0,121,'CJob',NULL,'create','2026-11-20 20:35:27','172.18.0.1','9b77a6adb5eeeeada','8975be1e209554aaf',NULL,'6537796026915d74e');
/*!40000 ALTER TABLE `action_history_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `address_country`
--

DROP TABLE IF EXISTS `address_country`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `address_country` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `code` varchar(2) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_preferred` tinyint NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_NAME` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `address_country`
--

LOCK TABLES `address_country` WRITE;
/*!40000 ALTER TABLE `address_country` DISABLE KEYS */;
/*!40000 ALTER TABLE `address_country` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_log_record`
--

DROP TABLE IF EXISTS `app_log_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_log_record` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint DEFAULT '0',
  `number` bigint unsigned NOT NULL AUTO_INCREMENT,
  `created_at` datetime DEFAULT NULL,
  `message` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `level` varchar(9) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `code` int DEFAULT NULL,
  `exception_class` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `line` int DEFAULT NULL,
  `request_method` varchar(7) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `request_resource_path` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `request_url` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_NUMBER` (`number`),
  KEY `IDX_LEVEL` (`level`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_log_record`
--

LOCK TABLES `app_log_record` WRITE;
/*!40000 ALTER TABLE `app_log_record` DISABLE KEYS */;
/*!40000 ALTER TABLE `app_log_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_secret`
--

DROP TABLE IF EXISTS `app_secret`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_secret` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `value` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `delete_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_NAME_DELETE_ID` (`name`,`delete_id`),
  KEY `IDX_NAME` (`name`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_secret`
--

LOCK TABLES `app_secret` WRITE;
/*!40000 ALTER TABLE `app_secret` DISABLE KEYS */;
/*!40000 ALTER TABLE `app_secret` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `array_value`
--

DROP TABLE IF EXISTS `array_value`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `array_value` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint DEFAULT '0',
  `value` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attribute` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `entity_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `entity_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_ENTITY_TYPE_VALUE` (`entity_type`,`value`),
  KEY `IDX_ENTITY_VALUE` (`entity_type`,`entity_id`,`value`),
  KEY `IDX_ENTITY` (`entity_id`,`entity_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `array_value`
--

LOCK TABLES `array_value` WRITE;
/*!40000 ALTER TABLE `array_value` DISABLE KEYS */;
INSERT INTO `array_value` VALUES ('cf255556f23e9532e',0,'BList','positionList','ec10c8c9d8816d7ed','Team'),('d9b64eebc70d41329',0,'Rank Pos','positionList','d7b229038af2056a8','Team');
/*!40000 ALTER TABLE `array_value` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `attachment`
--

DROP TABLE IF EXISTS `attachment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `attachment` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `size` bigint DEFAULT NULL,
  `field` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_being_uploaded` tinyint NOT NULL DEFAULT '0',
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `role` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `storage` varchar(24) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `storage_file_path` varchar(260) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `global` tinyint NOT NULL DEFAULT '0',
  `parent_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `related_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `related_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `source_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_PARENT` (`parent_type`,`parent_id`),
  KEY `IDX_RELATED` (`related_id`,`related_type`),
  KEY `IDX_SOURCE` (`source_id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attachment`
--

LOCK TABLES `attachment` WRITE;
/*!40000 ALTER TABLE `attachment` DISABLE KEYS */;
INSERT INTO `attachment` VALUES ('bb2a40cc24997e887','loogo.png',0,'image/png',120787,'companyLogo',0,'2026-11-20 19:20:59','2026-11-20 19:20:59','Attachment','EspoUploadDir',NULL,0,NULL,NULL,NULL,'Settings',NULL,'8975be1e209554aaf');
/*!40000 ALTER TABLE `attachment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_log_record`
--

DROP TABLE IF EXISTS `auth_log_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_log_record` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint DEFAULT '0',
  `username` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ip_address` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `is_denied` tinyint NOT NULL DEFAULT '0',
  `denial_reason` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `request_time` double DEFAULT NULL,
  `request_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `request_method` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `authentication_method` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `portal_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `auth_token_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_IP_ADDRESS` (`ip_address`),
  KEY `IDX_IP_ADDRESS_REQUEST_TIME` (`ip_address`,`request_time`),
  KEY `IDX_REQUEST_TIME` (`request_time`),
  KEY `IDX_USERNAME_IP_ADDRESS` (`username`,`ip_address`),
  KEY `IDX_PORTAL_ID` (`portal_id`),
  KEY `IDX_USER_ID` (`user_id`),
  KEY `IDX_AUTH_TOKEN_ID` (`auth_token_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_log_record`
--

LOCK TABLES `auth_log_record` WRITE;
/*!40000 ALTER TABLE `auth_log_record` DISABLE KEYS */;
INSERT INTO `auth_log_record` VALUES ('003c1bd9412bd3eef',0,'admin','172.18.0.1','2026-11-20 20:35:39',0,NULL,1795206939.0412,'http://localhost/api/v1/CInvoice','GET','Espo',NULL,'8975be1e209554aaf',NULL),('0052a4abb48302130',0,'admin','172.18.0.1','2026-11-20 11:52:40',0,NULL,1795175560.7367,'http://localhost/api/v1/Admin/fieldManager/CAttendance','POST','Espo',NULL,'8975be1e209554aaf',NULL),('00709930a1524f500',0,'admin','172.18.0.1','2026-11-20 12:16:32',0,NULL,1795176992.6518,'http://localhost/api/v1/EntityManager/action/formula','POST','Espo',NULL,'8975be1e209554aaf',NULL),('0096cb4e4512eafcf',0,'admin','172.18.0.1','2026-11-20 11:58:51',0,NULL,1795175931.4973,'http://localhost/api/v1/Settings','PUT','Espo',NULL,'8975be1e209554aaf',NULL),('009c7ea78ff288e5a',0,'admin','172.18.0.1','2026-11-20 12:01:21',0,NULL,1795176081.1657,'http://localhost/api/v1/CAttendance','GET','Espo',NULL,'8975be1e209554aaf',NULL),('025d457cf79bcf9cb',0,'admin','172.18.0.1','2026-11-20 12:16:20',0,NULL,1795176980.321,'http://localhost/api/v1/EntityManager/action/createEntity','POST','Espo',NULL,'8975be1e209554aaf',NULL),('0352cf66d71d6d83a',0,'admin','172.18.0.1','2026-11-20 20:34:43',0,NULL,1795206883.4019,'http://localhost/api/v1/Admin/fieldManager/CInvoice','POST','Espo',NULL,'8975be1e209554aaf',NULL),('04f242a695242ae8f',0,'admin','172.18.0.1','2026-11-20 20:36:05',0,NULL,1795206965.7163,'http://localhost/api/v1/App/user','GET','Espo',NULL,'8975be1e209554aaf','9d1899fc2070e6eb6'),('0573375b653fb0d68',0,'admin','172.18.0.1','2026-11-20 20:34:49',0,NULL,1795206888.9444,'http://localhost/api/v1/Admin/fieldManager/CPartService','POST','Espo',NULL,'8975be1e209554aaf',NULL),('067d68b5069b64e6a',0,'admin','172.18.0.1','2026-11-20 20:34:33',0,NULL,1795206873.2512,'http://localhost/api/v1/Admin/fieldManager/CEstimation','POST','Espo',NULL,'8975be1e209554aaf',NULL),('07a77568ab414b100',0,'admin','172.18.0.1','2026-11-20 19:59:51',0,NULL,1795204791.3706,'http://localhost/api/v1/App/user','GET','Espo',NULL,'8975be1e209554aaf',NULL),('07bc50286aa5c0a48',0,'admin','172.18.0.1','2026-11-20 12:11:40',0,NULL,1795176700.0777,'http://localhost/api/v1/Settings','PUT','Espo',NULL,'8975be1e209554aaf',NULL),('08031cd6c43293da6',0,'admin','172.18.0.1','2026-11-20 11:58:35',0,NULL,1795175914.9189,'http://localhost/api/v1/App/user','GET','Espo',NULL,'8975be1e209554aaf',NULL),('08a24444a907bef8f',0,'admin','172.18.0.1','2026-11-20 12:00:30',0,NULL,1795176030.3432,'http://localhost/api/v1/CWorkOrder','POST','Espo',NULL,'8975be1e209554aaf',NULL),('0986c9ca71c04e398',0,'admin','172.18.0.1','2026-11-20 20:34:50',0,NULL,1795206890.5706,'http://localhost/api/v1/EntityManager/action/createLink','POST','Espo',NULL,'8975be1e209554aaf',NULL),('0b25ae6162135d01f',0,'admin','172.18.0.1','2026-11-20 11:58:33',0,NULL,1795175913.5698,'http://localhost/api/v1/CWorkOrder/layout/detail','PUT','Espo',NULL,'8975be1e209554aaf',NULL),('0c0e729e01b07e592',0,'admin','172.18.0.1','2026-11-20 20:35:03',0,NULL,1795206903.1681,'http://localhost/api/v1/CInvoice/layout/detail','PUT','Espo',NULL,'8975be1e209554aaf',NULL),('0d3de824a653481ac',0,'admin','172.18.0.1','2026-11-20 12:28:29',0,NULL,1795177709.2901,'http://localhost/api/v1/Admin/fieldManager/CDailyHours','POST','Espo',NULL,'8975be1e209554aaf',NULL),('0dbb409b1fdd8cb56',0,'admin','172.18.0.1','2026-11-20 12:45:50',0,NULL,1795178749.9763,'http://localhost/api/v1/CAttendance/343d90807238b187e','PUT','Espo',NULL,'8975be1e209554aaf',NULL),('0e3e392bb709b421c',0,'admin','100.64.0.4','2026-11-20 12:02:13',0,NULL,1795176132.9509,'http://app-8b34cd0836f1d712.up.railway.app/api/v1/CAttendance','POST','Espo',NULL,'8975be1e209554aaf','d2b25d505a04d515c'),('0ecfe108b690f48ff',0,'admin','172.18.0.1','2026-11-20 20:34:44',0,NULL,1795206884.7754,'http://localhost/api/v1/Admin/fieldManager/CPartService','POST','Espo',NULL,'8975be1e209554aaf',NULL),('0f341b05002a727c1',0,'admin','172.18.0.1','2026-11-20 11:52:37',0,NULL,1795175557.3241,'http://localhost/api/v1/Admin/fieldManager/CAttendance','POST','Espo',NULL,'8975be1e209554aaf',NULL),('108fa6c722572643a',0,'admin','172.18.0.1','2026-11-20 11:58:04',0,NULL,1795175883.9465,'http://localhost/api/v1/EntityManager/action/removeEntity','POST','Espo',NULL,'8975be1e209554aaf',NULL),('1284f18c0fade3504',0,'admin','172.18.0.1','2026-11-20 20:34:44',0,NULL,1795206884.1317,'http://localhost/api/v1/Admin/fieldManager/CPartService','POST','Espo',NULL,'8975be1e209554aaf',NULL),('12d2860df2054ba9f',0,'admin','172.18.0.1','2026-11-20 11:52:24',0,NULL,1795175544.1351,'http://localhost/api/v1/Admin/fieldManager/CWorkOrder','POST','Espo',NULL,'8975be1e209554aaf',NULL),('12d77f46c0988d9c0',0,'admin','172.18.0.1','2026-11-20 20:35:33',0,NULL,1795206933.5057,'http://localhost/api/v1/CAMC/2d70128fccb163450/partServices','GET','Espo',NULL,'8975be1e209554aaf',NULL),('13049352447dfadf1',0,'admin','172.18.0.1','2026-11-20 12:47:19',0,NULL,1795178839.0403,'http://localhost/api/v1/App/user','GET','Espo',NULL,'8975be1e209554aaf',NULL),('14b21ff0fc3bd2f60',0,'admin','100.64.0.6','2026-11-20 12:40:30',0,NULL,1795178430.4992,'http://app-8b34cd0836f1d712.up.railway.app/api/v1/CAttendance','GET','Espo',NULL,'8975be1e209554aaf','fd4b5ef42ad98a305'),('15d4b6b5c299550a9',0,'admin','172.18.0.1','2026-11-20 11:58:34',0,NULL,1795175914.2469,'http://localhost/api/v1/Admin/fieldManager/CWorkOrder/assignedUser','PUT','Espo',NULL,'8975be1e209554aaf',NULL),('15fb0f073e4103a57',0,'admin','100.64.0.20','2026-11-20 12:52:01',0,NULL,1795179121.1156,'http://app-8b34cd0836f1d712.up.railway.app/api/v1/App/user','GET','Espo',NULL,'8975be1e209554aaf','36e84f0576c673650'),('1729ef2d1271e894e',0,'admin','172.18.0.1','2026-11-20 12:45:44',0,NULL,1795178744.0033,'http://localhost/api/v1/Preferences/8975be1e209554aaf','PUT','Espo',NULL,'8975be1e209554aaf',NULL),('174ff5ba21312cc99',0,'admin','172.18.0.1','2026-11-20 11:58:14',0,NULL,1795175894.4699,'http://localhost/api/v1/Admin/fieldManager/CWorkOrder/status','PUT','Espo',NULL,'8975be1e209554aaf',NULL),('175331fcb3435f50c',0,'admin','172.18.0.1','2026-11-20 20:35:45',0,NULL,1795206945.0501,'http://localhost/api/v1/CPartService','GET','Espo',NULL,'8975be1e209554aaf',NULL),('1772aa29899ffda27',0,'admin','172.18.0.1','2026-11-20 20:35:45',0,NULL,1795206945.7167,'http://localhost/api/v1/CInvoice/d393fc43249460ea6','DELETE','Espo',NULL,'8975be1e209554aaf',NULL),('18081ed80bc1a44ce',0,'admin','172.18.0.1','2026-11-20 20:34:55',0,NULL,1795206895.2096,'http://localhost/api/v1/EntityManager/action/createLink','POST','Espo',NULL,'8975be1e209554aaf',NULL),('1880f715e73ff1a02',0,'admin','172.18.0.1','2026-11-20 19:16:14',0,NULL,1795202173.6215,'http://localhost/api/v1/App/user','GET','Espo',NULL,'8975be1e209554aaf',NULL),('194379bea0fbaffee',0,'admin','172.18.0.1','2026-11-20 11:52:44',0,NULL,1795175564.5567,'http://localhost/api/v1/EntityManager/action/createLink','POST','Espo',NULL,'8975be1e209554aaf',NULL),('19979144ce826d707',0,'admin','172.18.0.1','2026-11-20 19:06:16',0,NULL,1795201576.143,'http://localhost/api/v1/App/user','GET','Espo',NULL,'8975be1e209554aaf',NULL),('1aff545d6cdd72931',0,'admin','172.18.0.1','2026-11-20 12:28:26',0,NULL,1795177705.8862,'http://localhost/api/v1/Admin/fieldManager/CDailyHours','POST','Espo',NULL,'8975be1e209554aaf',NULL),('1be977dbb106fb020',0,'admin','172.18.0.1','2026-11-20 11:51:58',0,NULL,1795175517.5822,'http://localhost/api/v1/App/user','GET','Espo',NULL,'8975be1e209554aaf',NULL),('1c7cedf7346ae6d5d',0,'admin','172.18.0.1','2026-11-20 11:52:43',0,NULL,1795175562.8119,'http://localhost/api/v1/EntityManager/action/createLink','POST','Espo',NULL,'8975be1e209554aaf',NULL),('1d6f2a828ab416302',0,'admin','172.18.0.1','2026-11-20 12:10:26',0,NULL,1795176626.7865,'http://localhost/api/v1/Admin/fieldManager/CAMC','POST','Espo',NULL,'8975be1e209554aaf',NULL),('1d92126c61be4f8fe',0,'admin','172.18.0.1','2026-11-20 14:23:23',0,NULL,1795184603.0396,'http://localhost/api/v1/App/user','GET','Espo',NULL,'8975be1e209554aaf',NULL),('1d92a0dd9f3994752',0,'admin','172.18.0.1','2026-11-20 11:54:04',0,NULL,1795175644.5663,'http://localhost/api/v1/Admin/fieldManager/CWorkOrder/actualStart','PUT','Espo',NULL,'8975be1e209554aaf',NULL),('1e6043e637bd09bff',0,'admin','172.18.0.1','2026-11-20 11:58:22',0,NULL,1795175902.1369,'http://localhost/api/v1/EntityManager/action/createLink','POST','Espo',NULL,'8975be1e209554aaf',NULL),('1f70c194c93181d7c',0,'admin','172.18.0.1','2026-11-20 12:45:43',0,NULL,1795178743.7392,'http://localhost/api/v1/App/user','GET','Espo',NULL,'8975be1e209554aaf',NULL),('20c4de1163c82ad52',0,'admin','172.18.0.1','2026-11-20 20:35:31',0,NULL,1795206931.007,'http://localhost/api/v1/CInvoice/d393fc43249460ea6','GET','Espo',NULL,'8975be1e209554aaf',NULL),('20ca3f7c925b8558b',0,'admin','100.64.0.10','2026-11-20 12:02:13',0,NULL,1795176133.5908,'http://app-8b34cd0836f1d712.up.railway.app/api/v1/CAttendance','GET','Espo',NULL,'8975be1e209554aaf','98973429d8f252570'),('21476b0fa1679fbae',0,'admin','172.18.0.1','2026-11-20 11:54:12',0,NULL,1795175651.956,'http://localhost/api/v1/Admin/fieldManager/CAttendance/checkInLng','PUT','Espo',NULL,'8975be1e209554aaf',NULL),('22148429956ea49ea',0,'admin','172.18.0.1','2026-11-20 12:10:32',0,NULL,1795176632.3738,'http://localhost/api/v1/Admin/fieldManager/CAMC','POST','Espo',NULL,'8975be1e209554aaf',NULL),('22adc301bd2a9f481',0,'admin','172.18.0.1','2026-11-20 20:35:03',0,NULL,1795206902.9394,'http://localhost/api/v1/CEstimation/layout/list','PUT','Espo',NULL,'8975be1e209554aaf',NULL),('2507c7d73709867b7',0,'admin','172.18.0.1','2026-11-20 20:35:31',0,NULL,1795206931.507,'http://localhost/api/v1/CEstimation/bf551c7f371c4cc8e','GET','Espo',NULL,'8975be1e209554aaf',NULL),('2601dc8955b627b2c',0,'admin','172.18.0.1','2026-11-20 11:54:10',0,NULL,1795175650.7412,'http://localhost/api/v1/Admin/fieldManager/CAttendance/status','PUT','Espo',NULL,'8975be1e209554aaf',NULL),('26b6b4c89166d770d',0,'admin','172.18.0.1','2026-11-20 12:28:58',0,NULL,1795177738.0451,'http://localhost/api/v1/App/user','GET','Espo',NULL,'8975be1e209554aaf',NULL),('26fd0366a4e207df0',0,'admin','172.18.0.1','2026-11-20 12:10:47',0,NULL,1795176647.0467,'http://localhost/api/v1/CWorkOrder','GET','Espo',NULL,'8975be1e209554aaf',NULL),('275a1f6609ddbb67f',0,'admin','172.18.0.1','2026-11-20 20:35:01',0,NULL,1795206901.1835,'http://localhost/api/v1/EntityManager/action/formula','POST','Espo',NULL,'8975be1e209554aaf',NULL),('28aded1ebe4af3e3d',0,'admin','172.18.0.1','2026-11-20 11:58:21',0,NULL,1795175900.8333,'http://localhost/api/v1/Admin/fieldManager/CWorkOrder/dateEnd','PUT','Espo',NULL,'8975be1e209554aaf',NULL),('2a0ddbd115d6e410b',0,'admin','172.18.0.1','2026-11-20 20:35:00',0,NULL,1795206900.349,'http://localhost/api/v1/EntityManager/action/createLink','POST','Espo',NULL,'8975be1e209554aaf',NULL),('2ae48a2d3d87f9e15',0,'admin','172.18.0.1','2026-11-20 12:28:58',0,NULL,1795177738.5794,'http://localhost/api/v1/CDailyHours','GET','Espo',NULL,'8975be1e209554aaf',NULL),('2c7857da59bb8f7e2',0,'admin','172.18.0.1','2026-11-20 20:35:27',0,NULL,1795206927.5323,'http://localhost/api/v1/CWorkOrder','POST','Espo',NULL,'8975be1e209554aaf',NULL),('2cdb2f2600889b903',0,'admin','172.18.0.1','2026-11-20 11:58:34',0,NULL,1795175913.8018,'http://localhost/api/v1/CWorkOrder/layout/list','PUT','Espo',NULL,'8975be1e209554aaf',NULL),('301ba8807a6023f9d',0,'admin','172.18.0.1','2026-11-20 11:52:38',0,NULL,1795175558.0404,'http://localhost/api/v1/Admin/fieldManager/CAttendance','POST','Espo',NULL,'8975be1e209554aaf',NULL),('303da5e4ebeda9b2f',0,'admin','172.18.0.1','2026-11-20 11:54:06',0,NULL,1795175645.9206,'http://localhost/api/v1/Admin/fieldManager/CWorkOrder/resolutionNotes','PUT','Espo',NULL,'8975be1e209554aaf',NULL),('3092439fafd62c23c',0,'admin','172.18.0.1','2026-11-20 20:34:40',0,NULL,1795206879.8837,'http://localhost/api/v1/Admin/fieldManager/CInvoice','POST','Espo',NULL,'8975be1e209554aaf',NULL),('30ec7bd8a7912e6c0',0,'admin','172.18.0.1','2026-11-20 12:16:43',0,NULL,1795177003.6693,'http://localhost/api/v1/CJob/5172ba6f3bf9cf278/workOrders','GET','Espo',NULL,'8975be1e209554aaf',NULL),('317a8aedc9cce810e',0,'admin','172.18.0.1','2026-11-20 12:16:24',0,NULL,1795176984.118,'http://localhost/api/v1/Admin/fieldManager/CJob','POST','Espo',NULL,'8975be1e209554aaf',NULL),('3269f70594ceaa2be',0,'admin','172.18.0.1','2026-11-20 20:34:57',0,NULL,1795206897.3306,'http://localhost/api/v1/EntityManager/action/createLink','POST','Espo',NULL,'8975be1e209554aaf',NULL),('36991967dbb10e5ba',0,'admin','172.18.0.1','2026-11-20 20:35:39',0,NULL,1795206939.2789,'http://localhost/api/v1/CInvoice/d393fc43249460ea6','PUT','Espo',NULL,'8975be1e209554aaf',NULL),('370f1bcb04a37296f',0,'admin','172.18.0.1','2026-11-20 12:10:56',0,NULL,1795176656.3111,'http://localhost/api/v1/CAMC/d766f3eec4a784423','PUT','Espo',NULL,'8975be1e209554aaf',NULL),('377e447b63c8a6ade',0,'admin','172.18.0.1','2026-11-20 20:35:32',0,NULL,1795206932.1488,'http://localhost/api/v1/CJob/9b77a6adb5eeeeada/partServices','GET','Espo',NULL,'8975be1e209554aaf',NULL),('37bb91b5d21516dc1',0,'admin','172.18.0.1','2026-11-20 12:16:25',0,NULL,1795176985.6821,'http://localhost/api/v1/Admin/fieldManager/CJob','POST','Espo',NULL,'8975be1e209554aaf',NULL),('39352f65227549325',0,'admin','172.18.0.1','2026-11-20 12:48:09',0,NULL,1795178889.5064,'http://localhost/api/v1/Admin/clearCache','POST','Espo',NULL,'8975be1e209554aaf',NULL),('3b083faca5c31522a',0,'admin','172.18.0.1','2026-11-20 20:35:40',0,NULL,1795206939.8348,'http://localhost/api/v1/CInvoice/d393fc43249460ea6','PUT','Espo',NULL,'8975be1e209554aaf',NULL),('3bb9228ba8f138fe6',0,'admin','172.18.0.1','2026-11-20 20:35:46',0,NULL,1795206946.6747,'http://localhost/api/v1/CEstimation','GET','Espo',NULL,'8975be1e209554aaf',NULL),('3c477fd7693103ff2',0,'admin','172.18.0.1','2026-11-20 12:16:23',0,NULL,1795176983.2838,'http://localhost/api/v1/Admin/fieldManager/CJob','POST','Espo',NULL,'8975be1e209554aaf',NULL),('3ce68c36f2f0ec267',0,'admin','172.18.0.1','2026-11-20 20:35:32',0,NULL,1795206932.3647,'http://localhost/api/v1/CWorkOrder/9256dd2bc6c0ed35e/estimations','GET','Espo',NULL,'8975be1e209554aaf',NULL),('3d23c27ed702a0dba',0,'admin','172.18.0.1','2026-11-20 12:10:34',0,NULL,1795176634.11,'http://localhost/api/v1/Admin/fieldManager/CAMC','POST','Espo',NULL,'8975be1e209554aaf',NULL),('3d87fdce6411ccaa8',0,'admin','172.18.0.1','2026-11-20 18:12:24',0,NULL,1795198344.5173,'http://localhost/api/v1/App/user','GET','Espo',NULL,'8975be1e209554aaf',NULL),('3e0532935d23cc086',0,'admin','100.64.0.7','2026-11-20 20:30:15',0,NULL,1795206615.1345,'http://app-8b34cd0836f1d712.up.railway.app/api/v1/App/user','GET','Espo',NULL,'8975be1e209554aaf','0973bc66a817b0306'),('3eba00a28adced47b',0,'admin','172.18.0.1','2026-11-20 20:34:58',0,NULL,1795206898.0413,'http://localhost/api/v1/EntityManager/action/createLink','POST','Espo',NULL,'8975be1e209554aaf',NULL),('3fb69b410327dfc13',0,'admin','172.18.0.1','2026-11-20 12:10:46',0,NULL,1795176646.686,'http://localhost/api/v1/CAMC','POST','Espo',NULL,'8975be1e209554aaf',NULL),('3fc1c47467c3fefdc',0,'admin','172.18.0.1','2026-11-20 11:54:07',0,NULL,1795175647.7384,'http://localhost/api/v1/Admin/fieldManager/CWorkOrder/address','PUT','Espo',NULL,'8975be1e209554aaf',NULL),('407490814ebe4acc1',0,'admin','100.64.0.21','2026-11-20 12:00:50',0,NULL,1795176049.6061,'http://app-8b34cd0836f1d712.up.railway.app/api/v1/CAttendance','GET','Espo',NULL,'8975be1e209554aaf','5a954821df4d83ed7'),('408bd92e54f47a6e7',0,'admin','172.18.0.1','2026-11-20 12:16:28',0,NULL,1795176988.186,'http://localhost/api/v1/Admin/fieldManager/CJob','POST','Espo',NULL,'8975be1e209554aaf',NULL),('40ce214b8e5924717',0,'admin','172.18.0.1','2026-11-20 12:28:32',0,NULL,1795177712.0303,'http://localhost/api/v1/CDailyHours/layout/detail','PUT','Espo',NULL,'8975be1e209554aaf',NULL),('41467f2c8f1436932',0,'admin','172.18.0.1','2026-11-20 12:11:35',0,NULL,1795176695.5139,'http://localhost/api/v1/App/user','GET','Espo',NULL,'8975be1e209554aaf',NULL),('42bcec8e84c8ff013',0,'admin','172.18.0.1','2026-11-20 20:35:46',0,NULL,1795206946.4254,'http://localhost/api/v1/CEstimation/bf551c7f371c4cc8e','DELETE','Espo',NULL,'8975be1e209554aaf',NULL),('4346dae5be93a61c8',0,'admin','100.64.0.34','2026-11-20 12:01:16',0,NULL,1795176076.4735,'http://app-8b34cd0836f1d712.up.railway.app/api/v1/CAttendance/3d1bcfdd0d782c3e7','PUT','Espo',NULL,'8975be1e209554aaf','405b307d474c58ef5'),('47daaed9e2be4555e',0,'admin','172.18.0.1','2026-11-20 17:52:44',0,NULL,1795197164.2283,'http://localhost/api/v1/App/user','GET','Espo',NULL,'8975be1e209554aaf',NULL),('47e442bc6e7572c77',0,'admin','172.18.0.1','2026-11-20 11:52:39',0,NULL,1795175559.1774,'http://localhost/api/v1/Admin/fieldManager/CAttendance','POST','Espo',NULL,'8975be1e209554aaf',NULL),('4888cf686d37b8453',0,'admin','172.18.0.1','2026-11-20 20:34:51',0,NULL,1795206891.2899,'http://localhost/api/v1/EntityManager/action/createLink','POST','Espo',NULL,'8975be1e209554aaf',NULL),('4b42ad168f5912bb1',0,'admin','172.18.0.1','2026-11-20 12:36:07',0,NULL,1795178166.7862,'http://localhost/api/v1/App/user','GET','Espo',NULL,'8975be1e209554aaf',NULL),('4bb0ed103e12f6555',0,'admin','172.18.0.1','2026-11-20 11:58:17',0,NULL,1795175897.1874,'http://localhost/api/v1/Admin/fieldManager/CWorkOrder','POST','Espo',NULL,'8975be1e209554aaf',NULL),('4c09927d27a830f52',0,'admin','172.18.0.1','2026-11-20 11:53:12',0,NULL,1795175591.9197,'http://localhost/api/v1/CWorkOrder','POST','Espo',NULL,'8975be1e209554aaf',NULL),('4cd8ca43aec64d3fe',0,'admin','100.64.0.8','2026-11-20 12:40:34',0,NULL,1795178434.4588,'http://app-8b34cd0836f1d712.up.railway.app/api/v1/CAttendance','GET','Espo',NULL,'8975be1e209554aaf','1213ddfb0ae85b314'),('4e0c6cc3ee0cdd227',0,'admin','172.18.0.1','2026-11-20 11:52:40',0,NULL,1795175559.9694,'http://localhost/api/v1/Admin/fieldManager/CAttendance','POST','Espo',NULL,'8975be1e209554aaf',NULL),('4e22f9fb440492932',0,'admin','172.18.0.1','2026-11-20 20:34:56',0,NULL,1795206895.9263,'http://localhost/api/v1/EntityManager/action/createLink','POST','Espo',NULL,'8975be1e209554aaf',NULL),('4ef497c094a661c7c',0,'admin','172.18.0.1','2026-11-20 20:35:32',0,NULL,1795206932.5873,'http://localhost/api/v1/CWorkOrder/9256dd2bc6c0ed35e/invoices','GET','Espo',NULL,'8975be1e209554aaf',NULL),('5015e5903e26a0d73',0,'admin','172.18.0.1','2026-11-20 12:36:12',0,NULL,1795178172.3453,'http://localhost/api/v1/App/user','GET','Espo',NULL,'8975be1e209554aaf',NULL),('53406f2e8c30e9800',0,'admin','100.64.0.9','2026-11-20 11:13:16',1,'CREDENTIALS',1795173196.0649,'http://app-8b34cd0836f1d712.up.railway.app/api/v1/App/user','GET','Espo',NULL,NULL,NULL),('5348ba196c4eb94b0',0,'admin','172.18.0.1','2026-11-20 12:10:27',0,NULL,1795176627.5986,'http://localhost/api/v1/Admin/fieldManager/CAMC','POST','Espo',NULL,'8975be1e209554aaf',NULL),('5353e88bf7b0b5e9d',0,'admin','172.18.0.1','2026-11-20 11:52:27',0,NULL,1795175546.8894,'http://localhost/api/v1/Admin/fieldManager/CWorkOrder','POST','Espo',NULL,'8975be1e209554aaf',NULL),('53e57c4028c020187',0,'admin','172.18.0.1','2026-11-20 20:35:48',0,NULL,1795206948.5366,'http://localhost/api/v1/CAMC/2d70128fccb163450','DELETE','Espo',NULL,'8975be1e209554aaf',NULL),('54025b8eec292f9da',0,'admin','100.64.0.7','2026-11-20 12:40:37',0,NULL,1795178437.6103,'http://app-8b34cd0836f1d712.up.railway.app/api/v1/CAttendance','GET','Espo',NULL,'8975be1e209554aaf','7386f06ca589b5b98'),('54595807bd47f4a9c',0,'admin','172.18.0.1','2026-11-20 20:35:49',0,NULL,1795206949.4245,'http://localhost/api/v1/Account','GET','Espo',NULL,'8975be1e209554aaf',NULL),('54cd0834da9d97d78',0,'admin','172.18.0.1','2026-11-20 20:35:40',0,NULL,1795206940.1071,'http://localhost/api/v1/CInvoice/d393fc43249460ea6','GET','Espo',NULL,'8975be1e209554aaf',NULL),('54d857fd4cdc1ce0c',0,'admin','172.18.0.1','2026-11-20 20:35:33',0,NULL,1795206932.8401,'http://localhost/api/v1/CWorkOrder/9256dd2bc6c0ed35e/partServices','GET','Espo',NULL,'8975be1e209554aaf',NULL),('566c47b024efdd1ff',0,'admin','172.18.0.1','2026-11-20 20:34:59',0,NULL,1795206898.8679,'http://localhost/api/v1/EntityManager/action/createLink','POST','Espo',NULL,'8975be1e209554aaf',NULL),('56ade4cdc96806a5a',0,'admin','100.64.0.17','2026-11-20 12:01:16',0,NULL,1795176076.1682,'http://app-8b34cd0836f1d712.up.railway.app/api/v1/CAttendance','GET','Espo',NULL,'8975be1e209554aaf','aba58bea40d5e26c0'),('57d2f560ee603dfa3',0,'admin','172.18.0.1','2026-11-20 11:53:12',0,NULL,1795175592.1937,'http://localhost/api/v1/CAttendance','POST','Espo',NULL,'8975be1e209554aaf',NULL),('57d458671a35ef8cc',0,'admin','100.64.0.9','2026-11-20 12:02:08',0,NULL,1795176128.0214,'http://app-8b34cd0836f1d712.up.railway.app/api/v1/CAttendance','GET','Espo',NULL,'8975be1e209554aaf','dc97d2112d2a9e019'),('5933fd9d7f2c0cc1d',0,'admin','172.18.0.1','2026-11-20 11:52:36',0,NULL,1795175556.6054,'http://localhost/api/v1/Admin/fieldManager/CAttendance','POST','Espo',NULL,'8975be1e209554aaf',NULL),('59cdce47475b2a50d',0,'admin','100.64.0.21','2026-11-20 12:11:22',0,NULL,1795176682.491,'http://app-8b34cd0836f1d712.up.railway.app/api/v1/App/user','GET','Espo',NULL,'8975be1e209554aaf','7b38d64f39ae46d2b'),('59fd96b95345b7230',0,'admin','172.18.0.1','2026-11-20 11:52:42',0,NULL,1795175562.1122,'http://localhost/api/v1/EntityManager/action/createLink','POST','Espo',NULL,'8975be1e209554aaf',NULL),('5a811b15d8fac76e3',0,'admin','172.18.0.1','2026-11-20 11:52:30',0,NULL,1795175550.4406,'http://localhost/api/v1/Admin/fieldManager/CWorkOrder','POST','Espo',NULL,'8975be1e209554aaf',NULL),('5c3a82bb95338a962',0,'admin','172.18.0.1','2026-11-20 11:52:10',0,NULL,1795175529.6,'http://localhost/api/v1/Metadata','GET','Espo',NULL,'8975be1e209554aaf',NULL),('5c4c2328eadf7f920',0,'admin','172.18.0.1','2026-11-20 20:34:59',0,NULL,1795206899.613,'http://localhost/api/v1/EntityManager/action/createLink','POST','Espo',NULL,'8975be1e209554aaf',NULL),('5cf97c1245e39ea14',0,'admin','172.18.0.1','2026-11-20 12:04:34',0,NULL,1795176274.1767,'http://localhost/api/v1/Settings','PUT','Espo',NULL,'8975be1e209554aaf',NULL),('5d6029bdcb7c92893',0,'admin','172.18.0.1','2026-11-20 12:45:41',0,NULL,1795178740.8086,'http://localhost/api/v1/Admin/fieldManager/CAttendance','POST','Espo',NULL,'8975be1e209554aaf',NULL),('60d86b3bd99f5a58b',0,'admin','172.18.0.1','2026-11-20 11:54:03',0,NULL,1795175643.4539,'http://localhost/api/v1/Admin/fieldManager/CWorkOrder/scheduledStart','PUT','Espo',NULL,'8975be1e209554aaf',NULL),('61390158d3f733228',0,'admin','172.18.0.1','2026-11-20 20:34:41',0,NULL,1795206881.2359,'http://localhost/api/v1/Admin/fieldManager/CInvoice','POST','Espo',NULL,'8975be1e209554aaf',NULL),('61e18402b0a36ede4',0,'admin','172.18.0.1','2026-11-20 12:28:32',0,NULL,1795177712.2699,'http://localhost/api/v1/CDailyHours/layout/list','PUT','Espo',NULL,'8975be1e209554aaf',NULL),('61e8cacf406748a2f',0,'admin','172.18.0.1','2026-11-20 11:53:29',0,NULL,1795175608.9502,'http://localhost/api/v1/CAttendance','POST','Espo',NULL,'8975be1e209554aaf',NULL),('6229ca766da910b24',0,'admin','172.18.0.1','2026-11-20 12:16:22',0,NULL,1795176982.2226,'http://localhost/api/v1/Admin/fieldManager/CJob','POST','Espo',NULL,'8975be1e209554aaf',NULL),('637ee2d98c1e287b9',0,'admin','172.18.0.1','2026-11-20 11:52:29',0,NULL,1795175549.7395,'http://localhost/api/v1/Admin/fieldManager/CWorkOrder','POST','Espo',NULL,'8975be1e209554aaf',NULL),('641404efb7f05a543',0,'admin','172.18.0.1','2026-11-20 11:52:55',0,NULL,1795175574.8104,'http://localhost/api/v1/EntityManager/action/formula','POST','Espo',NULL,'8975be1e209554aaf',NULL),('6537796026915d74e',0,'admin','172.18.0.1','2026-11-20 20:35:27',0,NULL,1795206927.2435,'http://localhost/api/v1/CJob','POST','Espo',NULL,'8975be1e209554aaf',NULL),('6554b3a5cd7f6411b',0,'admin','172.18.0.1','2026-11-20 11:53:05',0,NULL,1795175585.1907,'http://localhost/api/v1/App/user','GET','Espo',NULL,'8975be1e209554aaf',NULL),('65c268a6b60f08d2f',0,'admin','172.18.0.1','2026-11-20 11:52:34',0,NULL,1795175553.7905,'http://localhost/api/v1/Admin/fieldManager/CWorkOrder','POST','Espo',NULL,'8975be1e209554aaf',NULL),('665e8c03bd89c4a3e',0,'admin','100.64.0.25','2026-11-20 11:22:03',0,NULL,1795173722.8613,'http://app-8b34cd0836f1d712.up.railway.app/api/v1/App/user','GET','Espo',NULL,'8975be1e209554aaf',NULL),('67065e962efa8a3c0',0,'admin','172.18.0.1','2026-11-20 11:54:02',0,NULL,1795175642.3944,'http://localhost/api/v1/Admin/fieldManager/CWorkOrder/jobType','PUT','Espo',NULL,'8975be1e209554aaf',NULL),('67e9c3ac30077c68e',0,'admin','172.18.0.1','2026-11-20 20:34:54',0,NULL,1795206894.5509,'http://localhost/api/v1/EntityManager/action/createLink','POST','Espo',NULL,'8975be1e209554aaf',NULL),('6849a99d875995cdb',0,'admin','172.18.0.1','2026-11-20 20:35:47',0,NULL,1795206947.7954,'http://localhost/api/v1/CJob/9b77a6adb5eeeeada','DELETE','Espo',NULL,'8975be1e209554aaf',NULL),('694a584fecca17d18',0,'admin','172.18.0.1','2026-11-20 12:47:19',0,NULL,1795178839.3784,'http://localhost/api/v1/Preferences/8975be1e209554aaf','GET','Espo',NULL,'8975be1e209554aaf',NULL),('697d10805f92bf97f',0,'admin','172.18.0.1','2026-11-20 12:00:31',0,NULL,1795176030.7648,'http://localhost/api/v1/Activities','GET','Espo',NULL,'8975be1e209554aaf',NULL),('6ac062e7e4e2ab207',0,'admin','172.18.0.1','2026-11-20 12:10:46',0,NULL,1795176646.205,'http://localhost/api/v1/Settings','PUT','Espo',NULL,'8975be1e209554aaf',NULL),('6b73a17c130d77fa1',0,'admin','172.18.0.1','2026-11-20 12:04:34',0,NULL,1795176274.4575,'http://localhost/api/v1/App/user','GET','Espo',NULL,'8975be1e209554aaf',NULL),('6c539f5b3b6b8e968',0,'admin','172.18.0.1','2026-11-20 12:16:32',0,NULL,1795176991.9859,'http://localhost/api/v1/EntityManager/action/createLink','POST','Espo',NULL,'8975be1e209554aaf',NULL),('6cd7ed32c0d60bb40',0,'admin','172.18.0.1','2026-11-20 12:01:10',0,NULL,1795176070.7546,'http://localhost/api/v1/CAttendance','GET','Espo',NULL,'8975be1e209554aaf',NULL),('6cdf11d3c0fe81f75',0,'admin','172.18.0.1','2026-11-20 20:35:02',0,NULL,1795206901.7357,'http://localhost/api/v1/EntityManager/action/formula','POST','Espo',NULL,'8975be1e209554aaf',NULL),('6d78d4e3857c13fe0',0,'admin','172.18.0.1','2026-11-20 11:55:27',0,NULL,1795175727.1273,'http://localhost/api/v1/Admin/clearCache','POST','Espo',NULL,'8975be1e209554aaf',NULL),('6db20c776fd7fddaf',0,'admin','172.18.0.1','2026-11-20 12:48:08',0,NULL,1795178888.5353,'http://localhost/api/v1/App/user','GET','Espo',NULL,'8975be1e209554aaf',NULL),('6e8d5c4caa1e7a313',0,'admin','172.18.0.1','2026-11-20 11:52:32',0,NULL,1795175552.0804,'http://localhost/api/v1/Admin/fieldManager/CWorkOrder','POST','Espo',NULL,'8975be1e209554aaf',NULL),('6eab0f70c9acc4349',0,'admin','172.18.0.1','2026-11-20 12:58:26',0,NULL,1795179506.4184,'http://localhost/api/v1/App/user','GET','Espo',NULL,'8975be1e209554aaf',NULL),('6fc41ae6feeab5f57',0,'admin','172.18.0.1','2026-11-20 11:53:11',0,NULL,1795175590.9843,'http://localhost/api/v1/Account','POST','Espo',NULL,'8975be1e209554aaf',NULL),('72301e46835c2b6a1',0,'admin','172.18.0.1','2026-11-20 11:58:51',0,NULL,1795175931.7007,'http://localhost/api/v1/Preferences/8975be1e209554aaf','PUT','Espo',NULL,'8975be1e209554aaf',NULL),('72e76202a45e70936',0,'admin','172.18.0.1','2026-11-20 12:16:34',0,NULL,1795176994.5694,'http://localhost/api/v1/App/user','GET','Espo',NULL,'8975be1e209554aaf',NULL),('732200d36959de2eb',0,'admin','172.18.0.1','2026-11-20 12:16:44',0,NULL,1795177003.8881,'http://localhost/api/v1/CAMC/d766f3eec4a784423/jobs','GET','Espo',NULL,'8975be1e209554aaf',NULL),('739094dfbc4cc5681',0,'admin','172.18.0.1','2026-11-20 20:35:31',0,NULL,1795206931.2322,'http://localhost/api/v1/CPartService/9bbc99d1aaa7e1a4b','DELETE','Espo',NULL,'8975be1e209554aaf',NULL),('7523a3b9caf09dd04',0,'admin','172.18.0.1','2026-11-20 11:58:19',0,NULL,1795175899.0697,'http://localhost/api/v1/Admin/fieldManager/CWorkOrder','POST','Espo',NULL,'8975be1e209554aaf',NULL),('7645beb25582ade09',0,'admin','172.18.0.1','2026-11-20 20:35:48',0,NULL,1795206948.285,'http://localhost/api/v1/CAMC','GET','Espo',NULL,'8975be1e209554aaf',NULL),('77a7a4c6ff888b829',0,'admin','100.64.0.33','2026-11-20 12:01:06',0,NULL,1795176066.5488,'http://app-8b34cd0836f1d712.up.railway.app/api/v1/CAttendance','POST','Espo',NULL,'8975be1e209554aaf','f8169207aeb86a16a'),('78355a934e031d9ec',0,'admin','172.18.0.1','2026-11-20 11:54:10',0,NULL,1795175650.2108,'http://localhost/api/v1/Admin/fieldManager/CAttendance/checkOut','PUT','Espo',NULL,'8975be1e209554aaf',NULL),('786b56dd13257b17b',0,'admin','172.18.0.1','2026-11-20 12:16:35',0,NULL,1795176995.0791,'http://localhost/api/v1/Admin/clearCache','POST','Espo',NULL,'8975be1e209554aaf',NULL),('78f780fab0e6eed81',0,'admin','172.18.0.1','2026-11-20 12:48:09',0,NULL,1795178889.3018,'http://localhost/api/v1/Settings','PUT','Espo',NULL,'8975be1e209554aaf',NULL),('7bd009008c602c494',0,'admin','172.18.0.1','2026-11-20 12:10:47',0,NULL,1795176647.6097,'http://localhost/api/v1/Admin/clearCache','POST','Espo',NULL,'8975be1e209554aaf',NULL),('7c15218931f082ebc',0,'admin','172.18.0.1','2026-11-20 20:35:47',0,NULL,1795206947.3294,'http://localhost/api/v1/CWorkOrder','GET','Espo',NULL,'8975be1e209554aaf',NULL),('7d0bae89a402e663e',0,'admin','172.18.0.1','2026-11-20 20:34:30',0,NULL,1795206869.7858,'http://localhost/api/v1/Admin/fieldManager/CEstimation','POST','Espo',NULL,'8975be1e209554aaf',NULL),('8069f56bd8f69a533',0,'admin','172.18.0.1','2026-11-20 11:58:12',0,NULL,1795175892.5086,'http://localhost/api/v1/EntityManager/action/createEntity','POST','Espo',NULL,'8975be1e209554aaf',NULL),('80b84bd15c87ad892',0,'admin','172.18.0.1','2026-11-20 20:35:33',0,NULL,1795206933.2926,'http://localhost/api/v1/CAMC/2d70128fccb163450/invoices','GET','Espo',NULL,'8975be1e209554aaf',NULL),('80cbb77108eb9e0c9',0,'admin','172.18.0.1','2026-11-20 20:35:02',0,NULL,1795206902.2412,'http://localhost/api/v1/EntityManager/action/formula','POST','Espo',NULL,'8975be1e209554aaf',NULL),('820beef28597797a8',0,'admin','172.18.0.1','2026-11-20 11:52:32',0,NULL,1795175551.8353,'http://localhost/api/v1/Admin/fieldManager/CWorkOrder','POST','Espo',NULL,'8975be1e209554aaf',NULL),('827eaa82ff939e7c6',0,'admin','172.18.0.1','2026-11-20 11:54:09',0,NULL,1795175648.8742,'http://localhost/api/v1/Admin/fieldManager/CAttendance/date','PUT','Espo',NULL,'8975be1e209554aaf',NULL),('82a7c063fb34110c5',0,'admin','172.18.0.1','2026-11-20 12:16:42',0,NULL,1795177002.6776,'http://localhost/api/v1/CJob','POST','Espo',NULL,'8975be1e209554aaf',NULL),('8347dd639d8a38562',0,'admin','172.18.0.1','2026-11-20 20:34:46',0,NULL,1795206886.1602,'http://localhost/api/v1/Admin/fieldManager/CPartService','POST','Espo',NULL,'8975be1e209554aaf',NULL),('83bb45090a9a221bd',0,'admin','172.18.0.1','2026-11-20 11:52:26',0,NULL,1795175545.7043,'http://localhost/api/v1/Admin/fieldManager/CWorkOrder','POST','Espo',NULL,'8975be1e209554aaf',NULL),('83f55e513b46d4d2b',0,'admin','100.64.0.2','2026-11-20 12:40:29',0,NULL,1795178429.6669,'http://app-8b34cd0836f1d712.up.railway.app/api/v1/App/user','GET','Espo',NULL,'8975be1e209554aaf','3d0ada9cb5b60d311'),('845318812085c1042',0,'admin','172.18.0.1','2026-11-20 20:35:49',0,NULL,1795206948.9963,'http://localhost/api/v1/Account','GET','Espo',NULL,'8975be1e209554aaf',NULL),('854a6bcdb519642b8',0,'admin','172.18.0.1','2026-11-20 12:16:43',0,NULL,1795177003.3744,'http://localhost/api/v1/CJob/5172ba6f3bf9cf278','PUT','Espo',NULL,'8975be1e209554aaf',NULL),('85fdc3326a8e45095',0,'admin','172.18.0.1','2026-11-20 11:54:14',0,NULL,1795175654.3459,'http://localhost/api/v1/Admin/fieldManager/CAttendance/hoursWorked','PUT','Espo',NULL,'8975be1e209554aaf',NULL),('864491943fa475cec',0,'admin','172.18.0.1','2026-11-20 20:34:26',0,NULL,1795206866.6752,'http://localhost/api/v1/EntityManager/action/createEntity','POST','Espo',NULL,'8975be1e209554aaf',NULL),('864a2bb75ee02a0c8',0,'admin','172.18.0.1','2026-11-20 20:35:48',0,NULL,1795206948.0729,'http://localhost/api/v1/CJob','GET','Espo',NULL,'8975be1e209554aaf',NULL),('869e2e7cc76bfbd5f',0,'admin','172.18.0.1','2026-11-20 12:28:59',0,NULL,1795177739.0461,'http://localhost/api/v1/CDailyHours','GET','Espo',NULL,'8975be1e209554aaf',NULL),('86d4d567a4a73ea8a',0,'admin','172.18.0.1','2026-11-20 11:58:19',0,NULL,1795175899.6607,'http://localhost/api/v1/Admin/fieldManager/CWorkOrder','POST','Espo',NULL,'8975be1e209554aaf',NULL),('875fd8539a00638c2',0,'admin','172.18.0.1','2026-11-20 12:44:56',0,NULL,1795178696.376,'http://localhost/api/v1/App/user','GET','Espo',NULL,'8975be1e209554aaf',NULL),('8807274bad98fab3f',0,'admin','100.64.0.29','2026-11-20 12:04:56',0,NULL,1795176296.0217,'http://app-8b34cd0836f1d712.up.railway.app/api/v1/App/user','GET','Espo',NULL,'8975be1e209554aaf','1d374a07680bd894e'),('882e8e1bb64b0db8d',0,'admin','100.64.0.13','2026-11-20 12:35:52',0,NULL,1795178151.9239,'http://app-8b34cd0836f1d712.up.railway.app/api/v1/App/user','GET','Espo',NULL,'8975be1e209554aaf','793034d439ff714f7'),('887066f592263a780',0,'admin','172.18.0.1','2026-11-20 20:35:30',0,NULL,1795206929.9522,'http://localhost/api/v1/CInvoice/d393fc43249460ea6','GET','Espo',NULL,'8975be1e209554aaf',NULL),('89d93b68c560900a1',0,'admin','172.18.0.1','2026-11-20 20:34:47',0,NULL,1795206887.3989,'http://localhost/api/v1/Admin/fieldManager/CPartService','POST','Espo',NULL,'8975be1e209554aaf',NULL),('8a38d09642f6983fe',0,'admin','172.18.0.1','2026-11-20 11:53:19',0,NULL,1795175599.6674,'http://localhost/api/v1/CAttendance','POST','Espo',NULL,'8975be1e209554aaf',NULL),('8bd774231bce3eda6',0,'admin','172.18.0.1','2026-11-20 19:59:47',0,NULL,1795204786.2945,'http://localhost/api/v1/App/user','GET','Espo',NULL,'8975be1e209554aaf',NULL),('8bf6bb2f60691b554',0,'admin','172.18.0.1','2026-11-20 12:28:56',0,NULL,1795177736.3346,'http://localhost/api/v1/CAttendance','GET','Espo',NULL,'8975be1e209554aaf',NULL),('8bfee89e7da82acd1',0,'admin','172.18.0.1','2026-11-20 12:10:45',0,NULL,1795176645.1341,'http://localhost/api/v1/CAMC/layout/detail','PUT','Espo',NULL,'8975be1e209554aaf',NULL),('8c4e18af2e37fda47',0,'admin','172.18.0.1','2026-11-20 11:52:43',0,NULL,1795175563.7493,'http://localhost/api/v1/EntityManager/action/createLink','POST','Espo',NULL,'8975be1e209554aaf',NULL),('8cc8b62002e0e144e',0,'admin','172.18.0.1','2026-11-20 20:34:32',0,NULL,1795206871.914,'http://localhost/api/v1/Admin/fieldManager/CEstimation','POST','Espo',NULL,'8975be1e209554aaf',NULL),('8d2601fc37687dc5a',0,'admin','172.18.0.1','2026-11-20 12:10:30',0,NULL,1795176630.6391,'http://localhost/api/v1/Admin/fieldManager/CAMC','POST','Espo',NULL,'8975be1e209554aaf',NULL),('9086093fa3bf8aa24',0,'admin','172.18.0.1','2026-11-20 12:10:55',0,NULL,1795176655.3579,'http://localhost/api/v1/CAMC','GET','Espo',NULL,'8975be1e209554aaf',NULL),('90dcc1f763c25120e',0,'admin','172.18.0.1','2026-11-20 12:28:32',0,NULL,1795177712.4911,'http://localhost/api/v1/App/user','GET','Espo',NULL,'8975be1e209554aaf',NULL),('9136e72d519813605',0,'admin','172.18.0.1','2026-11-20 11:54:15',0,NULL,1795175654.9259,'http://localhost/api/v1/Admin/fieldManager/CAttendance/notes','PUT','Espo',NULL,'8975be1e209554aaf',NULL),('9434310d154ca088a',0,'admin','172.18.0.1','2026-11-20 11:54:06',0,NULL,1795175646.4869,'http://localhost/api/v1/Admin/fieldManager/CWorkOrder/customerSignatureName','PUT','Espo',NULL,'8975be1e209554aaf',NULL),('956a85cf1a3302b5f',0,'admin','172.18.0.1','2026-11-20 11:52:33',0,NULL,1795175552.7731,'http://localhost/api/v1/Admin/fieldManager/CWorkOrder','POST','Espo',NULL,'8975be1e209554aaf',NULL),('9589e5c4d56711401',0,'admin','172.18.0.1','2026-11-20 12:10:35',0,NULL,1795176635.466,'http://localhost/api/v1/EntityManager/action/createLink','POST','Espo',NULL,'8975be1e209554aaf',NULL),('975a753c4d4699e4d',0,'admin','172.18.0.1','2026-11-20 11:58:23',0,NULL,1795175902.7806,'http://localhost/api/v1/EntityManager/action/createLink','POST','Espo',NULL,'8975be1e209554aaf',NULL),('978fcdd869c72de59',0,'admin','172.18.0.1','2026-11-20 12:45:44',0,NULL,1795178744.5454,'http://localhost/api/v1/Admin/clearCache','POST','Espo',NULL,'8975be1e209554aaf',NULL),('97f3e594a84ce284d',0,'admin','172.18.0.1','2026-11-20 12:16:34',0,NULL,1795176994.3036,'http://localhost/api/v1/CWorkOrder/layout/list','PUT','Espo',NULL,'8975be1e209554aaf',NULL),('992ccb23eaee88383',0,'admin','172.18.0.1','2026-11-20 12:04:39',0,NULL,1795176278.8911,'http://localhost/api/v1/Settings','PUT','Espo',NULL,'8975be1e209554aaf',NULL),('99398762935b77c76',0,'admin','172.18.0.1','2026-11-20 12:28:56',0,NULL,1795177736.5916,'http://localhost/api/v1/CAttendance/66e3ae57755bf451c','PUT','Espo',NULL,'8975be1e209554aaf',NULL),('994f084f31aba8ddf',0,'admin','172.18.0.1','2026-11-20 20:35:04',0,NULL,1795206904.2273,'http://localhost/api/v1/App/user','GET','Espo',NULL,'8975be1e209554aaf',NULL),('996404a9d9dbe2c8b',0,'admin','172.18.0.1','2026-11-20 12:45:43',0,NULL,1795178743.2359,'http://localhost/api/v1/CAttendance/layout/detail','PUT','Espo',NULL,'8975be1e209554aaf',NULL),('99b4c68e01dcfe5c9',0,'admin','172.18.0.1','2026-11-20 12:10:29',0,NULL,1795176629.0595,'http://localhost/api/v1/Admin/fieldManager/CAMC','POST','Espo',NULL,'8975be1e209554aaf',NULL),('9a8f36453537f9f18',0,'admin','172.18.0.1','2026-11-20 12:28:28',0,NULL,1795177707.7663,'http://localhost/api/v1/Admin/fieldManager/CDailyHours','POST','Espo',NULL,'8975be1e209554aaf',NULL),('9ab02c3a0c439a9bf',0,'admin','100.64.0.16','2026-11-20 12:46:19',0,NULL,1795178779.4954,'http://app-8b34cd0836f1d712.up.railway.app/api/v1/App/user','GET','Espo',NULL,'8975be1e209554aaf','fed84cf2612494308'),('9ad5cd9a028d85718',0,'admin','172.18.0.1','2026-11-20 12:04:38',0,NULL,1795176278.6233,'http://localhost/api/v1/App/user','GET','Espo',NULL,'8975be1e209554aaf',NULL),('9b14d346cd5d0425b',0,'admin','100.64.0.11','2026-11-20 12:39:54',0,NULL,1795178393.884,'http://app-8b34cd0836f1d712.up.railway.app/api/v1/App/user','GET','Espo',NULL,'8975be1e209554aaf','2f48ab220d2a1aac7'),('9c57b5d217d738a73',0,'admin','172.18.0.1','2026-11-20 20:35:02',0,NULL,1795206902.595,'http://localhost/api/v1/CEstimation/layout/detail','PUT','Espo',NULL,'8975be1e209554aaf',NULL),('9ca2a7ed3233556a3',0,'admin','172.18.0.1','2026-11-20 20:35:03',0,NULL,1795206903.6858,'http://localhost/api/v1/CPartService/layout/detail','PUT','Espo',NULL,'8975be1e209554aaf',NULL),('9cc313be79fbacd2e',0,'admin','172.18.0.1','2026-11-20 20:34:49',0,NULL,1795206889.7398,'http://localhost/api/v1/EntityManager/action/createLink','POST','Espo',NULL,'8975be1e209554aaf',NULL),('9ce7909c89d06da99',0,'admin','172.18.0.1','2026-11-20 20:35:31',0,NULL,1795206931.7224,'http://localhost/api/v1/CJob/9b77a6adb5eeeeada/estimations','GET','Espo',NULL,'8975be1e209554aaf',NULL),('9ced91240b457127f',0,'admin','172.18.0.1','2026-11-20 11:53:19',0,NULL,1795175599.1382,'http://localhost/api/v1/App/user','GET','Espo',NULL,'8975be1e209554aaf',NULL),('9d2db93850c3839d4',0,'admin','172.18.0.1','2026-11-20 11:53:06',0,NULL,1795175585.8484,'http://localhost/api/v1/Admin/rebuild','POST','Espo',NULL,'8975be1e209554aaf',NULL),('9ef8f1513fe406451',0,'admin','172.18.0.1','2026-11-20 12:16:26',0,NULL,1795176986.5316,'http://localhost/api/v1/Admin/fieldManager/CJob','POST','Espo',NULL,'8975be1e209554aaf',NULL),('a05745a0a4d07be9f',0,'admin','172.18.0.1','2026-11-20 20:34:45',0,NULL,1795206885.4715,'http://localhost/api/v1/Admin/fieldManager/CPartService','POST','Espo',NULL,'8975be1e209554aaf',NULL),('a122435bccbb94539',0,'admin','172.18.0.1','2026-11-20 12:16:30',0,NULL,1795176990.4587,'http://localhost/api/v1/EntityManager/action/createLink','POST','Espo',NULL,'8975be1e209554aaf',NULL),('a1489272a102ad776',0,'admin','172.18.0.1','2026-11-20 11:53:28',0,NULL,1795175607.8189,'http://localhost/api/v1/App/user','GET','Espo',NULL,'8975be1e209554aaf',NULL),('a1786607370de4d0c',0,'admin','172.18.0.1','2026-11-20 12:28:24',0,NULL,1795177704.0443,'http://localhost/api/v1/EntityManager/action/createEntity','POST','Espo',NULL,'8975be1e209554aaf',NULL),('a220e0340d197a04f',0,'admin','172.18.0.1','2026-11-20 11:52:35',0,NULL,1795175555.2359,'http://localhost/api/v1/Admin/fieldManager/CAttendance','POST','Espo',NULL,'8975be1e209554aaf',NULL),('a2f3a0dd2123f4f48',0,'admin','172.18.0.1','2026-11-20 11:58:21',0,NULL,1795175901.4035,'http://localhost/api/v1/EntityManager/action/createLink','POST','Espo',NULL,'8975be1e209554aaf',NULL),('a32968558286e8e46',0,'admin','172.18.0.1','2026-11-20 20:35:32',0,NULL,1795206931.9379,'http://localhost/api/v1/CJob/9b77a6adb5eeeeada/invoices','GET','Espo',NULL,'8975be1e209554aaf',NULL),('a41ab12cdcbfaf1b5',0,'admin','172.18.0.1','2026-11-20 11:52:27',0,NULL,1795175547.7118,'http://localhost/api/v1/Admin/fieldManager/CWorkOrder','POST','Espo',NULL,'8975be1e209554aaf',NULL),('a53f09c53f824814e',0,'admin','172.18.0.1','2026-11-20 12:16:42',0,NULL,1795177002.0513,'http://localhost/api/v1/CAMC','GET','Espo',NULL,'8975be1e209554aaf',NULL),('a58e7f9adc6d004e1',0,'admin','172.18.0.1','2026-11-20 20:34:30',0,NULL,1795206870.5799,'http://localhost/api/v1/Admin/fieldManager/CEstimation','POST','Espo',NULL,'8975be1e209554aaf',NULL),('a5bb39979443fd811',0,'admin','172.18.0.1','2026-11-20 20:34:37',0,NULL,1795206877.693,'http://localhost/api/v1/Admin/fieldManager/CInvoice','POST','Espo',NULL,'8975be1e209554aaf',NULL),('a6693062b9c26f48c',0,'admin','100.64.0.5','2026-11-20 12:39:57',0,NULL,1795178397.0502,'http://app-8b34cd0836f1d712.up.railway.app/api/v1/CAttendance/66e3ae57755bf451c','PUT','Espo',NULL,'8975be1e209554aaf','eb9a534dbac9e0c53'),('a76fabf6378e502e4',0,'admin','172.18.0.1','2026-11-20 12:16:33',0,NULL,1795176993.4181,'http://localhost/api/v1/CJob/layout/detail','PUT','Espo',NULL,'8975be1e209554aaf',NULL),('a8ad383f73770f065',0,'admin','100.64.0.9','2026-11-20 12:40:37',0,NULL,1795178436.9353,'http://app-8b34cd0836f1d712.up.railway.app/api/v1/CAttendance/bac44286bee36cd47','PUT','Espo',NULL,'8975be1e209554aaf','bfcd331482a98c566'),('aa9cb7bc599ba94a2',0,'admin','172.18.0.1','2026-11-20 12:28:32',0,NULL,1795177712.729,'http://localhost/api/v1/Settings','PUT','Espo',NULL,'8975be1e209554aaf',NULL),('aaa4eabc402e13441',0,'sales1','100.64.0.2','2026-11-20 19:20:34',0,NULL,1795202434.3678,'http://app-8b34cd0836f1d712.up.railway.app/api/v1/App/user','GET','Espo',NULL,'3a9d2245f7f443cd5','3c076e87c113b5ad8'),('aaf8a693d2619cb12',0,'admin','100.64.0.3','2026-11-20 12:39:58',0,NULL,1795178397.7702,'http://app-8b34cd0836f1d712.up.railway.app/api/v1/CAttendance','GET','Espo',NULL,'8975be1e209554aaf','a54e41429cda29ca5'),('ab795b29c3ed1354b',0,'admin','172.18.0.1','2026-11-20 11:58:20',0,NULL,1795175900.3094,'http://localhost/api/v1/Admin/fieldManager/CWorkOrder/dateStart','PUT','Espo',NULL,'8975be1e209554aaf',NULL),('abcb5bd4a4c59bacc',0,'admin','172.18.0.1','2026-11-20 12:10:46',0,NULL,1795176646.4442,'http://localhost/api/v1/Account','GET','Espo',NULL,'8975be1e209554aaf',NULL),('abd3752ce3c3162a0',0,'admin','172.18.0.1','2026-11-20 20:35:29',0,NULL,1795206928.9885,'http://localhost/api/v1/CInvoice','POST','Espo',NULL,'8975be1e209554aaf',NULL),('acb99f005e378ac15',0,'admin','172.18.0.1','2026-11-20 20:34:39',0,NULL,1795206879.1943,'http://localhost/api/v1/Admin/fieldManager/CInvoice','POST','Espo',NULL,'8975be1e209554aaf',NULL),('ad610d11c9b5282e1',0,'admin','172.18.0.1','2026-11-20 12:36:12',0,NULL,1795178172.5816,'http://localhost/api/v1/Settings','PUT','Espo',NULL,'8975be1e209554aaf',NULL),('ad6c932739975afd4',0,'admin','172.18.0.1','2026-11-20 12:28:57',0,NULL,1795177737.0685,'http://localhost/api/v1/CAttendance/3d1bcfdd0d782c3e7','PUT','Espo',NULL,'8975be1e209554aaf',NULL),('ae7f55a00f3e314a7',0,'admin','172.18.0.1','2026-11-20 12:10:37',0,NULL,1795176637.5149,'http://localhost/api/v1/EntityManager/action/formula','POST','Espo',NULL,'8975be1e209554aaf',NULL),('aec4ad6f7b057e26f',0,'admin','172.18.0.1','2026-11-20 12:10:30',0,NULL,1795176629.7926,'http://localhost/api/v1/Admin/fieldManager/CAMC','POST','Espo',NULL,'8975be1e209554aaf',NULL),('aed101cd3983a2dc8',0,'admin','172.18.0.1','2026-11-20 12:47:19',0,NULL,1795178839.6083,'http://localhost/api/v1/Preferences/8975be1e209554aaf','PUT','Espo',NULL,'8975be1e209554aaf',NULL),('af6f516bb82c291d8',0,'admin','172.18.0.1','2026-11-20 20:35:39',0,NULL,1795206939.5796,'http://localhost/api/v1/CInvoice/d393fc43249460ea6','GET','Espo',NULL,'8975be1e209554aaf',NULL),('b130c50a83839b551',0,'admin','172.18.0.1','2026-11-20 11:53:06',0,NULL,1795175586.5703,'http://localhost/api/v1/Admin/rebuild','POST','Espo',NULL,'8975be1e209554aaf',NULL),('b18dd47d179afec3c',0,'admin','172.18.0.1','2026-11-20 11:52:29',0,NULL,1795175549.0391,'http://localhost/api/v1/Admin/fieldManager/CWorkOrder','POST','Espo',NULL,'8975be1e209554aaf',NULL),('b25a27e8244b76b51',0,'admin','172.18.0.1','2026-11-20 12:04:34',0,NULL,1795176273.8726,'http://localhost/api/v1/App/user','GET','Espo',NULL,'8975be1e209554aaf',NULL),('b4334d08a84a34f4f',0,'admin','100.64.0.6','2026-11-20 11:13:18',1,'CREDENTIALS',1795173198.7006,'http://app-8b34cd0836f1d712.up.railway.app/api/v1/App/user','GET','Espo',NULL,NULL,NULL),('b470b8b7374cda39f',0,'admin','172.18.0.1','2026-11-20 12:10:28',0,NULL,1795176628.3352,'http://localhost/api/v1/Admin/fieldManager/CAMC','POST','Espo',NULL,'8975be1e209554aaf',NULL),('b4e8737909cdd251a',0,'admin','172.18.0.1','2026-11-20 20:34:52',0,NULL,1795206892.0109,'http://localhost/api/v1/EntityManager/action/createLink','POST','Espo',NULL,'8975be1e209554aaf',NULL),('b50ca2b08c49e2c53',0,'admin','100.64.0.8','2026-11-20 12:40:34',0,NULL,1795178433.9734,'http://app-8b34cd0836f1d712.up.railway.app/api/v1/CAttendance','POST','Espo',NULL,'8975be1e209554aaf','b881e63e93c44e013'),('b529626d77786b60a',0,'admin','172.18.0.1','2026-11-20 12:45:43',0,NULL,1795178742.9083,'http://localhost/api/v1/EntityManager/action/formula','POST','Espo',NULL,'8975be1e209554aaf',NULL),('b6b9332598cbf2c4b',0,'admin','172.18.0.1','2026-11-20 20:35:17',0,NULL,1795206917.604,'http://localhost/api/v1/Admin/clearCache','POST','Espo',NULL,'8975be1e209554aaf',NULL),('b89a345a6c500f39b',0,'admin','172.18.0.1','2026-11-20 11:52:36',0,NULL,1795175555.908,'http://localhost/api/v1/Admin/fieldManager/CAttendance','POST','Espo',NULL,'8975be1e209554aaf',NULL),('b9001cffa30ad0d2d',0,'admin','172.18.0.1','2026-11-20 12:28:27',0,NULL,1795177706.8851,'http://localhost/api/v1/Admin/fieldManager/CDailyHours','POST','Espo',NULL,'8975be1e209554aaf',NULL),('b9143c30646cf0fe9',0,'admin','172.18.0.1','2026-11-20 20:35:33',0,NULL,1795206933.0635,'http://localhost/api/v1/CAMC/2d70128fccb163450/estimations','GET','Espo',NULL,'8975be1e209554aaf',NULL),('b91e282355f4743ca',0,'admin','172.18.0.1','2026-11-20 20:34:42',0,NULL,1795206882.7178,'http://localhost/api/v1/Admin/fieldManager/CInvoice','POST','Espo',NULL,'8975be1e209554aaf',NULL),('b95d3e1d6f44a3e40',0,'admin','172.18.0.1','2026-11-20 20:34:37',0,NULL,1795206876.9366,'http://localhost/api/v1/Admin/fieldManager/CInvoice','POST','Espo',NULL,'8975be1e209554aaf',NULL),('b9974aef00c147b83',0,'admin','172.18.0.1','2026-11-20 11:52:31',0,NULL,1795175551.1463,'http://localhost/api/v1/Admin/fieldManager/CWorkOrder','POST','Espo',NULL,'8975be1e209554aaf',NULL),('b9c636ab6079c5914',0,'admin','172.18.0.1','2026-11-20 11:53:15',0,NULL,1795175595.0089,'http://localhost/api/v1/App/user','GET','Espo',NULL,'8975be1e209554aaf',NULL),('ba206d01d6f8d7fc1',0,'admin','100.64.0.6','2026-11-20 12:39:56',0,NULL,1795178396.4403,'http://app-8b34cd0836f1d712.up.railway.app/api/v1/CAttendance','GET','Espo',NULL,'8975be1e209554aaf','e3ab78114e3e7cf4c'),('ba2533ee3b450d40f',0,'admin','172.18.0.1','2026-11-20 11:55:32',0,NULL,1795175731.7592,'http://localhost/api/v1/Admin/clearCache','POST','Espo',NULL,'8975be1e209554aaf',NULL),('baae291fa0bb46622',0,'admin','172.18.0.1','2026-11-20 12:28:59',0,NULL,1795177738.8086,'http://localhost/api/v1/CAttendance/5cf9a1253b321c9ae','DELETE','Espo',NULL,'8975be1e209554aaf',NULL),('bb7e0eb6c0a9c68da',0,'admin','172.18.0.1','2026-11-20 12:48:09',0,NULL,1795178889.0487,'http://localhost/api/v1/Preferences/8975be1e209554aaf','PUT','Espo',NULL,'8975be1e209554aaf',NULL),('bbe0725142cbdef5c',0,'admin','172.18.0.1','2026-11-20 12:10:33',0,NULL,1795176633.2242,'http://localhost/api/v1/Admin/fieldManager/CAMC','POST','Espo',NULL,'8975be1e209554aaf',NULL),('bd5d1124724a37918',0,'admin','172.18.0.1','2026-11-20 11:53:27',0,NULL,1795175607.1405,'http://localhost/api/v1/EntityManager/action/formula','POST','Espo',NULL,'8975be1e209554aaf',NULL),('bdc3fd6ef06d092f2',0,'admin','172.18.0.1','2026-11-20 11:58:18',0,NULL,1795175897.941,'http://localhost/api/v1/Admin/fieldManager/CWorkOrder','POST','Espo',NULL,'8975be1e209554aaf',NULL),('beaeda6d09f2a3633',0,'admin','172.18.0.1','2026-11-20 12:10:45',0,NULL,1795176645.5686,'http://localhost/api/v1/CAMC/layout/list','PUT','Espo',NULL,'8975be1e209554aaf',NULL),('bec81e0ea037333dd',0,'admin','172.18.0.1','2026-11-20 12:16:35',0,NULL,1795176994.8268,'http://localhost/api/v1/Settings','PUT','Espo',NULL,'8975be1e209554aaf',NULL),('bf0b8a06cc5a7b90b',0,'admin','100.64.0.8','2026-11-20 12:02:07',0,NULL,1795176127.0346,'http://app-8b34cd0836f1d712.up.railway.app/api/v1/App/user','GET','Espo',NULL,'8975be1e209554aaf','83714450691835a6d'),('bfac8c79307cca7a5',0,'admin','172.18.0.1','2026-11-20 11:53:32',0,NULL,1795175612.005,'http://localhost/api/v1/CAttendance','GET','Espo',NULL,'8975be1e209554aaf',NULL),('bfb616935928b0eed',0,'admin','100.64.0.1','2026-11-20 11:13:33',0,NULL,1795173213.4212,'http://app-8b34cd0836f1d712.up.railway.app/api/v1/App/user','GET','Espo',NULL,'8975be1e209554aaf','358da851518a0b673'),('bfef52128563be0c5',0,'admin','172.18.0.1','2026-11-20 11:52:45',0,NULL,1795175565.3191,'http://localhost/api/v1/EntityManager/action/createLink','POST','Espo',NULL,'8975be1e209554aaf',NULL),('c04a2378ccd71833c',0,'admin','172.18.0.1','2026-11-20 11:58:03',0,NULL,1795175883.1327,'http://localhost/api/v1/EntityManager/action/removeLink','POST','Espo',NULL,'8975be1e209554aaf',NULL),('c05b5ab2e26587ea3',0,'admin','172.18.0.1','2026-11-20 20:35:27',0,NULL,1795206926.952,'http://localhost/api/v1/CAMC','POST','Espo',NULL,'8975be1e209554aaf',NULL),('c05be8a71a3937f38',0,'admin','172.18.0.1','2026-11-20 11:54:11',0,NULL,1795175651.3275,'http://localhost/api/v1/Admin/fieldManager/CAttendance/checkInLat','PUT','Espo',NULL,'8975be1e209554aaf',NULL),('c07b1ef02d3bce637',0,'admin','172.18.0.1','2026-11-20 12:16:25',0,NULL,1795176984.9514,'http://localhost/api/v1/Admin/fieldManager/CJob','POST','Espo',NULL,'8975be1e209554aaf',NULL),('c1778a2a4b71c0c57',0,'admin','172.18.0.1','2026-11-20 20:34:42',0,NULL,1795206882.0596,'http://localhost/api/v1/Admin/fieldManager/CInvoice','POST','Espo',NULL,'8975be1e209554aaf',NULL),('c196ed03ffcf93e25',0,'admin','172.18.0.1','2026-11-20 11:58:34',0,NULL,1795175914.0172,'http://localhost/api/v1/CAttendance/layout/list','PUT','Espo',NULL,'8975be1e209554aaf',NULL),('c28ece90422ce7b35',0,'admin','100.64.0.17','2026-11-20 11:53:48',0,NULL,1795175628.1492,'http://app-8b34cd0836f1d712.up.railway.app/api/v1/App/user','GET','Espo',NULL,'8975be1e209554aaf','08f9050a5c8ea25b4'),('c297aff4042c78381',0,'admin','172.18.0.1','2026-11-20 20:35:48',0,NULL,1795206948.7786,'http://localhost/api/v1/CAMC','GET','Espo',NULL,'8975be1e209554aaf',NULL),('c2d2817d44f75606d',0,'admin','172.18.0.1','2026-11-20 12:00:30',0,NULL,1795176029.9755,'http://localhost/api/v1/App/user','GET','Espo',NULL,'8975be1e209554aaf',NULL),('c337dddd3a07c7659',0,'admin','100.64.0.11','2026-11-20 12:40:36',0,NULL,1795178436.3269,'http://app-8b34cd0836f1d712.up.railway.app/api/v1/CAttendance','GET','Espo',NULL,'8975be1e209554aaf','b8307bba23bb9cac4'),('c3520887e457459a9',0,'admin','172.18.0.1','2026-11-20 20:34:40',0,NULL,1795206880.5474,'http://localhost/api/v1/Admin/fieldManager/CInvoice','POST','Espo',NULL,'8975be1e209554aaf',NULL),('c377c97d7c3e6652a',0,'admin','172.18.0.1','2026-11-20 12:10:45',0,NULL,1795176645.7748,'http://localhost/api/v1/CWorkOrder/layout/detail','PUT','Espo',NULL,'8975be1e209554aaf',NULL),('c38377691dbf627d8',0,'admin','172.18.0.1','2026-11-20 11:52:41',0,NULL,1795175561.4435,'http://localhost/api/v1/Admin/fieldManager/CAttendance','POST','Espo',NULL,'8975be1e209554aaf',NULL),('c3ede377d24a54cb0',0,'admin','172.18.0.1','2026-11-20 12:28:31',0,NULL,1795177711.4246,'http://localhost/api/v1/EntityManager/action/createLink','POST','Espo',NULL,'8975be1e209554aaf',NULL),('c4289f6b11a57d8fd',0,'admin','100.64.0.29','2026-11-20 12:00:49',0,NULL,1795176049.1928,'http://app-8b34cd0836f1d712.up.railway.app/api/v1/App/user','GET','Espo',NULL,'8975be1e209554aaf','60519d6eccf2cb9ed'),('c461739d4c46e963b',0,'admin','172.18.0.1','2026-11-20 11:58:24',0,NULL,1795175903.9529,'http://localhost/api/v1/Metadata','GET','Espo',NULL,'8975be1e209554aaf',NULL),('c4df400812bcca492',0,'sales1','100.64.0.10','2026-11-20 19:29:53',0,NULL,1795202992.8937,'http://app-8b34cd0836f1d712.up.railway.app/api/v1/App/user','GET','Espo',NULL,'3a9d2245f7f443cd5','0d41473af61914185'),('c7e64c1f924ef0d24',0,'admin','172.18.0.1','2026-11-20 12:10:46',0,NULL,1795176645.9812,'http://localhost/api/v1/App/user','GET','Espo',NULL,'8975be1e209554aaf',NULL),('c86327dab3dcd8a9e',0,'admin','172.18.0.1','2026-11-20 20:34:25',0,NULL,1795206865.266,'http://localhost/api/v1/EntityManager/action/createEntity','POST','Espo',NULL,'8975be1e209554aaf',NULL),('c8b30e6e67e6b82b1',0,'admin','172.18.0.1','2026-11-20 12:10:34',0,NULL,1795176634.7544,'http://localhost/api/v1/Admin/fieldManager/CAMC','POST','Espo',NULL,'8975be1e209554aaf',NULL),('c8ea6304b38e0b43f',0,'admin','172.18.0.1','2026-11-20 12:10:36',0,NULL,1795176636.1568,'http://localhost/api/v1/EntityManager/action/createLink','POST','Espo',NULL,'8975be1e209554aaf',NULL),('c90bf919c177df1e9',0,'admin','172.18.0.1','2026-11-20 11:58:35',0,NULL,1795175915.1646,'http://localhost/api/v1/App/user','GET','Espo',NULL,'8975be1e209554aaf',NULL),('c90d7024e2ad3e2ee',0,'admin','172.18.0.1','2026-11-20 11:58:16',0,NULL,1795175896.5179,'http://localhost/api/v1/Admin/fieldManager/CWorkOrder','POST','Espo',NULL,'8975be1e209554aaf',NULL),('c93fd4218bd16a5b6',0,'admin','172.18.0.1','2026-11-20 11:54:05',0,NULL,1795175645.3265,'http://localhost/api/v1/Admin/fieldManager/CWorkOrder/actualEnd','PUT','Espo',NULL,'8975be1e209554aaf',NULL),('c97a250e78ee841df',0,'admin','172.18.0.1','2026-11-20 11:53:14',0,NULL,1795175594.7711,'http://localhost/api/v1/Account','POST','Espo',NULL,'8975be1e209554aaf',NULL),('c9f4f27a809b793fd',0,'admin','172.18.0.1','2026-11-20 11:53:28',0,NULL,1795175608.687,'http://localhost/api/v1/CWorkOrder','GET','Espo',NULL,'8975be1e209554aaf',NULL),('ca2bd544ccf1cd949',0,'admin','172.18.0.1','2026-11-20 12:10:47',0,NULL,1795176647.2769,'http://localhost/api/v1/CWorkOrder/76b672d24f8bb255e','PUT','Espo',NULL,'8975be1e209554aaf',NULL),('ca366e17270fc5cf9',0,'admin','172.18.0.1','2026-11-20 11:54:08',0,NULL,1795175648.3231,'http://localhost/api/v1/Admin/fieldManager/CWorkOrder/description','PUT','Espo',NULL,'8975be1e209554aaf',NULL),('ca41d04b71d447bfd',0,'admin','172.18.0.1','2026-11-20 17:08:03',0,NULL,1795194482.8699,'http://localhost/api/v1/App/user','GET','Espo',NULL,'8975be1e209554aaf',NULL),('caa220ee4ae3d2e67',0,'admin','172.18.0.1','2026-11-20 20:35:47',0,NULL,1795206947.5485,'http://localhost/api/v1/CJob','GET','Espo',NULL,'8975be1e209554aaf',NULL),('cb73dca8681ccab20',0,'admin','172.18.0.1','2026-11-20 20:34:48',0,NULL,1795206888.27,'http://localhost/api/v1/Admin/fieldManager/CPartService','POST','Espo',NULL,'8975be1e209554aaf',NULL),('cbcc239948fb510c2',0,'admin','172.18.0.1','2026-11-20 20:34:27',0,NULL,1795206867.3169,'http://localhost/api/v1/EntityManager/action/createEntity','POST','Espo',NULL,'8975be1e209554aaf',NULL),('cda03f9d69bd43d97',0,'admin','172.18.0.1','2026-11-20 11:54:07',0,NULL,1795175647.1608,'http://localhost/api/v1/Admin/fieldManager/CWorkOrder/laborCost','PUT','Espo',NULL,'8975be1e209554aaf',NULL),('cdae1484eb00ee4b4',0,'admin','172.18.0.1','2026-11-20 12:16:33',0,NULL,1795176993.0114,'http://localhost/api/v1/EntityManager/action/formula','POST','Espo',NULL,'8975be1e209554aaf',NULL),('ce08c19291a1bc14c',0,'admin','172.18.0.1','2026-11-20 12:16:31',0,NULL,1795176991.2073,'http://localhost/api/v1/EntityManager/action/createLink','POST','Espo',NULL,'8975be1e209554aaf',NULL),('ce0bfcbd27f3115dc',0,'admin','172.18.0.1','2026-11-20 12:10:56',0,NULL,1795176656.0396,'http://localhost/api/v1/CAMC/d766f3eec4a784423','PUT','Espo',NULL,'8975be1e209554aaf',NULL),('ce79551310d57bc1a',0,'admin','172.18.0.1','2026-11-20 12:28:30',0,NULL,1795177710.7353,'http://localhost/api/v1/EntityManager/action/createLink','POST','Espo',NULL,'8975be1e209554aaf',NULL),('cefc19032700ee1c4',0,'admin','172.18.0.1','2026-11-20 12:16:34',0,NULL,1795176993.8641,'http://localhost/api/v1/CJob/layout/list','PUT','Espo',NULL,'8975be1e209554aaf',NULL),('cf04f7b7a0b8f778c',0,'admin','172.18.0.1','2026-11-20 20:35:29',0,NULL,1795206929.6996,'http://localhost/api/v1/CPartService/6f8e92f43265d908e','PUT','Espo',NULL,'8975be1e209554aaf',NULL),('cfa1a076660b41859',0,'admin','172.18.0.1','2026-11-20 20:35:04',0,NULL,1795206903.9818,'http://localhost/api/v1/CPartService/layout/list','PUT','Espo',NULL,'8975be1e209554aaf',NULL),('cff5ed188a4051e69',0,'admin','172.18.0.1','2026-11-20 11:54:01',0,NULL,1795175641.1311,'http://localhost/api/v1/Admin/fieldManager/CWorkOrder/status','PUT','Espo',NULL,'8975be1e209554aaf',NULL),('d178ae460d6edb27a',0,'admin','172.18.0.1','2026-11-20 12:16:34',0,NULL,1795176994.0852,'http://localhost/api/v1/CWorkOrder/layout/detail','PUT','Espo',NULL,'8975be1e209554aaf',NULL),('d198ef0883eafe384',0,'admin','172.18.0.1','2026-11-20 12:28:59',0,NULL,1795177739.2529,'http://localhost/api/v1/CAttendance','GET','Espo',NULL,'8975be1e209554aaf',NULL),('d25b361d4d45310a8',0,'admin','172.18.0.1','2026-11-20 12:28:58',0,NULL,1795177737.784,'http://localhost/api/v1/CAttendance/343d90807238b187e','PUT','Espo',NULL,'8975be1e209554aaf',NULL),('d2b01f2c8fdb1f64d',0,'admin','172.18.0.1','2026-11-20 20:34:54',0,NULL,1795206893.7527,'http://localhost/api/v1/EntityManager/action/createLink','POST','Espo',NULL,'8975be1e209554aaf',NULL),('d2e0998fcfc781964',0,'admin','172.18.0.1','2026-11-20 12:10:26',0,NULL,1795176625.8393,'http://localhost/api/v1/Admin/fieldManager/CAMC','POST','Espo',NULL,'8975be1e209554aaf',NULL),('d3ba35a6cc6f15b65',0,'admin','172.18.0.1','2026-11-20 11:53:11',0,NULL,1795175591.6639,'http://localhost/api/v1/App/user','GET','Espo',NULL,'8975be1e209554aaf',NULL),('d3c8ca779aa3c8df2',0,'admin','172.18.0.1','2026-11-20 12:16:29',0,NULL,1795176989.6212,'http://localhost/api/v1/EntityManager/action/createLink','POST','Espo',NULL,'8975be1e209554aaf',NULL),('d4720229c0d39aacc',0,'admin','172.18.0.1','2026-11-20 11:52:02',0,NULL,1795175521.6917,'http://localhost/api/v1/EntityManager/action/createEntity','POST','Espo',NULL,'8975be1e209554aaf',NULL),('d4d6426601bfe55ce',0,'admin','172.18.0.1','2026-11-20 11:52:34',0,NULL,1795175554.5036,'http://localhost/api/v1/Admin/fieldManager/CAttendance','POST','Espo',NULL,'8975be1e209554aaf',NULL),('d5906dddc78e1cc2c',0,'admin','172.18.0.1','2026-11-20 20:35:28',0,NULL,1795206928.1733,'http://localhost/api/v1/CPartService','POST','Espo',NULL,'8975be1e209554aaf',NULL),('d5cfa47eda071f966',0,'admin','172.18.0.1','2026-11-20 12:45:49',0,NULL,1795178749.7298,'http://localhost/api/v1/CAttendance','GET','Espo',NULL,'8975be1e209554aaf',NULL),('d617d42beb5e0844f',0,'admin','172.18.0.1','2026-11-20 11:54:02',0,NULL,1795175641.7911,'http://localhost/api/v1/Admin/fieldManager/CWorkOrder/priority','PUT','Espo',NULL,'8975be1e209554aaf',NULL),('d76a102f9ba22ac21',0,'admin','172.18.0.1','2026-11-20 11:54:09',0,NULL,1795175649.6405,'http://localhost/api/v1/Admin/fieldManager/CAttendance/checkIn','PUT','Espo',NULL,'8975be1e209554aaf',NULL),('d7845747f9f404342',0,'admin','172.18.0.1','2026-11-20 20:35:47',0,NULL,1795206947.0971,'http://localhost/api/v1/CWorkOrder/9256dd2bc6c0ed35e','DELETE','Espo',NULL,'8975be1e209554aaf',NULL),('d97726375a78f5cab',0,'admin','172.18.0.1','2026-11-20 12:11:40',0,NULL,1795176699.8446,'http://localhost/api/v1/App/user','GET','Espo',NULL,'8975be1e209554aaf',NULL),('da2f8b19ef958701b',0,'admin','172.18.0.1','2026-11-20 20:35:49',0,NULL,1795206949.2035,'http://localhost/api/v1/Account/f3041c7f637e8df79','DELETE','Espo',NULL,'8975be1e209554aaf',NULL),('daa83491d34a0ab11',0,'admin','172.18.0.1','2026-11-20 20:35:45',0,NULL,1795206945.2784,'http://localhost/api/v1/CPartService','GET','Espo',NULL,'8975be1e209554aaf',NULL),('dac2f460139671dab',0,'admin','172.18.0.1','2026-11-20 20:34:29',0,NULL,1795206868.9152,'http://localhost/api/v1/Admin/fieldManager/CEstimation','POST','Espo',NULL,'8975be1e209554aaf',NULL),('dbfaffecbcd5f0f39',0,'admin','172.18.0.1','2026-11-20 14:13:20',0,NULL,1795183999.1172,'http://localhost/api/v1/App/user','GET','Espo',NULL,'8975be1e209554aaf',NULL),('dcea7e9a9e382f69e',0,'admin','172.18.0.1','2026-11-20 11:58:18',0,NULL,1795175898.5349,'http://localhost/api/v1/Admin/fieldManager/CWorkOrder','POST','Espo',NULL,'8975be1e209554aaf',NULL),('dcf94fc9773f9d7b4',0,'admin','172.18.0.1','2026-11-20 11:53:04',0,NULL,1795175583.9331,'http://localhost/api/v1/CWorkOrder/layout/list','PUT','Espo',NULL,'8975be1e209554aaf',NULL),('dd22a49e92e0b30c7',0,'admin','172.18.0.1','2026-11-20 20:35:29',0,NULL,1795206929.4539,'http://localhost/api/v1/CPartService/9bbc99d1aaa7e1a4b','PUT','Espo',NULL,'8975be1e209554aaf',NULL),('dd34fbb452664d4b8',0,'admin','172.18.0.1','2026-11-20 11:53:04',0,NULL,1795175584.1626,'http://localhost/api/v1/CAttendance/layout/detail','PUT','Espo',NULL,'8975be1e209554aaf',NULL),('dde6591d25eb01513',0,'admin','172.18.0.1','2026-11-20 20:35:28',0,NULL,1795206928.507,'http://localhost/api/v1/CPartService','POST','Espo',NULL,'8975be1e209554aaf',NULL),('ded758a0368348a28',0,'admin','172.18.0.1','2026-11-20 12:45:44',0,NULL,1795178744.2718,'http://localhost/api/v1/Settings','PUT','Espo',NULL,'8975be1e209554aaf',NULL),('df0cf48a37afa1165',0,'admin','172.18.0.1','2026-11-20 20:34:38',0,NULL,1795206878.463,'http://localhost/api/v1/Admin/fieldManager/CInvoice','POST','Espo',NULL,'8975be1e209554aaf',NULL),('df1cbc3cf67cec1bc',0,'admin','172.18.0.1','2026-11-20 12:28:58',0,NULL,1795177738.3103,'http://localhost/api/v1/CAttendance','POST','Espo',NULL,'8975be1e209554aaf',NULL),('df4e81f9da6a2a395',0,'admin','172.18.0.1','2026-11-20 11:54:13',0,NULL,1795175653.6172,'http://localhost/api/v1/Admin/fieldManager/CAttendance/checkOutLng','PUT','Espo',NULL,'8975be1e209554aaf',NULL),('dfb1312aa0fab953f',0,'admin','172.18.0.1','2026-11-20 11:54:04',0,NULL,1795175643.9872,'http://localhost/api/v1/Admin/fieldManager/CWorkOrder/scheduledEnd','PUT','Espo',NULL,'8975be1e209554aaf',NULL),('dfe363b7c26334f1d',0,'admin','100.64.0.11','2026-11-20 12:39:54',0,NULL,1795178394.7017,'http://app-8b34cd0836f1d712.up.railway.app/api/v1/CAttendance','GET','Espo',NULL,'8975be1e209554aaf','fe2d0aa955b6c12a8'),('e04e82496b20ba667',0,'admin','172.18.0.1','2026-11-20 20:35:46',0,NULL,1795206946.1936,'http://localhost/api/v1/CEstimation','GET','Espo',NULL,'8975be1e209554aaf',NULL),('e076c3949f0c96cf4',0,'admin','172.18.0.1','2026-11-20 20:34:35',0,NULL,1795206875.1274,'http://localhost/api/v1/Admin/fieldManager/CInvoice','POST','Espo',NULL,'8975be1e209554aaf',NULL),('e150424ee72a27249',0,'admin','172.18.0.1','2026-11-20 12:16:29',0,NULL,1795176988.9418,'http://localhost/api/v1/Admin/fieldManager/CJob','POST','Espo',NULL,'8975be1e209554aaf',NULL),('e22672c867dad5569',0,'admin','100.64.0.26','2026-11-20 12:01:17',0,NULL,1795176076.9,'http://app-8b34cd0836f1d712.up.railway.app/api/v1/CAttendance','GET','Espo',NULL,'8975be1e209554aaf','0f28b5ca1627ea939'),('e2ac9cd28a0f64dc2',0,'admin','172.18.0.1','2026-11-20 20:35:04',0,NULL,1795206904.5249,'http://localhost/api/v1/Settings','PUT','Espo',NULL,'8975be1e209554aaf',NULL),('e46294d4578ff482e',0,'admin','172.18.0.1','2026-11-20 20:35:30',0,NULL,1795206930.4751,'http://localhost/api/v1/CInvoice/d393fc43249460ea6','GET','Espo',NULL,'8975be1e209554aaf',NULL),('e49f17b6f2e5ed51a',0,'admin','172.18.0.1','2026-11-20 12:45:43',0,NULL,1795178743.5265,'http://localhost/api/v1/CAttendance/layout/list','PUT','Espo',NULL,'8975be1e209554aaf',NULL),('e4e47196362e70def',0,'admin','172.18.0.1','2026-11-20 11:53:05',0,NULL,1795175585.4532,'http://localhost/api/v1/Settings','PUT','Espo',NULL,'8975be1e209554aaf',NULL),('e4ffd4899e2a8b9e0',0,'admin','172.18.0.1','2026-11-20 11:53:03',0,NULL,1795175583.6973,'http://localhost/api/v1/CWorkOrder/layout/detail','PUT','Espo',NULL,'8975be1e209554aaf',NULL),('e54d361aa4374b14c',0,'admin','172.18.0.1','2026-11-20 20:34:34',0,NULL,1795206874.0338,'http://localhost/api/v1/Admin/fieldManager/CEstimation','POST','Espo',NULL,'8975be1e209554aaf',NULL),('e58340916ae6380d8',0,'admin','172.18.0.1','2026-11-20 11:58:51',0,NULL,1795175930.9466,'http://localhost/api/v1/App/user','GET','Espo',NULL,'8975be1e209554aaf',NULL),('e5f97260008598201',0,'admin','172.18.0.1','2026-11-20 20:35:26',0,NULL,1795206926.37,'http://localhost/api/v1/Account','POST','Espo',NULL,'8975be1e209554aaf',NULL),('e6729e2f0de18b6fe',0,'admin','172.18.0.1','2026-11-20 12:45:42',0,NULL,1795178742.1111,'http://localhost/api/v1/Admin/fieldManager/CAttendance','POST','Espo',NULL,'8975be1e209554aaf',NULL),('e72e6141df9f67790',0,'admin','172.18.0.1','2026-11-20 12:16:43',0,NULL,1795177003.0987,'http://localhost/api/v1/CWorkOrder','POST','Espo',NULL,'8975be1e209554aaf',NULL),('e7dfaebd2cdc2071b',0,'admin','172.18.0.1','2026-11-20 12:48:09',0,NULL,1795178888.8171,'http://localhost/api/v1/Preferences/8975be1e209554aaf','GET','Espo',NULL,'8975be1e209554aaf',NULL),('e823b9c813bfa3e2f',0,'admin','172.18.0.1','2026-11-20 11:58:51',0,NULL,1795175931.1934,'http://localhost/api/v1/Settings','PUT','Espo',NULL,'8975be1e209554aaf',NULL),('e85060720824f619f',0,'admin','172.18.0.1','2026-11-20 11:53:19',0,NULL,1795175599.4043,'http://localhost/api/v1/CWorkOrder','GET','Espo',NULL,'8975be1e209554aaf',NULL),('e98361717d71b22e4',0,'admin','172.18.0.1','2026-11-20 12:10:55',0,NULL,1795176655.7518,'http://localhost/api/v1/CAMC/d766f3eec4a784423','PUT','Espo',NULL,'8975be1e209554aaf',NULL),('ea29bcb78251aa410',0,'admin','172.18.0.1','2026-11-20 11:53:04',0,NULL,1795175584.3719,'http://localhost/api/v1/CAttendance/layout/list','PUT','Espo',NULL,'8975be1e209554aaf',NULL),('ea5c9512a779e1fe0',0,'admin','172.18.0.1','2026-11-20 11:58:15',0,NULL,1795175895.209,'http://localhost/api/v1/Admin/fieldManager/CWorkOrder','POST','Espo',NULL,'8975be1e209554aaf',NULL),('eaa7a0ba11eabf228',0,'admin','172.18.0.1','2026-11-20 12:10:24',0,NULL,1795176623.8376,'http://localhost/api/v1/EntityManager/action/createEntity','POST','Espo',NULL,'8975be1e209554aaf',NULL),('eb119f13c561b6877',0,'admin','172.18.0.1','2026-11-20 20:34:53',0,NULL,1795206892.9128,'http://localhost/api/v1/EntityManager/action/createLink','POST','Espo',NULL,'8975be1e209554aaf',NULL),('eb1da450c58f9fc3e',0,'admin','100.64.0.28','2026-11-20 12:01:07',0,NULL,1795176066.8802,'http://app-8b34cd0836f1d712.up.railway.app/api/v1/CAttendance','GET','Espo',NULL,'8975be1e209554aaf','4f175329b10d9fd79'),('eb41a279f0338f5e0',0,'admin','172.18.0.1','2026-11-20 20:35:28',0,NULL,1795206927.8377,'http://localhost/api/v1/CEstimation','POST','Espo',NULL,'8975be1e209554aaf',NULL),('ec23c8640fc7701d8',0,'admin','172.18.0.1','2026-11-20 20:35:28',0,NULL,1795206928.763,'http://localhost/api/v1/CEstimation/bf551c7f371c4cc8e','GET','Espo',NULL,'8975be1e209554aaf',NULL),('ed7ffc4bdbe8b71e1',0,'admin','172.18.0.1','2026-11-20 12:10:37',0,NULL,1795176636.8234,'http://localhost/api/v1/EntityManager/action/createLink','POST','Espo',NULL,'8975be1e209554aaf',NULL),('eda523773e71a2026',0,'admin','172.18.0.1','2026-11-20 20:35:30',0,NULL,1795206930.1981,'http://localhost/api/v1/CInvoice/d393fc43249460ea6','PUT','Espo',NULL,'8975be1e209554aaf',NULL),('edfbe2db77c8cefbe',0,'admin','172.18.0.1','2026-11-20 12:16:27',0,NULL,1795176987.4067,'http://localhost/api/v1/Admin/fieldManager/CJob','POST','Espo',NULL,'8975be1e209554aaf',NULL),('eef2a50b81ea39171',0,'admin','172.18.0.1','2026-11-20 20:35:30',0,NULL,1795206930.7427,'http://localhost/api/v1/CInvoice/d393fc43249460ea6','PUT','Espo',NULL,'8975be1e209554aaf',NULL),('ef1a3e2dd6b7e9d39',0,'admin','172.18.0.1','2026-11-20 20:34:31',0,NULL,1795206871.3113,'http://localhost/api/v1/Admin/fieldManager/CEstimation','POST','Espo',NULL,'8975be1e209554aaf',NULL),('efabdb60367730ae9',0,'admin','172.18.0.1','2026-11-20 11:58:52',0,NULL,1795175931.9159,'http://localhost/api/v1/Admin/rebuild','POST','Espo',NULL,'8975be1e209554aaf',NULL),('efe96a8335fe5dd0f',0,'admin','172.18.0.1','2026-11-20 12:10:31',0,NULL,1795176631.5502,'http://localhost/api/v1/Admin/fieldManager/CAMC','POST','Espo',NULL,'8975be1e209554aaf',NULL),('f00dfd79f9468eb7f',0,'admin','172.18.0.1','2026-11-20 12:10:55',0,NULL,1795176655.0351,'http://localhost/api/v1/EntityManager/action/formula','POST','Espo',NULL,'8975be1e209554aaf',NULL),('f120d2ac9b4439ee8',0,'admin','172.18.0.1','2026-11-20 20:34:56',0,NULL,1795206896.6209,'http://localhost/api/v1/EntityManager/action/createLink','POST','Espo',NULL,'8975be1e209554aaf',NULL),('f13400a22c1527541',0,'admin','172.18.0.1','2026-11-20 20:35:47',0,NULL,1795206946.8816,'http://localhost/api/v1/CWorkOrder','GET','Espo',NULL,'8975be1e209554aaf',NULL),('f37346ad4aed7a14a',0,'admin','172.18.0.1','2026-11-20 11:53:04',0,NULL,1795175584.5956,'http://localhost/api/v1/EntityManager/action/formula','POST','Espo',NULL,'8975be1e209554aaf',NULL),('f38c7e48f5c949807',0,'admin','172.18.0.1','2026-11-20 11:58:16',0,NULL,1795175895.8912,'http://localhost/api/v1/Admin/fieldManager/CWorkOrder','POST','Espo',NULL,'8975be1e209554aaf',NULL),('f391c1fed664385c3',0,'admin','172.18.0.1','2026-11-20 12:52:28',0,NULL,1795179148.5654,'http://localhost/api/v1/CAttendance','GET','Espo',NULL,'8975be1e209554aaf',NULL),('f3fe2ae5e891437fb',0,'admin','172.18.0.1','2026-11-20 20:35:45',0,NULL,1795206945.5019,'http://localhost/api/v1/CInvoice','GET','Espo',NULL,'8975be1e209554aaf',NULL),('f4d46820a6ce6a6d9',0,'admin','172.18.0.1','2026-11-20 20:34:32',0,NULL,1795206872.5389,'http://localhost/api/v1/Admin/fieldManager/CEstimation','POST','Espo',NULL,'8975be1e209554aaf',NULL),('f667da8f5120b29bc',0,'admin','172.18.0.1','2026-11-20 12:28:28',0,NULL,1795177708.5644,'http://localhost/api/v1/Admin/fieldManager/CDailyHours','POST','Espo',NULL,'8975be1e209554aaf',NULL),('f71ede8f4051073ab',0,'admin','172.18.0.1','2026-11-20 12:28:30',0,NULL,1795177710.0142,'http://localhost/api/v1/Admin/fieldManager/CDailyHours','POST','Espo',NULL,'8975be1e209554aaf',NULL),('f97399481494750ff',0,'admin','172.18.0.1','2026-11-20 11:54:12',0,NULL,1795175652.7553,'http://localhost/api/v1/Admin/fieldManager/CAttendance/checkOutLat','PUT','Espo',NULL,'8975be1e209554aaf',NULL),('fabe728041faafcae',0,'admin','172.18.0.1','2026-11-20 20:35:29',0,NULL,1795206929.2499,'http://localhost/api/v1/CPartService','GET','Espo',NULL,'8975be1e209554aaf',NULL),('fb31c6618b9c3236e',0,'admin','172.18.0.1','2026-11-20 20:34:28',0,NULL,1795206868.0613,'http://localhost/api/v1/Admin/fieldManager/CEstimation','POST','Espo',NULL,'8975be1e209554aaf',NULL),('fba21a9ed599267dc',0,'admin','172.18.0.1','2026-11-20 20:35:04',0,NULL,1795206904.7604,'http://localhost/api/v1/Admin/clearCache','POST','Espo',NULL,'8975be1e209554aaf',NULL),('fd1479b1777fd4840',0,'admin','172.18.0.1','2026-11-20 11:52:03',0,NULL,1795175523.2861,'http://localhost/api/v1/EntityManager/action/createEntity','POST','Espo',NULL,'8975be1e209554aaf',NULL),('fe36e20fa405c81bc',0,'admin','172.18.0.1','2026-11-20 20:34:36',0,NULL,1795206876.0952,'http://localhost/api/v1/Admin/fieldManager/CInvoice','POST','Espo',NULL,'8975be1e209554aaf',NULL),('fe90f0fa03a44ac37',0,'admin','172.18.0.1','2026-11-20 20:35:46',0,NULL,1795206945.9607,'http://localhost/api/v1/CInvoice','GET','Espo',NULL,'8975be1e209554aaf',NULL),('ff1177c0187cc5aef',0,'admin','172.18.0.1','2026-11-20 20:35:03',0,NULL,1795206903.3901,'http://localhost/api/v1/CInvoice/layout/list','PUT','Espo',NULL,'8975be1e209554aaf',NULL);
/*!40000 ALTER TABLE `auth_log_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_token`
--

DROP TABLE IF EXISTS `auth_token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_token` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint DEFAULT '0',
  `token` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hash` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `secret` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ip_address` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint NOT NULL DEFAULT '1',
  `password_version` int NOT NULL DEFAULT '0',
  `last_access` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `portal_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_TOKEN` (`token`,`deleted`),
  KEY `IDX_HASH` (`hash`),
  KEY `IDX_USER_ID` (`user_id`),
  KEY `IDX_PORTAL_ID` (`portal_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_token`
--

LOCK TABLES `auth_token` WRITE;
/*!40000 ALTER TABLE `auth_token` DISABLE KEYS */;
INSERT INTO `auth_token` VALUES ('08f9050a5c8ea25b4',0,'cf060445d637d4759335bf7b5df9b2bd',NULL,'493bfb7719a19b7693cd81fd71132b1c','100.64.0.17',1,1,'2026-11-20 13:07:04','2026-11-20 11:53:48','2026-11-20 13:07:04','8975be1e209554aaf',NULL),('0973bc66a817b0306',0,'4ab667a042cdb06de8a6d80c055fa66c',NULL,'b87b43c9d8f40d15e61bce0d2033e22f','100.64.0.7',1,1,'2026-11-20 20:41:09','2026-11-20 20:30:15','2026-11-20 20:41:09','8975be1e209554aaf',NULL),('0d41473af61914185',0,'9bd7fbfb519fc343f257073a38c6e7af',NULL,'272081904369f25754677e2ba7074767','100.64.0.10',1,2,'2026-11-20 20:40:11','2026-11-20 19:29:53','2026-11-20 20:40:11','3a9d2245f7f443cd5',NULL),('0f28b5ca1627ea939',0,'3cec56bc73c2e7148eba976509bf255d',NULL,NULL,'100.64.0.26',1,1,'2026-11-20 12:01:17','2026-11-20 12:01:17','2026-11-20 12:01:17','8975be1e209554aaf',NULL),('1213ddfb0ae85b314',0,'ac8ac731b315036156e338a614995fe6',NULL,NULL,'100.64.0.8',1,1,'2026-11-20 12:40:34','2026-11-20 12:40:34','2026-11-20 12:40:34','8975be1e209554aaf',NULL),('1d374a07680bd894e',0,'28db37e5c26d82749443be038d3f4e7f',NULL,'98b5b3299bfd78ff61e25fc7df98bae6','100.64.0.29',1,1,'2026-11-20 12:07:17','2026-11-20 12:04:56','2026-11-20 12:07:17','8975be1e209554aaf',NULL),('2f48ab220d2a1aac7',0,'0c952943760aaa94c807177001d2e8c7',NULL,NULL,'100.64.0.11',1,1,'2026-11-20 12:39:54','2026-11-20 12:39:54','2026-11-20 12:39:54','8975be1e209554aaf',NULL),('358da851518a0b673',0,'a63b15c20871b624c2e7b48c6d72b08e',NULL,'8ed1361fb706101d3d1d9398f572a181','100.64.0.1',0,1,'2026-11-20 20:30:02','2026-11-20 11:13:33','2026-11-20 20:30:02','8975be1e209554aaf',NULL),('36e84f0576c673650',0,'f00f2492c9fc3a570128e254b4ba9ed4',NULL,'0b0fc8a494fc08ba7a869dc5614aca52','100.64.0.20',1,1,'2026-11-20 12:54:22','2026-11-20 12:52:01','2026-11-20 12:54:22','8975be1e209554aaf',NULL),('3c076e87c113b5ad8',0,'b5665c7da150e7ae93ddf293f17d8985',NULL,'11085ead1e461f4c233eecc6b6854b93','100.64.0.2',0,2,'2026-11-20 19:29:46','2026-11-20 19:20:34','2026-11-20 19:29:46','3a9d2245f7f443cd5',NULL),('3d0ada9cb5b60d311',0,'72f0ae8ac9f75e18398cc136056e1206',NULL,NULL,'100.64.0.2',1,1,'2026-11-20 12:40:29','2026-11-20 12:40:29','2026-11-20 12:40:29','8975be1e209554aaf',NULL),('405b307d474c58ef5',0,'c048ec648025ee53b1d7c81e0540d790',NULL,NULL,'100.64.0.34',1,1,'2026-11-20 12:01:16','2026-11-20 12:01:16','2026-11-20 12:01:16','8975be1e209554aaf',NULL),('4f175329b10d9fd79',0,'9d9fe97c488a571ee50e405c74efbd64',NULL,NULL,'100.64.0.28',1,1,'2026-11-20 12:01:07','2026-11-20 12:01:07','2026-11-20 12:01:07','8975be1e209554aaf',NULL),('5a954821df4d83ed7',0,'942d07a6a29b614cb4e9bf0d12cf0296',NULL,NULL,'100.64.0.21',1,1,'2026-11-20 12:00:50','2026-11-20 12:00:50','2026-11-20 12:00:50','8975be1e209554aaf',NULL),('60519d6eccf2cb9ed',0,'c0b0f937823614eaf785bce17de591db',NULL,NULL,'100.64.0.29',1,1,'2026-11-20 12:00:49','2026-11-20 12:00:49','2026-11-20 12:00:49','8975be1e209554aaf',NULL),('7386f06ca589b5b98',0,'166469f6a51fbc829083d99001c3d1b0',NULL,NULL,'100.64.0.7',1,1,'2026-11-20 12:40:37','2026-11-20 12:40:37','2026-11-20 12:40:37','8975be1e209554aaf',NULL),('793034d439ff714f7',0,'ebbf3d57bf90a7c2b9f4e9cd5e0d3d48',NULL,'657a852e859ac819bb9b7b77a2022972','100.64.0.13',1,1,'2026-11-20 12:37:53','2026-11-20 12:35:52','2026-11-20 12:37:53','8975be1e209554aaf',NULL),('7b38d64f39ae46d2b',0,'4c33afd20bd746c56d8bc2658e6d207b',NULL,'75c76ece3ac9d601bbadc98ab7cc7110','100.64.0.21',1,1,'2026-11-20 12:13:44','2026-11-20 12:11:22','2026-11-20 12:13:44','8975be1e209554aaf',NULL),('83714450691835a6d',0,'2ed537cc0a68dc99a5ccf5545847f0e6',NULL,NULL,'100.64.0.8',1,1,'2026-11-20 12:02:07','2026-11-20 12:02:07','2026-11-20 12:02:07','8975be1e209554aaf',NULL),('98973429d8f252570',0,'8fda898671c44d5351f3058f197d3381',NULL,NULL,'100.64.0.10',1,1,'2026-11-20 12:02:13','2026-11-20 12:02:13','2026-11-20 12:02:13','8975be1e209554aaf',NULL),('9d1899fc2070e6eb6',0,'0c19e0a4bb0074ad3d4813714460faa7',NULL,'d6cc6ca5df6d76de91b7d2b4e96ce5d9','172.18.0.1',1,1,'2026-11-20 20:38:23','2026-11-20 20:36:05','2026-11-20 20:38:23','8975be1e209554aaf',NULL),('a54e41429cda29ca5',0,'c45642b74d81e6cbb8e6972b777c179e',NULL,NULL,'100.64.0.3',1,1,'2026-11-20 12:39:58','2026-11-20 12:39:58','2026-11-20 12:39:58','8975be1e209554aaf',NULL),('aba58bea40d5e26c0',0,'5f5775715c69485a18bb63917de4edd1',NULL,NULL,'100.64.0.17',1,1,'2026-11-20 12:01:16','2026-11-20 12:01:16','2026-11-20 12:01:16','8975be1e209554aaf',NULL),('b8307bba23bb9cac4',0,'f92b039ad84682044c71359db44011e7',NULL,NULL,'100.64.0.11',1,1,'2026-11-20 12:40:36','2026-11-20 12:40:36','2026-11-20 12:40:36','8975be1e209554aaf',NULL),('b881e63e93c44e013',0,'24e186d5f4d14a8e5bf622bd72597753',NULL,NULL,'100.64.0.8',1,1,'2026-11-20 12:40:34','2026-11-20 12:40:34','2026-11-20 12:40:34','8975be1e209554aaf',NULL),('bfcd331482a98c566',0,'a505d86db65c03353bbfac2a6c309355',NULL,NULL,'100.64.0.9',1,1,'2026-11-20 12:40:37','2026-11-20 12:40:37','2026-11-20 12:40:37','8975be1e209554aaf',NULL),('d2b25d505a04d515c',0,'81e52783ac02b1a22cda599cddae46cc',NULL,NULL,'100.64.0.4',1,1,'2026-11-20 12:02:13','2026-11-20 12:02:13','2026-11-20 12:02:13','8975be1e209554aaf',NULL),('dc97d2112d2a9e019',0,'99317f39fe47df10adab73e0b03952c4',NULL,NULL,'100.64.0.9',1,1,'2026-11-20 12:02:08','2026-11-20 12:02:08','2026-11-20 12:02:08','8975be1e209554aaf',NULL),('e3ab78114e3e7cf4c',0,'d8d58aeca29c7f81631c83442abc400c',NULL,NULL,'100.64.0.6',1,1,'2026-11-20 12:39:56','2026-11-20 12:39:56','2026-11-20 12:39:56','8975be1e209554aaf',NULL),('eb9a534dbac9e0c53',0,'104d0cd981781f444671d30308116fe1',NULL,NULL,'100.64.0.5',1,1,'2026-11-20 12:39:57','2026-11-20 12:39:57','2026-11-20 12:39:57','8975be1e209554aaf',NULL),('f8169207aeb86a16a',0,'73a0743b621858aa2f3e44de1521aef3',NULL,NULL,'100.64.0.33',1,1,'2026-11-20 12:01:06','2026-11-20 12:01:06','2026-11-20 12:01:06','8975be1e209554aaf',NULL),('fd4b5ef42ad98a305',0,'cba0e526e0789ef34b06ba9f2f9ed1df',NULL,NULL,'100.64.0.6',1,1,'2026-11-20 12:40:30','2026-11-20 12:40:30','2026-11-20 12:40:30','8975be1e209554aaf',NULL),('fe2d0aa955b6c12a8',0,'0e7d05a2534666e5d15951be7925cc2c',NULL,NULL,'100.64.0.11',1,1,'2026-11-20 12:39:54','2026-11-20 12:39:54','2026-11-20 12:39:54','8975be1e209554aaf',NULL),('fed84cf2612494308',0,'752c44dabb8ed1210bcf25cc1f5ab7f6',NULL,'5a3d678c2e60c687f2531ee5e254ed51','100.64.0.16',1,1,'2026-11-20 12:49:50','2026-11-20 12:46:19','2026-11-20 12:49:50','8975be1e209554aaf',NULL);
/*!40000 ALTER TABLE `auth_token` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `authentication_provider`
--

DROP TABLE IF EXISTS `authentication_provider`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `authentication_provider` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `method` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `oidc_client_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `oidc_client_secret` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `oidc_authorization_endpoint` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `oidc_user_info_endpoint` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `oidc_token_endpoint` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `oidc_jwks_endpoint` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `oidc_jwt_signature_algorithm_list` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `oidc_scopes` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `oidc_create_user` tinyint NOT NULL DEFAULT '0',
  `oidc_username_claim` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'sub',
  `oidc_sync` tinyint NOT NULL DEFAULT '0',
  `oidc_logout_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `oidc_authorization_prompt` varchar(14) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `oidc_authorization_pkce` tinyint NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `authentication_provider`
--

LOCK TABLES `authentication_provider` WRITE;
/*!40000 ALTER TABLE `authentication_provider` DISABLE KEYS */;
/*!40000 ALTER TABLE `authentication_provider` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `autofollow`
--

DROP TABLE IF EXISTS `autofollow`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `autofollow` (
  `id` int NOT NULL AUTO_INCREMENT,
  `deleted` tinyint DEFAULT '0',
  `entity_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_ENTITY_TYPE` (`entity_type`),
  KEY `IDX_USER` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `autofollow`
--

LOCK TABLES `autofollow` WRITE;
/*!40000 ALTER TABLE `autofollow` DISABLE KEYS */;
/*!40000 ALTER TABLE `autofollow` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `c_a_m_c`
--

DROP TABLE IF EXISTS `c_a_m_c`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `c_a_m_c` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `stream_updated_at` datetime DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `assigned_user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contract_number` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Draft',
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `contract_value` double DEFAULT NULL,
  `contract_value_currency` varchar(3) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `billing_frequency` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Yearly',
  `visits_per_year` int DEFAULT '4',
  `service_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Comprehensive',
  `asset_covered` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `site_address_street` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `site_address_city` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `site_address_state` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `site_address_country` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `site_address_postal_code` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `renewal_reminder_date` date DEFAULT NULL,
  `terms` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `account_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_CREATED_AT_ID` (`created_at`,`id`),
  KEY `IDX_NAME` (`name`,`deleted`),
  KEY `IDX_ASSIGNED_USER` (`assigned_user_id`,`deleted`),
  KEY `IDX_CREATED_AT` (`created_at`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`),
  KEY `IDX_ASSIGNED_USER_ID` (`assigned_user_id`),
  KEY `IDX_ACCOUNT_ID` (`account_id`),
  KEY `IDX_CONTACT_ID` (`contact_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `c_a_m_c`
--

LOCK TABLES `c_a_m_c` WRITE;
/*!40000 ALTER TABLE `c_a_m_c` DISABLE KEYS */;
INSERT INTO `c_a_m_c` VALUES ('2d70128fccb163450','BT AMC',1,NULL,'2026-11-20 20:35:27','2026-11-20 20:35:48','2026-11-20 20:35:27','8975be1e209554aaf','8975be1e209554aaf',NULL,NULL,'Draft','2026-01-01','2027-01-01',NULL,NULL,'Yearly',4,'Comprehensive',NULL,NULL,NULL,NULL,NULL,NULL,'2026-12-02',NULL,'f3041c7f637e8df79',NULL),('d766f3eec4a784423','Acme HVAC AMC 2026',0,NULL,'2026-11-20 12:10:46','2026-11-20 12:10:56','2026-11-20 12:10:46','8975be1e209554aaf','8975be1e209554aaf',NULL,'AMC-0001','Active','2026-01-01','2027-06-01',120000,'USD','Quarterly',4,'Comprehensive',NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-10',NULL,'fad196603b025835e',NULL);
/*!40000 ALTER TABLE `c_a_m_c` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `c_attendance`
--

DROP TABLE IF EXISTS `c_attendance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `c_attendance` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `assigned_user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date` date DEFAULT NULL,
  `check_in` datetime DEFAULT NULL,
  `check_out` datetime DEFAULT NULL,
  `status` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Present',
  `check_in_lat` double DEFAULT NULL,
  `check_in_lng` double DEFAULT NULL,
  `check_out_lat` double DEFAULT NULL,
  `check_out_lng` double DEFAULT NULL,
  `hours_worked` double DEFAULT NULL,
  `notes` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `employee_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `work_order_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `daily_hours_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `check_in_map` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `check_out_map` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_CREATED_AT_ID` (`created_at`,`id`),
  KEY `IDX_NAME` (`name`,`deleted`),
  KEY `IDX_ASSIGNED_USER` (`assigned_user_id`,`deleted`),
  KEY `IDX_CREATED_AT` (`created_at`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`),
  KEY `IDX_ASSIGNED_USER_ID` (`assigned_user_id`),
  KEY `IDX_EMPLOYEE_ID` (`employee_id`),
  KEY `IDX_WORK_ORDER_ID` (`work_order_id`),
  KEY `IDX_DAILY_HOURS_ID` (`daily_hours_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `c_attendance`
--

LOCK TABLES `c_attendance` WRITE;
/*!40000 ALTER TABLE `c_attendance` DISABLE KEYS */;
INSERT INTO `c_attendance` VALUES ('343d90807238b187e','Admin 2026-11-20',0,NULL,'2026-11-20 11:53:29','2026-11-20 12:45:50','8975be1e209554aaf','8975be1e209554aaf',NULL,'2026-11-20','2026-11-20 09:00:00','2026-11-20 17:30:00','Present',12.9716,77.5946,NULL,NULL,8.5,'resync','8975be1e209554aaf','6d060c6e1e1181f59','d5c431f4b034b4b8b','https://www.openstreetmap.org/?mlat=12.9716&mlon=77.5946#map=17/12.9716/77.5946',NULL),('3d1bcfdd0d782c3e7','Admin 2026-11-20',0,NULL,'2026-11-20 12:01:06','2026-11-20 12:41:31','8975be1e209554aaf','8975be1e209554aaf',NULL,'2026-11-20','2026-11-20 12:01:00','2026-11-20 13:30:00','Present',NULL,NULL,NULL,NULL,1.48,'resync','8975be1e209554aaf',NULL,'d5c431f4b034b4b8b',NULL,NULL),('5062dab9aa60940ed','Admin 2026-11-20',0,NULL,'2026-11-20 12:52:22','2026-11-20 12:52:51','8975be1e209554aaf','8975be1e209554aaf',NULL,'2026-11-20','2026-11-20 12:52:22','2026-11-20 12:52:50','Present',NULL,NULL,13.02778909856,80.100300619098,0,NULL,'8975be1e209554aaf',NULL,'d5c431f4b034b4b8b',NULL,'https://www.openstreetmap.org/?mlat=13.02778909856&mlon=80.100300619098#map=17/13.02778909856/80.100300619098'),('5155e3286aeb73c25','Admin 2026-11-20',0,NULL,'2026-11-20 12:55:42','2026-11-20 17:08:56','8975be1e209554aaf','8975be1e209554aaf',NULL,'2026-11-20','2026-11-20 12:55:41','2026-11-20 17:08:55','Present',NULL,NULL,NULL,NULL,4.22,NULL,'8975be1e209554aaf',NULL,'d5c431f4b034b4b8b',NULL,NULL),('5cf9a1253b321c9ae','s3',1,NULL,'2026-11-20 12:28:58','2026-11-20 12:28:59','8975be1e209554aaf','8975be1e209554aaf',NULL,'2026-11-20','2026-11-20 18:00:00','2026-11-20 19:15:00','Present',NULL,NULL,NULL,NULL,1.25,NULL,'8975be1e209554aaf',NULL,'d5c431f4b034b4b8b',NULL,NULL),('66e3ae57755bf451c','Admin 2026-11-20',0,NULL,'2026-11-20 12:02:13','2026-11-20 12:39:57','8975be1e209554aaf','8975be1e209554aaf',NULL,'2026-11-20','2026-11-20 12:02:12','2026-11-20 12:39:55','Present',NULL,NULL,NULL,NULL,0.62,'resync','8975be1e209554aaf',NULL,'d5c431f4b034b4b8b',NULL,NULL),('82fe88e78a9f0023e','Sales 1 User 2026-11-21',0,NULL,'2026-11-20 20:25:43','2026-11-20 20:25:43','3a9d2245f7f443cd5',NULL,'3a9d2245f7f443cd5','2026-11-21','2026-11-20 20:25:43',NULL,'Present',NULL,NULL,NULL,NULL,NULL,NULL,'3a9d2245f7f443cd5',NULL,'a8233979e9a34d612',NULL,NULL),('bac44286bee36cd47','Admin 2026-11-20',0,NULL,'2026-11-20 12:40:34','2026-11-20 12:40:37','8975be1e209554aaf','8975be1e209554aaf',NULL,'2026-11-20','2026-11-20 12:40:33','2026-11-20 12:40:35','Present',13.027754,80.100891,13.027754,80.100891,0,NULL,'8975be1e209554aaf',NULL,'d5c431f4b034b4b8b',NULL,NULL),('cc6593c4a6bf438fe','Admin 2026-11-20',0,NULL,'2026-11-20 12:52:53','2026-11-20 12:52:58','8975be1e209554aaf','8975be1e209554aaf',NULL,'2026-11-20','2026-11-20 12:52:52','2026-11-20 12:52:57','Present',13.02778909856,80.100300619098,13.02778909856,80.100300619098,0,NULL,'8975be1e209554aaf',NULL,'d5c431f4b034b4b8b','https://www.openstreetmap.org/?mlat=13.02778909856&mlon=80.100300619098#map=17/13.02778909856/80.100300619098','https://www.openstreetmap.org/?mlat=13.02778909856&mlon=80.100300619098#map=17/13.02778909856/80.100300619098');
/*!40000 ALTER TABLE `c_attendance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `c_daily_hours`
--

DROP TABLE IF EXISTS `c_daily_hours`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `c_daily_hours` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `assigned_user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date` date DEFAULT NULL,
  `total_hours` double DEFAULT NULL,
  `session_count` int DEFAULT NULL,
  `open_sessions` int DEFAULT NULL,
  `first_check_in` datetime DEFAULT NULL,
  `last_check_out` datetime DEFAULT NULL,
  `employee_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_CREATED_AT_ID` (`created_at`,`id`),
  KEY `IDX_NAME` (`name`,`deleted`),
  KEY `IDX_ASSIGNED_USER` (`assigned_user_id`,`deleted`),
  KEY `IDX_CREATED_AT` (`created_at`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`),
  KEY `IDX_ASSIGNED_USER_ID` (`assigned_user_id`),
  KEY `IDX_EMPLOYEE_ID` (`employee_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `c_daily_hours`
--

LOCK TABLES `c_daily_hours` WRITE;
/*!40000 ALTER TABLE `c_daily_hours` DISABLE KEYS */;
INSERT INTO `c_daily_hours` VALUES ('a8233979e9a34d612','Sales 1 User - 2026-11-21',0,NULL,'2026-11-20 20:25:43','2026-11-20 20:25:43','3a9d2245f7f443cd5',NULL,NULL,'2026-11-21',0,1,1,'2026-11-20 20:25:43',NULL,'3a9d2245f7f443cd5'),('d5c431f4b034b4b8b','Admin - 2026-11-20',0,NULL,'2026-11-20 12:28:57','2026-11-20 17:08:57','8975be1e209554aaf','8975be1e209554aaf',NULL,'2026-11-20',14.84,7,0,'2026-11-20 09:00:00','2026-11-20 17:30:00','8975be1e209554aaf');
/*!40000 ALTER TABLE `c_daily_hours` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `c_estimation`
--

DROP TABLE IF EXISTS `c_estimation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `c_estimation` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `stream_updated_at` datetime DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `assigned_user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `estimate_number` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Draft',
  `issue_date` date DEFAULT NULL,
  `valid_until` date DEFAULT NULL,
  `subtotal` double DEFAULT NULL,
  `subtotal_currency` varchar(3) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `discount` double DEFAULT NULL,
  `discount_currency` varchar(3) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tax_percent` double DEFAULT '0',
  `tax_amount` double DEFAULT NULL,
  `tax_amount_currency` varchar(3) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total` double DEFAULT NULL,
  `total_currency` varchar(3) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `account_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `job_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `work_order_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amc_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_CREATED_AT_ID` (`created_at`,`id`),
  KEY `IDX_NAME` (`name`,`deleted`),
  KEY `IDX_ASSIGNED_USER` (`assigned_user_id`,`deleted`),
  KEY `IDX_CREATED_AT` (`created_at`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`),
  KEY `IDX_ASSIGNED_USER_ID` (`assigned_user_id`),
  KEY `IDX_ACCOUNT_ID` (`account_id`),
  KEY `IDX_JOB_ID` (`job_id`),
  KEY `IDX_WORK_ORDER_ID` (`work_order_id`),
  KEY `IDX_AMC_ID` (`amc_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `c_estimation`
--

LOCK TABLES `c_estimation` WRITE;
/*!40000 ALTER TABLE `c_estimation` DISABLE KEYS */;
INSERT INTO `c_estimation` VALUES ('bf551c7f371c4cc8e','BT Est',1,NULL,'2026-11-20 20:35:28','2026-11-20 20:35:46','2026-11-20 20:35:28','8975be1e209554aaf','8975be1e209554aaf',NULL,NULL,'Draft','2026-11-20','2026-12-20',151.5,'USD',NULL,NULL,10,15.15,'USD',166.65,'USD','f3041c7f637e8df79','9b77a6adb5eeeeada','9256dd2bc6c0ed35e','2d70128fccb163450');
/*!40000 ALTER TABLE `c_estimation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `c_invoice`
--

DROP TABLE IF EXISTS `c_invoice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `c_invoice` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `stream_updated_at` datetime DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `assigned_user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `invoice_number` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Draft',
  `issue_date` date DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `subtotal` double DEFAULT NULL,
  `subtotal_currency` varchar(3) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `discount` double DEFAULT NULL,
  `discount_currency` varchar(3) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tax_percent` double DEFAULT '0',
  `tax_amount` double DEFAULT NULL,
  `tax_amount_currency` varchar(3) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total` double DEFAULT NULL,
  `total_currency` varchar(3) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount_paid` double DEFAULT NULL,
  `amount_paid_currency` varchar(3) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `balance` double DEFAULT NULL,
  `balance_currency` varchar(3) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_method` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `account_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `job_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `work_order_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amc_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `estimation_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_CREATED_AT_ID` (`created_at`,`id`),
  KEY `IDX_NAME` (`name`,`deleted`),
  KEY `IDX_ASSIGNED_USER` (`assigned_user_id`,`deleted`),
  KEY `IDX_CREATED_AT` (`created_at`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`),
  KEY `IDX_ASSIGNED_USER_ID` (`assigned_user_id`),
  KEY `IDX_ACCOUNT_ID` (`account_id`),
  KEY `IDX_JOB_ID` (`job_id`),
  KEY `IDX_WORK_ORDER_ID` (`work_order_id`),
  KEY `IDX_AMC_ID` (`amc_id`),
  KEY `IDX_ESTIMATION_ID` (`estimation_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `c_invoice`
--

LOCK TABLES `c_invoice` WRITE;
/*!40000 ALTER TABLE `c_invoice` DISABLE KEYS */;
INSERT INTO `c_invoice` VALUES ('d393fc43249460ea6','BT Inv',1,NULL,'2026-11-20 20:35:29','2026-11-20 20:35:45','2026-11-20 20:35:29','8975be1e209554aaf','8975be1e209554aaf',NULL,NULL,'Paid','2026-11-20','2026-12-01',151.5,'USD',NULL,NULL,10,15.15,'USD',166.65,'USD',166.65,'USD',0,'USD',NULL,'f3041c7f637e8df79','9b77a6adb5eeeeada',NULL,'2d70128fccb163450','bf551c7f371c4cc8e');
/*!40000 ALTER TABLE `c_invoice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `c_job`
--

DROP TABLE IF EXISTS `c_job`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `c_job` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `stream_updated_at` datetime DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `assigned_user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `job_number` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Open',
  `priority` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Normal',
  `job_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Repair',
  `start_date` date DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `completed_date` date DEFAULT NULL,
  `estimated_cost` double DEFAULT NULL,
  `estimated_cost_currency` varchar(3) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `site_address_street` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `site_address_city` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `site_address_state` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `site_address_country` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `site_address_postal_code` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `account_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amc_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_CREATED_AT_ID` (`created_at`,`id`),
  KEY `IDX_NAME` (`name`,`deleted`),
  KEY `IDX_ASSIGNED_USER` (`assigned_user_id`,`deleted`),
  KEY `IDX_CREATED_AT` (`created_at`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`),
  KEY `IDX_ASSIGNED_USER_ID` (`assigned_user_id`),
  KEY `IDX_ACCOUNT_ID` (`account_id`),
  KEY `IDX_CONTACT_ID` (`contact_id`),
  KEY `IDX_AMC_ID` (`amc_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `c_job`
--

LOCK TABLES `c_job` WRITE;
/*!40000 ALTER TABLE `c_job` DISABLE KEYS */;
INSERT INTO `c_job` VALUES ('1beaa2ed6d39769fc','Regular Alocation',0,NULL,'2026-11-20 19:51:08','2026-11-20 19:51:08','2026-11-20 19:51:08','8975be1e209554aaf',NULL,NULL,'QRC12343','Open','Normal','Repair','2026-11-20','2026-12-05',NULL,35000,'USD',NULL,NULL,NULL,NULL,NULL,'fad196603b025835e',NULL,'d766f3eec4a784423'),('26a23642611410415','Quarterly Maintainance',0,NULL,'2026-11-20 19:36:56','2026-11-20 19:36:56','2026-11-20 19:45:09','8975be1e209554aaf',NULL,NULL,'QCT1234','Open','Normal','Repair','2026-11-20','2026-11-30',NULL,25500,'USD',NULL,NULL,NULL,NULL,NULL,'fad196603b025835e',NULL,'d766f3eec4a784423'),('5172ba6f3bf9cf278','Q4 preventive maintenance',0,NULL,'2026-11-20 12:16:43','2026-11-20 12:16:43','2026-11-20 12:16:43','8975be1e209554aaf','8975be1e209554aaf',NULL,'JOB-0001','Completed','Normal','AMC Visit',NULL,NULL,'2026-11-20',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'fad196603b025835e',NULL,'d766f3eec4a784423'),('9b77a6adb5eeeeada','BT Job',1,NULL,'2026-11-20 20:35:27','2026-11-20 20:35:48','2026-11-20 20:35:27','8975be1e209554aaf','8975be1e209554aaf',NULL,NULL,'Open','Normal','Repair',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'f3041c7f637e8df79',NULL,'2d70128fccb163450'),('bee574c7672667f9a','Maintainance',0,NULL,'2026-11-20 12:54:30','2026-11-20 12:55:35','2026-11-20 12:55:35','8975be1e209554aaf','8975be1e209554aaf','8975be1e209554aaf','WD1258','In Progress','High','Inspection','2026-11-19','2026-11-22',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'fad196603b025835e',NULL,'d766f3eec4a784423');
/*!40000 ALTER TABLE `c_job` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `c_part_service`
--

DROP TABLE IF EXISTS `c_part_service`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `c_part_service` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `stream_updated_at` datetime DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `assigned_user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `item_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Part',
  `sku` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `quantity` double DEFAULT '1',
  `unit` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'pcs',
  `unit_price` double DEFAULT NULL,
  `unit_price_currency` varchar(3) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `line_total` double DEFAULT NULL,
  `line_total_currency` varchar(3) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Planned',
  `account_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `job_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `work_order_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amc_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `estimation_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `invoice_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_CREATED_AT_ID` (`created_at`,`id`),
  KEY `IDX_NAME` (`name`,`deleted`),
  KEY `IDX_ASSIGNED_USER` (`assigned_user_id`,`deleted`),
  KEY `IDX_CREATED_AT` (`created_at`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`),
  KEY `IDX_ASSIGNED_USER_ID` (`assigned_user_id`),
  KEY `IDX_ACCOUNT_ID` (`account_id`),
  KEY `IDX_JOB_ID` (`job_id`),
  KEY `IDX_WORK_ORDER_ID` (`work_order_id`),
  KEY `IDX_AMC_ID` (`amc_id`),
  KEY `IDX_ESTIMATION_ID` (`estimation_id`),
  KEY `IDX_INVOICE_ID` (`invoice_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `c_part_service`
--

LOCK TABLES `c_part_service` WRITE;
/*!40000 ALTER TABLE `c_part_service` DISABLE KEYS */;
INSERT INTO `c_part_service` VALUES ('6f8e92f43265d908e','Labour',0,NULL,'2026-11-20 20:35:28','2026-11-20 20:35:29','2026-11-20 20:35:28','8975be1e209554aaf','8975be1e209554aaf',NULL,'Service',NULL,3,'pcs',50.5,'USD',151.5,'USD','Planned','f3041c7f637e8df79','9b77a6adb5eeeeada','9256dd2bc6c0ed35e','2d70128fccb163450','bf551c7f371c4cc8e','d393fc43249460ea6'),('9bbc99d1aaa7e1a4b','Compressor',1,NULL,'2026-11-20 20:35:28','2026-11-20 20:35:31','2026-11-20 20:35:28','8975be1e209554aaf','8975be1e209554aaf',NULL,'Part',NULL,2,'pcs',100,'USD',200,'USD','Planned','f3041c7f637e8df79','9b77a6adb5eeeeada','9256dd2bc6c0ed35e','2d70128fccb163450','bf551c7f371c4cc8e','d393fc43249460ea6');
/*!40000 ALTER TABLE `c_part_service` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `c_work_order`
--

DROP TABLE IF EXISTS `c_work_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `c_work_order` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `assigned_user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'New',
  `priority` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Normal',
  `job_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Repair',
  `scheduled_start` datetime DEFAULT NULL,
  `scheduled_end` datetime DEFAULT NULL,
  `actual_start` datetime DEFAULT NULL,
  `actual_end` datetime DEFAULT NULL,
  `address_street` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_city` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_state` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_country` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_postal_code` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `resolution_notes` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `customer_signature_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `labor_cost` double DEFAULT NULL,
  `labor_cost_currency` varchar(3) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `account_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `technician_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date_start` datetime DEFAULT NULL,
  `date_end` datetime DEFAULT NULL,
  `is_all_day` tinyint NOT NULL DEFAULT '0',
  `date_start_date` date DEFAULT NULL,
  `date_end_date` date DEFAULT NULL,
  `parent_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amc_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `job_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_CREATED_AT_ID` (`created_at`,`id`),
  KEY `IDX_ASSIGNED_USER` (`assigned_user_id`,`deleted`),
  KEY `IDX_CREATED_AT` (`created_at`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`),
  KEY `IDX_ASSIGNED_USER_ID` (`assigned_user_id`),
  KEY `IDX_DATE_START_STATUS` (`date_start`,`status`),
  KEY `IDX_DATE_START` (`date_start`,`deleted`),
  KEY `IDX_STATUS` (`status`,`deleted`),
  KEY `IDX_ASSIGNED_USER_STATUS` (`assigned_user_id`,`status`),
  KEY `IDX_PARENT` (`parent_id`,`parent_type`),
  KEY `IDX_ACCOUNT_ID` (`account_id`),
  KEY `IDX_CONTACT_ID` (`contact_id`),
  KEY `IDX_AMC_ID` (`amc_id`),
  KEY `IDX_JOB_ID` (`job_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `c_work_order`
--

LOCK TABLES `c_work_order` WRITE;
/*!40000 ALTER TABLE `c_work_order` DISABLE KEYS */;
INSERT INTO `c_work_order` VALUES ('6582eaf57ed8dac2c','Q4 visit 1',0,NULL,'2026-11-20 12:16:43','2026-11-20 12:16:43','8975be1e209554aaf',NULL,NULL,'New','Normal','Repair',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'fad196603b025835e',NULL,NULL,'2026-11-25 10:00:00','2026-11-25 12:00:00',0,NULL,NULL,NULL,NULL,'d766f3eec4a784423','5172ba6f3bf9cf278'),('6d060c6e1e1181f59','Fix HVAC unit',0,NULL,'2026-11-20 11:53:12','2026-11-20 11:53:12','8975be1e209554aaf',NULL,NULL,'Scheduled','High','Repair','2026-11-21 09:00:00','2026-11-21 11:00:00',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'fad196603b025835e',NULL,'8975be1e209554aaf',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),('76b672d24f8bb255e','Fix HVAC unit',0,NULL,'2026-11-20 12:00:30','2026-11-20 12:10:47','8975be1e209554aaf','8975be1e209554aaf','8975be1e209554aaf','Scheduled','High','Repair',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-21 09:00:00','2026-11-21 11:00:00',0,NULL,NULL,NULL,NULL,'d766f3eec4a784423',NULL),('9256dd2bc6c0ed35e','BT WO',1,NULL,'2026-11-20 20:35:27','2026-11-20 20:35:47','8975be1e209554aaf','8975be1e209554aaf',NULL,'New','Normal','Repair',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'f3041c7f637e8df79',NULL,NULL,'2026-11-25 10:00:00','2026-11-25 11:00:00',0,NULL,NULL,NULL,NULL,'2d70128fccb163450','9b77a6adb5eeeeada');
/*!40000 ALTER TABLE `c_work_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `call`
--

DROP TABLE IF EXISTS `call`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `call` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Planned',
  `date_start` datetime DEFAULT NULL,
  `date_end` datetime DEFAULT NULL,
  `direction` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Outbound',
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `uid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `parent_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `account_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `assigned_user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_DATE_START_STATUS` (`date_start`,`status`),
  KEY `IDX_DATE_START` (`date_start`,`deleted`),
  KEY `IDX_STATUS` (`status`,`deleted`),
  KEY `IDX_ASSIGNED_USER` (`assigned_user_id`,`deleted`),
  KEY `IDX_ASSIGNED_USER_STATUS` (`assigned_user_id`,`status`),
  KEY `IDX_UID` (`uid`),
  KEY `IDX_PARENT` (`parent_id`,`parent_type`),
  KEY `IDX_ACCOUNT_ID` (`account_id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`),
  KEY `IDX_ASSIGNED_USER_ID` (`assigned_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `call`
--

LOCK TABLES `call` WRITE;
/*!40000 ALTER TABLE `call` DISABLE KEYS */;
/*!40000 ALTER TABLE `call` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `call_contact`
--

DROP TABLE IF EXISTS `call_contact`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `call_contact` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `call_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'None',
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_CALL_ID_CONTACT_ID` (`call_id`,`contact_id`),
  KEY `IDX_CALL_ID` (`call_id`),
  KEY `IDX_CONTACT_ID` (`contact_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `call_contact`
--

LOCK TABLES `call_contact` WRITE;
/*!40000 ALTER TABLE `call_contact` DISABLE KEYS */;
/*!40000 ALTER TABLE `call_contact` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `call_lead`
--

DROP TABLE IF EXISTS `call_lead`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `call_lead` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `call_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lead_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'None',
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_CALL_ID_LEAD_ID` (`call_id`,`lead_id`),
  KEY `IDX_CALL_ID` (`call_id`),
  KEY `IDX_LEAD_ID` (`lead_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `call_lead`
--

LOCK TABLES `call_lead` WRITE;
/*!40000 ALTER TABLE `call_lead` DISABLE KEYS */;
/*!40000 ALTER TABLE `call_lead` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `call_user`
--

DROP TABLE IF EXISTS `call_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `call_user` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `call_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'None',
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_USER_ID_CALL_ID` (`user_id`,`call_id`),
  KEY `IDX_USER_ID` (`user_id`),
  KEY `IDX_CALL_ID` (`call_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `call_user`
--

LOCK TABLES `call_user` WRITE;
/*!40000 ALTER TABLE `call_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `call_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `campaign`
--

DROP TABLE IF EXISTS `campaign`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `campaign` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Planning',
  `type` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Email',
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `budget` double DEFAULT NULL,
  `mail_merge_only_with_address` tinyint NOT NULL DEFAULT '1',
  `budget_currency` varchar(3) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `assigned_user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contacts_template_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `leads_template_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `accounts_template_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `users_template_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_CREATED_AT` (`created_at`,`deleted`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`),
  KEY `IDX_ASSIGNED_USER_ID` (`assigned_user_id`),
  KEY `IDX_CONTACTS_TEMPLATE_ID` (`contacts_template_id`),
  KEY `IDX_LEADS_TEMPLATE_ID` (`leads_template_id`),
  KEY `IDX_ACCOUNTS_TEMPLATE_ID` (`accounts_template_id`),
  KEY `IDX_USERS_TEMPLATE_ID` (`users_template_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `campaign`
--

LOCK TABLES `campaign` WRITE;
/*!40000 ALTER TABLE `campaign` DISABLE KEYS */;
/*!40000 ALTER TABLE `campaign` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `campaign_log_record`
--

DROP TABLE IF EXISTS `campaign_log_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `campaign_log_record` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint DEFAULT '0',
  `action` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `action_date` datetime DEFAULT NULL,
  `data` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `string_data` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `string_additional_data` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `application` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Espo',
  `created_at` datetime DEFAULT NULL,
  `is_test` tinyint NOT NULL DEFAULT '0',
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `campaign_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `object_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `object_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `queue_item_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_ACTION_DATE` (`action_date`,`deleted`),
  KEY `IDX_ACTION` (`action`,`deleted`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_CAMPAIGN_ID` (`campaign_id`),
  KEY `IDX_PARENT` (`parent_id`,`parent_type`),
  KEY `IDX_OBJECT` (`object_id`,`object_type`),
  KEY `IDX_QUEUE_ITEM_ID` (`queue_item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `campaign_log_record`
--

LOCK TABLES `campaign_log_record` WRITE;
/*!40000 ALTER TABLE `campaign_log_record` DISABLE KEYS */;
/*!40000 ALTER TABLE `campaign_log_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `campaign_target_list`
--

DROP TABLE IF EXISTS `campaign_target_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `campaign_target_list` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `campaign_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_list_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_CAMPAIGN_ID_TARGET_LIST_ID` (`campaign_id`,`target_list_id`),
  KEY `IDX_CAMPAIGN_ID` (`campaign_id`),
  KEY `IDX_TARGET_LIST_ID` (`target_list_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `campaign_target_list`
--

LOCK TABLES `campaign_target_list` WRITE;
/*!40000 ALTER TABLE `campaign_target_list` DISABLE KEYS */;
/*!40000 ALTER TABLE `campaign_target_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `campaign_target_list_excluding`
--

DROP TABLE IF EXISTS `campaign_target_list_excluding`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `campaign_target_list_excluding` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `campaign_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_list_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_CAMPAIGN_ID_TARGET_LIST_ID` (`campaign_id`,`target_list_id`),
  KEY `IDX_CAMPAIGN_ID` (`campaign_id`),
  KEY `IDX_TARGET_LIST_ID` (`target_list_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `campaign_target_list_excluding`
--

LOCK TABLES `campaign_target_list_excluding` WRITE;
/*!40000 ALTER TABLE `campaign_target_list_excluding` DISABLE KEYS */;
/*!40000 ALTER TABLE `campaign_target_list_excluding` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `campaign_tracking_url`
--

DROP TABLE IF EXISTS `campaign_tracking_url`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `campaign_tracking_url` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `action` varchar(12) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Redirect',
  `message` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `modified_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `campaign_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_CAMPAIGN_ID` (`campaign_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `campaign_tracking_url`
--

LOCK TABLES `campaign_tracking_url` WRITE;
/*!40000 ALTER TABLE `campaign_tracking_url` DISABLE KEYS */;
/*!40000 ALTER TABLE `campaign_tracking_url` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `case`
--

DROP TABLE IF EXISTS `case`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `case` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `number` int unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'New',
  `priority` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Normal',
  `type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `is_internal` tinyint NOT NULL DEFAULT '0',
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `stream_updated_at` datetime DEFAULT NULL,
  `account_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lead_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `inbound_email_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `assigned_user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `version_number` bigint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_NUMBER` (`number`),
  KEY `IDX_STATUS` (`status`,`deleted`),
  KEY `IDX_ASSIGNED_USER` (`assigned_user_id`,`deleted`),
  KEY `IDX_ASSIGNED_USER_STATUS` (`assigned_user_id`,`status`),
  KEY `IDX_ACCOUNT_ID` (`account_id`),
  KEY `IDX_LEAD_ID` (`lead_id`),
  KEY `IDX_CONTACT_ID` (`contact_id`),
  KEY `IDX_INBOUND_EMAIL_ID` (`inbound_email_id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`),
  KEY `IDX_ASSIGNED_USER_ID` (`assigned_user_id`),
  FULLTEXT KEY `IDX_SYSTEM_FULL_TEXT_SEARCH` (`name`,`description`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `case`
--

LOCK TABLES `case` WRITE;
/*!40000 ALTER TABLE `case` DISABLE KEYS */;
/*!40000 ALTER TABLE `case` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `case_contact`
--

DROP TABLE IF EXISTS `case_contact`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `case_contact` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `case_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_CASE_ID_CONTACT_ID` (`case_id`,`contact_id`),
  KEY `IDX_CASE_ID` (`case_id`),
  KEY `IDX_CONTACT_ID` (`contact_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `case_contact`
--

LOCK TABLES `case_contact` WRITE;
/*!40000 ALTER TABLE `case_contact` DISABLE KEYS */;
/*!40000 ALTER TABLE `case_contact` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `case_knowledge_base_article`
--

DROP TABLE IF EXISTS `case_knowledge_base_article`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `case_knowledge_base_article` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `case_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `knowledge_base_article_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_CASE_ID_KNOWLEDGE_BASE_ARTICLE_ID` (`case_id`,`knowledge_base_article_id`),
  KEY `IDX_CASE_ID` (`case_id`),
  KEY `IDX_KNOWLEDGE_BASE_ARTICLE_ID` (`knowledge_base_article_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `case_knowledge_base_article`
--

LOCK TABLES `case_knowledge_base_article` WRITE;
/*!40000 ALTER TABLE `case_knowledge_base_article` DISABLE KEYS */;
/*!40000 ALTER TABLE `case_knowledge_base_article` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contact`
--

DROP TABLE IF EXISTS `contact`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contact` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint DEFAULT '0',
  `salutation_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `first_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `do_not_call` tinyint NOT NULL DEFAULT '0',
  `address_street` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_city` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_state` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_country` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_postal_code` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `middle_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `stream_updated_at` datetime DEFAULT NULL,
  `account_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `campaign_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `assigned_user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_CREATED_AT_ID` (`created_at`,`id`),
  KEY `IDX_CREATED_AT` (`created_at`,`deleted`),
  KEY `IDX_FIRST_NAME` (`first_name`,`deleted`),
  KEY `IDX_NAME` (`first_name`,`last_name`),
  KEY `IDX_ASSIGNED_USER` (`assigned_user_id`,`deleted`),
  KEY `IDX_ACCOUNT_ID` (`account_id`),
  KEY `IDX_CAMPAIGN_ID` (`campaign_id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`),
  KEY `IDX_ASSIGNED_USER_ID` (`assigned_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contact`
--

LOCK TABLES `contact` WRITE;
/*!40000 ALTER TABLE `contact` DISABLE KEYS */;
INSERT INTO `contact` VALUES ('8795e37e5d45d44a3',0,'Mr.','Ganesh','Kumar','Cinemax is the SuperMall',0,'chennai','Chennai','TN','India','600122','2026-11-20 20:16:23','2026-11-20 20:16:23',NULL,'2026-11-20 20:16:23','4a097347c0ebd6aff',NULL,'8975be1e209554aaf',NULL,NULL);
/*!40000 ALTER TABLE `contact` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contact_document`
--

DROP TABLE IF EXISTS `contact_document`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contact_document` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `contact_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `document_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_CONTACT_ID_DOCUMENT_ID` (`contact_id`,`document_id`),
  KEY `IDX_CONTACT_ID` (`contact_id`),
  KEY `IDX_DOCUMENT_ID` (`document_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contact_document`
--

LOCK TABLES `contact_document` WRITE;
/*!40000 ALTER TABLE `contact_document` DISABLE KEYS */;
/*!40000 ALTER TABLE `contact_document` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contact_meeting`
--

DROP TABLE IF EXISTS `contact_meeting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contact_meeting` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `contact_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meeting_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'None',
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_CONTACT_ID_MEETING_ID` (`contact_id`,`meeting_id`),
  KEY `IDX_CONTACT_ID` (`contact_id`),
  KEY `IDX_MEETING_ID` (`meeting_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contact_meeting`
--

LOCK TABLES `contact_meeting` WRITE;
/*!40000 ALTER TABLE `contact_meeting` DISABLE KEYS */;
/*!40000 ALTER TABLE `contact_meeting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contact_opportunity`
--

DROP TABLE IF EXISTS `contact_opportunity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contact_opportunity` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `contact_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `opportunity_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_CONTACT_ID_OPPORTUNITY_ID` (`contact_id`,`opportunity_id`),
  KEY `IDX_CONTACT_ID` (`contact_id`),
  KEY `IDX_OPPORTUNITY_ID` (`opportunity_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contact_opportunity`
--

LOCK TABLES `contact_opportunity` WRITE;
/*!40000 ALTER TABLE `contact_opportunity` DISABLE KEYS */;
INSERT INTO `contact_opportunity` VALUES (1,'8795e37e5d45d44a3','7c97eb7ee580bd504',NULL,0);
/*!40000 ALTER TABLE `contact_opportunity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contact_target_list`
--

DROP TABLE IF EXISTS `contact_target_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contact_target_list` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `contact_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_list_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `opted_out` tinyint DEFAULT '0',
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_CONTACT_ID_TARGET_LIST_ID` (`contact_id`,`target_list_id`),
  KEY `IDX_CONTACT_ID` (`contact_id`),
  KEY `IDX_TARGET_LIST_ID` (`target_list_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contact_target_list`
--

LOCK TABLES `contact_target_list` WRITE;
/*!40000 ALTER TABLE `contact_target_list` DISABLE KEYS */;
/*!40000 ALTER TABLE `contact_target_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `currency`
--

DROP TABLE IF EXISTS `currency`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `currency` (
  `id` varchar(3) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `rate` double DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `currency`
--

LOCK TABLES `currency` WRITE;
/*!40000 ALTER TABLE `currency` DISABLE KEYS */;
INSERT INTO `currency` VALUES ('USD',1);
/*!40000 ALTER TABLE `currency` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `currency_record`
--

DROP TABLE IF EXISTS `currency_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `currency_record` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint DEFAULT '0',
  `code` varchar(3) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(8) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Active',
  `delete_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_CODE_DELETE_ID` (`code`,`delete_id`),
  KEY `IDX_CODE` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `currency_record`
--

LOCK TABLES `currency_record` WRITE;
/*!40000 ALTER TABLE `currency_record` DISABLE KEYS */;
INSERT INTO `currency_record` VALUES ('b222f992dd961682c',0,'USD','Active','0');
/*!40000 ALTER TABLE `currency_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `currency_record_rate`
--

DROP TABLE IF EXISTS `currency_record_rate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `currency_record_rate` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint DEFAULT '0',
  `base_code` varchar(3) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date` date DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `delete_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `record_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rate` decimal(20,8) DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_RECORD_ID_BASE_CODE_DATE` (`record_id`,`base_code`,`date`,`delete_id`),
  KEY `IDX_RECORD_ID` (`record_id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `currency_record_rate`
--

LOCK TABLES `currency_record_rate` WRITE;
/*!40000 ALTER TABLE `currency_record_rate` DISABLE KEYS */;
/*!40000 ALTER TABLE `currency_record_rate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dashboard_template`
--

DROP TABLE IF EXISTS `dashboard_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dashboard_template` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `layout` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `dashlets_options` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dashboard_template`
--

LOCK TABLES `dashboard_template` WRITE;
/*!40000 ALTER TABLE `dashboard_template` DISABLE KEYS */;
INSERT INTO `dashboard_template` VALUES ('5b0224715472ad4e8','Sales Team',0,'[{\"name\":\"My Espo\",\"layout\":[{\"id\":\"d566253\",\"name\":\"CheckIn\",\"x\":0,\"y\":0,\"width\":1.3333333333333333,\"height\":1.75},{\"id\":\"d557461\",\"name\":\"Stream\",\"x\":1.3333333333333333,\"y\":0,\"width\":1.3333333333333333,\"height\":1.75},{\"id\":\"d235921\",\"name\":\"Activities\",\"x\":2.6666666666666665,\"y\":0,\"width\":1.3333333333333333,\"height\":1.75},{\"id\":\"d832061\",\"name\":\"Calendar\",\"x\":0,\"y\":1.75,\"width\":4,\"height\":2.25}],\"id\":\"9612022\"}]','{}','2026-11-20 19:40:24','2026-11-20 20:06:22','8975be1e209554aaf','8975be1e209554aaf');
/*!40000 ALTER TABLE `dashboard_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `document`
--

DROP TABLE IF EXISTS `document`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `document` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Active',
  `type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `publish_date` date DEFAULT NULL,
  `expiration_date` date DEFAULT NULL,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `file_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `assigned_user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `folder_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`),
  KEY `IDX_ASSIGNED_USER_ID` (`assigned_user_id`),
  KEY `IDX_FOLDER_ID` (`folder_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `document`
--

LOCK TABLES `document` WRITE;
/*!40000 ALTER TABLE `document` DISABLE KEYS */;
/*!40000 ALTER TABLE `document` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `document_folder`
--

DROP TABLE IF EXISTS `document_folder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `document_folder` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`),
  KEY `IDX_PARENT_ID` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `document_folder`
--

LOCK TABLES `document_folder` WRITE;
/*!40000 ALTER TABLE `document_folder` DISABLE KEYS */;
/*!40000 ALTER TABLE `document_folder` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `document_folder_path`
--

DROP TABLE IF EXISTS `document_folder_path`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `document_folder_path` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ascendor_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `descendor_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_ASCENDOR_ID` (`ascendor_id`),
  KEY `IDX_DESCENDOR_ID` (`descendor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `document_folder_path`
--

LOCK TABLES `document_folder_path` WRITE;
/*!40000 ALTER TABLE `document_folder_path` DISABLE KEYS */;
/*!40000 ALTER TABLE `document_folder_path` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `document_lead`
--

DROP TABLE IF EXISTS `document_lead`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `document_lead` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `document_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lead_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_DOCUMENT_ID_LEAD_ID` (`document_id`,`lead_id`),
  KEY `IDX_DOCUMENT_ID` (`document_id`),
  KEY `IDX_LEAD_ID` (`lead_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `document_lead`
--

LOCK TABLES `document_lead` WRITE;
/*!40000 ALTER TABLE `document_lead` DISABLE KEYS */;
/*!40000 ALTER TABLE `document_lead` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `document_opportunity`
--

DROP TABLE IF EXISTS `document_opportunity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `document_opportunity` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `document_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `opportunity_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_DOCUMENT_ID_OPPORTUNITY_ID` (`document_id`,`opportunity_id`),
  KEY `IDX_DOCUMENT_ID` (`document_id`),
  KEY `IDX_OPPORTUNITY_ID` (`opportunity_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `document_opportunity`
--

LOCK TABLES `document_opportunity` WRITE;
/*!40000 ALTER TABLE `document_opportunity` DISABLE KEYS */;
/*!40000 ALTER TABLE `document_opportunity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email`
--

DROP TABLE IF EXISTS `email`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `email` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `from_string` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reply_to_string` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_name_map` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `is_replied` tinyint NOT NULL DEFAULT '0',
  `message_id` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `message_id_internal` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `body_plain` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `body` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `is_html` tinyint NOT NULL DEFAULT '1',
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Archived',
  `has_attachment` tinyint NOT NULL DEFAULT '0',
  `date_sent` datetime DEFAULT NULL,
  `delivery_date` datetime DEFAULT NULL,
  `send_at` datetime DEFAULT NULL,
  `is_auto_reply` tinyint NOT NULL DEFAULT '0',
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `is_system` tinyint NOT NULL DEFAULT '0',
  `ics_contents` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `ics_event_uid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `group_status_folder` varchar(7) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `from_email_address_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sent_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `assigned_user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `replied_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_event_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_event_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `group_folder_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `account_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_DATE_SENT` (`date_sent`,`deleted`),
  KEY `IDX_DATE_SENT_STATUS` (`date_sent`,`status`,`deleted`),
  KEY `IDX_MESSAGE_ID` (`message_id`),
  KEY `IDX_ICS_EVENT_UID` (`ics_event_uid`),
  KEY `IDX_GROUP_STATUS_FOLDER` (`group_status_folder`),
  KEY `IDX_FROM_EMAIL_ADDRESS_ID` (`from_email_address_id`),
  KEY `IDX_PARENT` (`parent_id`,`parent_type`),
  KEY `IDX_SENT_BY_ID` (`sent_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`),
  KEY `IDX_ASSIGNED_USER_ID` (`assigned_user_id`),
  KEY `IDX_REPLIED_ID` (`replied_id`),
  KEY `IDX_CREATED_EVENT` (`created_event_id`,`created_event_type`),
  KEY `IDX_GROUP_FOLDER_ID` (`group_folder_id`),
  KEY `IDX_ACCOUNT_ID` (`account_id`),
  FULLTEXT KEY `IDX_SYSTEM_FULL_TEXT_SEARCH` (`name`,`body_plain`,`body`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email`
--

LOCK TABLES `email` WRITE;
/*!40000 ALTER TABLE `email` DISABLE KEYS */;
/*!40000 ALTER TABLE `email` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_account`
--

DROP TABLE IF EXISTS `email_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_account` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `email_address` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Active',
  `host` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `port` int DEFAULT '993',
  `security` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'SSL',
  `username` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `monitored_folders` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `sent_folder` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `folder_map` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `store_sent_emails` tinyint NOT NULL DEFAULT '0',
  `keep_fetched_emails_unread` tinyint NOT NULL DEFAULT '0',
  `fetch_validity_number` int DEFAULT '0',
  `fetch_since` date DEFAULT NULL,
  `fetch_data` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `connected_at` datetime DEFAULT NULL,
  `use_imap` tinyint NOT NULL DEFAULT '1',
  `use_smtp` tinyint NOT NULL DEFAULT '0',
  `smtp_host` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `smtp_port` int DEFAULT '587',
  `smtp_auth` tinyint NOT NULL DEFAULT '1',
  `smtp_security` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'TLS',
  `smtp_username` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `smtp_password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `smtp_auth_mechanism` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'login',
  `imap_handler` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `smtp_handler` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_folder_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `assigned_user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_EMAIL_FOLDER_ID` (`email_folder_id`),
  KEY `IDX_ASSIGNED_USER_ID` (`assigned_user_id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_account`
--

LOCK TABLES `email_account` WRITE;
/*!40000 ALTER TABLE `email_account` DISABLE KEYS */;
/*!40000 ALTER TABLE `email_account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_address`
--

DROP TABLE IF EXISTS `email_address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_address` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `lower` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `invalid` tinyint NOT NULL DEFAULT '0',
  `opt_out` tinyint NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `IDX_LOWER` (`lower`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_address`
--

LOCK TABLES `email_address` WRITE;
/*!40000 ALTER TABLE `email_address` DISABLE KEYS */;
INSERT INTO `email_address` VALUES ('b5b1b0fbbd5b7e6c4','cinemax@gmail.com',0,'cinemax@gmail.com',0,0);
/*!40000 ALTER TABLE `email_address` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_email_account`
--

DROP TABLE IF EXISTS `email_email_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_email_account` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `email_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_account_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_EMAIL_ID_EMAIL_ACCOUNT_ID` (`email_id`,`email_account_id`),
  KEY `IDX_EMAIL_ID` (`email_id`),
  KEY `IDX_EMAIL_ACCOUNT_ID` (`email_account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_email_account`
--

LOCK TABLES `email_email_account` WRITE;
/*!40000 ALTER TABLE `email_email_account` DISABLE KEYS */;
/*!40000 ALTER TABLE `email_email_account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_email_address`
--

DROP TABLE IF EXISTS `email_email_address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_email_address` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `email_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_address_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_type` varchar(4) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_EMAIL_ID_EMAIL_ADDRESS_ID_ADDRESS_TYPE` (`email_id`,`email_address_id`,`address_type`),
  KEY `IDX_EMAIL_ID` (`email_id`),
  KEY `IDX_EMAIL_ADDRESS_ID` (`email_address_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_email_address`
--

LOCK TABLES `email_email_address` WRITE;
/*!40000 ALTER TABLE `email_email_address` DISABLE KEYS */;
/*!40000 ALTER TABLE `email_email_address` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_filter`
--

DROP TABLE IF EXISTS `email_filter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_filter` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `from` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `to` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subject` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `body_contains` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `body_contains_all` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `is_global` tinyint NOT NULL DEFAULT '0',
  `action` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Skip',
  `mark_as_read` tinyint NOT NULL DEFAULT '0',
  `skip_notification` tinyint NOT NULL DEFAULT '0',
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `parent_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_folder_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `group_email_folder_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_PARENT` (`parent_id`,`parent_type`),
  KEY `IDX_EMAIL_FOLDER_ID` (`email_folder_id`),
  KEY `IDX_GROUP_EMAIL_FOLDER_ID` (`group_email_folder_id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_filter`
--

LOCK TABLES `email_filter` WRITE;
/*!40000 ALTER TABLE `email_filter` DISABLE KEYS */;
/*!40000 ALTER TABLE `email_filter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_folder`
--

DROP TABLE IF EXISTS `email_folder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_folder` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `order` int DEFAULT NULL,
  `skip_notifications` tinyint NOT NULL DEFAULT '0',
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `assigned_user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_ASSIGNED_USER_ID` (`assigned_user_id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_folder`
--

LOCK TABLES `email_folder` WRITE;
/*!40000 ALTER TABLE `email_folder` DISABLE KEYS */;
/*!40000 ALTER TABLE `email_folder` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_inbound_email`
--

DROP TABLE IF EXISTS `email_inbound_email`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_inbound_email` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `email_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `inbound_email_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_EMAIL_ID_INBOUND_EMAIL_ID` (`email_id`,`inbound_email_id`),
  KEY `IDX_EMAIL_ID` (`email_id`),
  KEY `IDX_INBOUND_EMAIL_ID` (`inbound_email_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_inbound_email`
--

LOCK TABLES `email_inbound_email` WRITE;
/*!40000 ALTER TABLE `email_inbound_email` DISABLE KEYS */;
/*!40000 ALTER TABLE `email_inbound_email` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_queue_item`
--

DROP TABLE IF EXISTS `email_queue_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_queue_item` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint DEFAULT '0',
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attempt_count` int DEFAULT '0',
  `created_at` datetime DEFAULT NULL,
  `sent_at` datetime DEFAULT NULL,
  `email_address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_test` tinyint NOT NULL DEFAULT '0',
  `mass_email_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_SENT_AT` (`sent_at`),
  KEY `IDX_MASS_EMAIL_ID` (`mass_email_id`),
  KEY `IDX_TARGET` (`target_id`,`target_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_queue_item`
--

LOCK TABLES `email_queue_item` WRITE;
/*!40000 ALTER TABLE `email_queue_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `email_queue_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_template`
--

DROP TABLE IF EXISTS `email_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_template` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `subject` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `body` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `is_html` tinyint NOT NULL DEFAULT '1',
  `status` varchar(8) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Active',
  `one_off` tinyint NOT NULL DEFAULT '0',
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `category_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `assigned_user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `version_number` bigint DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `IDX_CATEGORY_ID` (`category_id`),
  KEY `IDX_ASSIGNED_USER_ID` (`assigned_user_id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_template`
--

LOCK TABLES `email_template` WRITE;
/*!40000 ALTER TABLE `email_template` DISABLE KEYS */;
/*!40000 ALTER TABLE `email_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_template_category`
--

DROP TABLE IF EXISTS `email_template_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_template_category` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `order` int DEFAULT NULL,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`),
  KEY `IDX_PARENT_ID` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_template_category`
--

LOCK TABLES `email_template_category` WRITE;
/*!40000 ALTER TABLE `email_template_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `email_template_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_template_category_path`
--

DROP TABLE IF EXISTS `email_template_category_path`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_template_category_path` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ascendor_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `descendor_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_ASCENDOR_ID` (`ascendor_id`),
  KEY `IDX_DESCENDOR_ID` (`descendor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_template_category_path`
--

LOCK TABLES `email_template_category_path` WRITE;
/*!40000 ALTER TABLE `email_template_category_path` DISABLE KEYS */;
/*!40000 ALTER TABLE `email_template_category_path` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_user`
--

DROP TABLE IF EXISTS `email_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_user` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `email_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_read` tinyint DEFAULT '0',
  `is_important` tinyint DEFAULT '0',
  `in_trash` tinyint DEFAULT '0',
  `in_archive` tinyint DEFAULT '0',
  `folder_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_EMAIL_ID_USER_ID` (`email_id`,`user_id`),
  KEY `IDX_EMAIL_ID` (`email_id`),
  KEY `IDX_USER_ID` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_user`
--

LOCK TABLES `email_user` WRITE;
/*!40000 ALTER TABLE `email_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `email_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entity_collaborator`
--

DROP TABLE IF EXISTS `entity_collaborator`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entity_collaborator` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `entity_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `entity_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_ENTITY_ID_USER_ID_ENTITY_TYPE` (`entity_id`,`user_id`,`entity_type`),
  KEY `IDX_ENTITY_ID` (`entity_id`),
  KEY `IDX_USER_ID` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entity_collaborator`
--

LOCK TABLES `entity_collaborator` WRITE;
/*!40000 ALTER TABLE `entity_collaborator` DISABLE KEYS */;
/*!40000 ALTER TABLE `entity_collaborator` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entity_email_address`
--

DROP TABLE IF EXISTS `entity_email_address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entity_email_address` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `entity_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_address_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `entity_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `primary` tinyint DEFAULT '0',
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_ENTITY_ID_EMAIL_ADDRESS_ID_ENTITY_TYPE` (`entity_id`,`email_address_id`,`entity_type`),
  KEY `IDX_ENTITY_ID` (`entity_id`),
  KEY `IDX_EMAIL_ADDRESS_ID` (`email_address_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entity_email_address`
--

LOCK TABLES `entity_email_address` WRITE;
/*!40000 ALTER TABLE `entity_email_address` DISABLE KEYS */;
INSERT INTO `entity_email_address` VALUES (1,'064cbaa61185d2fb2','b5b1b0fbbd5b7e6c4','Lead',1,0),(2,'4a097347c0ebd6aff','b5b1b0fbbd5b7e6c4','Account',1,0),(3,'8795e37e5d45d44a3','b5b1b0fbbd5b7e6c4','Contact',1,0);
/*!40000 ALTER TABLE `entity_email_address` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entity_phone_number`
--

DROP TABLE IF EXISTS `entity_phone_number`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entity_phone_number` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `entity_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone_number_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `entity_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `primary` tinyint DEFAULT '0',
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_ENTITY_ID_PHONE_NUMBER_ID_ENTITY_TYPE` (`entity_id`,`phone_number_id`,`entity_type`),
  KEY `IDX_ENTITY_ID` (`entity_id`),
  KEY `IDX_PHONE_NUMBER_ID` (`phone_number_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entity_phone_number`
--

LOCK TABLES `entity_phone_number` WRITE;
/*!40000 ALTER TABLE `entity_phone_number` DISABLE KEYS */;
INSERT INTO `entity_phone_number` VALUES (1,'064cbaa61185d2fb2','177e08ab14964cd46','Lead',1,0),(2,'4a097347c0ebd6aff','177e08ab14964cd46','Account',1,0),(3,'8795e37e5d45d44a3','177e08ab14964cd46','Contact',1,0);
/*!40000 ALTER TABLE `entity_phone_number` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entity_team`
--

DROP TABLE IF EXISTS `entity_team`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entity_team` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `entity_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `team_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `entity_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_ENTITY_ID_TEAM_ID_ENTITY_TYPE` (`entity_id`,`team_id`,`entity_type`),
  KEY `IDX_ENTITY_ID` (`entity_id`),
  KEY `IDX_TEAM_ID` (`team_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entity_team`
--

LOCK TABLES `entity_team` WRITE;
/*!40000 ALTER TABLE `entity_team` DISABLE KEYS */;
INSERT INTO `entity_team` VALUES (1,'26a23642611410415','d7b229038af2056a8','CJob',0),(2,'1beaa2ed6d39769fc','d7b229038af2056a8','CJob',0),(3,'064cbaa61185d2fb2','d7b229038af2056a8','Lead',0),(4,'4a097347c0ebd6aff','d7b229038af2056a8','Account',0),(5,'8795e37e5d45d44a3','d7b229038af2056a8','Contact',0),(6,'7c97eb7ee580bd504','d7b229038af2056a8','Opportunity',0);
/*!40000 ALTER TABLE `entity_team` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entity_user`
--

DROP TABLE IF EXISTS `entity_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entity_user` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `entity_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `entity_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_ENTITY_ID_USER_ID_ENTITY_TYPE` (`entity_id`,`user_id`,`entity_type`),
  KEY `IDX_ENTITY_ID` (`entity_id`),
  KEY `IDX_USER_ID` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entity_user`
--

LOCK TABLES `entity_user` WRITE;
/*!40000 ALTER TABLE `entity_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `entity_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `export`
--

DROP TABLE IF EXISTS `export`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `export` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint DEFAULT '0',
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Pending',
  `params` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL,
  `notify_on_finish` tinyint NOT NULL DEFAULT '0',
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attachment_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_ATTACHMENT` (`attachment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `export`
--

LOCK TABLES `export` WRITE;
/*!40000 ALTER TABLE `export` DISABLE KEYS */;
/*!40000 ALTER TABLE `export` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `extension`
--

DROP TABLE IF EXISTS `extension`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `extension` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `version` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_list` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `license_status` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `license_status_message` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `is_installed` tinyint NOT NULL DEFAULT '0',
  `check_version_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_LICENSE_STATUS` (`license_status`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `extension`
--

LOCK TABLES `extension` WRITE;
/*!40000 ALTER TABLE `extension` DISABLE KEYS */;
/*!40000 ALTER TABLE `extension` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `external_account`
--

DROP TABLE IF EXISTS `external_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `external_account` (
  `id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint DEFAULT '0',
  `data` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `enabled` tinyint NOT NULL DEFAULT '0',
  `is_locked` tinyint NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `external_account`
--

LOCK TABLES `external_account` WRITE;
/*!40000 ALTER TABLE `external_account` DISABLE KEYS */;
/*!40000 ALTER TABLE `external_account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `group_email_folder`
--

DROP TABLE IF EXISTS `group_email_folder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `group_email_folder` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `order` int DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `group_email_folder`
--

LOCK TABLES `group_email_folder` WRITE;
/*!40000 ALTER TABLE `group_email_folder` DISABLE KEYS */;
/*!40000 ALTER TABLE `group_email_folder` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `group_email_folder_team`
--

DROP TABLE IF EXISTS `group_email_folder_team`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `group_email_folder_team` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `group_email_folder_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `team_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_GROUP_EMAIL_FOLDER_ID_TEAM_ID` (`group_email_folder_id`,`team_id`),
  KEY `IDX_GROUP_EMAIL_FOLDER_ID` (`group_email_folder_id`),
  KEY `IDX_TEAM_ID` (`team_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `group_email_folder_team`
--

LOCK TABLES `group_email_folder_team` WRITE;
/*!40000 ALTER TABLE `group_email_folder_team` DISABLE KEYS */;
/*!40000 ALTER TABLE `group_email_folder_team` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `import`
--

DROP TABLE IF EXISTS `import`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `import` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint DEFAULT '0',
  `entity_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_index` int DEFAULT NULL,
  `params` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `attribute_list` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL,
  `file_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `import`
--

LOCK TABLES `import` WRITE;
/*!40000 ALTER TABLE `import` DISABLE KEYS */;
/*!40000 ALTER TABLE `import` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `import_entity`
--

DROP TABLE IF EXISTS `import_entity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `import_entity` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `deleted` tinyint DEFAULT '0',
  `is_imported` tinyint NOT NULL DEFAULT '0',
  `is_updated` tinyint NOT NULL DEFAULT '0',
  `is_duplicate` tinyint NOT NULL DEFAULT '0',
  `entity_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `entity_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `import_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_ENTITY_IMPORT` (`import_id`,`entity_type`),
  KEY `IDX_ENTITY` (`entity_id`,`entity_type`),
  KEY `IDX_IMPORT` (`import_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `import_entity`
--

LOCK TABLES `import_entity` WRITE;
/*!40000 ALTER TABLE `import_entity` DISABLE KEYS */;
/*!40000 ALTER TABLE `import_entity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `import_error`
--

DROP TABLE IF EXISTS `import_error`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `import_error` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint DEFAULT '0',
  `row_index` int DEFAULT NULL,
  `export_row_index` int DEFAULT NULL,
  `type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `validation_failures` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `row` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `import_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_ROW_INDEX` (`row_index`),
  KEY `IDX_IMPORT_ROW_INDEX` (`import_id`,`row_index`),
  KEY `IDX_IMPORT_ID` (`import_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `import_error`
--

LOCK TABLES `import_error` WRITE;
/*!40000 ALTER TABLE `import_error` DISABLE KEYS */;
/*!40000 ALTER TABLE `import_error` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inbound_email`
--

DROP TABLE IF EXISTS `inbound_email`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inbound_email` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `email_address` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Active',
  `host` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `port` int DEFAULT '993',
  `security` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'SSL',
  `username` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `monitored_folders` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `fetch_validity_number` int DEFAULT '0',
  `fetch_since` date DEFAULT NULL,
  `fetch_data` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `add_all_team_users` tinyint NOT NULL DEFAULT '1',
  `sent_folder` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `store_sent_emails` tinyint NOT NULL DEFAULT '0',
  `keep_fetched_emails_unread` tinyint NOT NULL DEFAULT '0',
  `connected_at` datetime DEFAULT NULL,
  `exclude_from_reply` tinyint NOT NULL DEFAULT '0',
  `use_imap` tinyint NOT NULL DEFAULT '1',
  `use_smtp` tinyint NOT NULL DEFAULT '0',
  `smtp_is_shared` tinyint NOT NULL DEFAULT '0',
  `smtp_is_for_mass_email` tinyint NOT NULL DEFAULT '0',
  `smtp_host` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `smtp_port` int DEFAULT '587',
  `smtp_auth` tinyint NOT NULL DEFAULT '1',
  `smtp_security` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'TLS',
  `smtp_username` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `smtp_password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `smtp_auth_mechanism` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'login',
  `create_case` tinyint NOT NULL DEFAULT '0',
  `case_distribution` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Direct-Assignment',
  `target_user_position` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reply` tinyint NOT NULL DEFAULT '0',
  `reply_from_address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reply_to_address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reply_from_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `from_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `imap_handler` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `smtp_handler` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `assign_to_user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `team_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reply_email_template_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `group_email_folder_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_ASSIGN_TO_USER_ID` (`assign_to_user_id`),
  KEY `IDX_TEAM_ID` (`team_id`),
  KEY `IDX_REPLY_EMAIL_TEMPLATE_ID` (`reply_email_template_id`),
  KEY `IDX_GROUP_EMAIL_FOLDER_ID` (`group_email_folder_id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inbound_email`
--

LOCK TABLES `inbound_email` WRITE;
/*!40000 ALTER TABLE `inbound_email` DISABLE KEYS */;
/*!40000 ALTER TABLE `inbound_email` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inbound_email_team`
--

DROP TABLE IF EXISTS `inbound_email_team`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inbound_email_team` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `inbound_email_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `team_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_INBOUND_EMAIL_ID_TEAM_ID` (`inbound_email_id`,`team_id`),
  KEY `IDX_INBOUND_EMAIL_ID` (`inbound_email_id`),
  KEY `IDX_TEAM_ID` (`team_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inbound_email_team`
--

LOCK TABLES `inbound_email_team` WRITE;
/*!40000 ALTER TABLE `inbound_email_team` DISABLE KEYS */;
/*!40000 ALTER TABLE `inbound_email_team` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `integration`
--

DROP TABLE IF EXISTS `integration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `integration` (
  `id` varchar(24) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint DEFAULT '0',
  `data` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `enabled` tinyint NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `integration`
--

LOCK TABLES `integration` WRITE;
/*!40000 ALTER TABLE `integration` DISABLE KEYS */;
/*!40000 ALTER TABLE `integration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job`
--

DROP TABLE IF EXISTS `job`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `job` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `status` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Pending',
  `execute_time` datetime DEFAULT NULL,
  `number` bigint unsigned NOT NULL AUTO_INCREMENT,
  `class_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `job` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `queue` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `group` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_group` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `started_at` datetime DEFAULT NULL,
  `executed_at` datetime DEFAULT NULL,
  `pid` int DEFAULT NULL,
  `attempts` int DEFAULT NULL,
  `target_id` varchar(48) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_type` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `failed_attempts` int DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `scheduled_job_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_NUMBER` (`number`),
  KEY `IDX_EXECUTE_TIME` (`status`,`execute_time`),
  KEY `IDX_STATUS` (`status`,`deleted`),
  KEY `IDX_STATUS_SCHEDULED_JOB_ID_TARGET` (`status`,`scheduled_job_id`,`target_type`,`target_id`),
  KEY `IDX_SCHEDULED_JOB_ID` (`scheduled_job_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job`
--

LOCK TABLES `job` WRITE;
/*!40000 ALTER TABLE `job` DISABLE KEYS */;
INSERT INTO `job` VALUES ('49df2152bc5c439f4','Espo\\Tools\\Stream\\Jobs\\ControlFollowers',0,'Pending','2026-11-20 12:55:35',1,'Espo\\Tools\\Stream\\Jobs\\ControlFollowers',NULL,'{\"entityType\":\"CJob\",\"entityId\":\"bee574c7672667f9a\"}','q1',NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,'2026-11-20 12:55:35','2026-11-20 12:55:35',NULL),('abf52b797689ccbb4','Espo\\Tools\\Stream\\Jobs\\ControlFollowers',0,'Pending','2026-11-20 20:28:30',2,'Espo\\Tools\\Stream\\Jobs\\ControlFollowers',NULL,'{\"entityType\":\"Lead\",\"entityId\":\"064cbaa61185d2fb2\"}','q1',NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,'2026-11-20 20:28:30','2026-11-20 20:28:30',NULL);
/*!40000 ALTER TABLE `job` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kanban_order`
--

DROP TABLE IF EXISTS `kanban_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `kanban_order` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint DEFAULT '0',
  `order` smallint DEFAULT NULL,
  `group` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `entity_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `entity_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_ENTITY_USER_ID` (`entity_type`,`entity_id`,`user_id`),
  KEY `IDX_ENTITY_TYPE` (`entity_type`),
  KEY `IDX_ENTITY_TYPE_USER_ID` (`entity_type`,`user_id`),
  KEY `IDX_ENTITY` (`entity_id`,`entity_type`),
  KEY `IDX_USER` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kanban_order`
--

LOCK TABLES `kanban_order` WRITE;
/*!40000 ALTER TABLE `kanban_order` DISABLE KEYS */;
/*!40000 ALTER TABLE `kanban_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `knowledge_base_article`
--

DROP TABLE IF EXISTS `knowledge_base_article`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `knowledge_base_article` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Draft',
  `language` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Article',
  `publish_date` date DEFAULT NULL,
  `expiration_date` date DEFAULT NULL,
  `order` int DEFAULT NULL,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `body` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `body_plain` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `is_html` tinyint NOT NULL DEFAULT '0',
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `assigned_user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `version_number` bigint DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`),
  KEY `IDX_ASSIGNED_USER_ID` (`assigned_user_id`),
  FULLTEXT KEY `IDX_SYSTEM_FULL_TEXT_SEARCH` (`name`,`body_plain`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `knowledge_base_article`
--

LOCK TABLES `knowledge_base_article` WRITE;
/*!40000 ALTER TABLE `knowledge_base_article` DISABLE KEYS */;
/*!40000 ALTER TABLE `knowledge_base_article` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `knowledge_base_article_knowledge_base_category`
--

DROP TABLE IF EXISTS `knowledge_base_article_knowledge_base_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `knowledge_base_article_knowledge_base_category` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `knowledge_base_article_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `knowledge_base_category_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_KNOWLEDGE_BASE_ARTICLE_ID_KNOWLEDGE_BASE_CATEGORY_ID` (`knowledge_base_article_id`,`knowledge_base_category_id`),
  KEY `IDX_KNOWLEDGE_BASE_ARTICLE_ID` (`knowledge_base_article_id`),
  KEY `IDX_KNOWLEDGE_BASE_CATEGORY_ID` (`knowledge_base_category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `knowledge_base_article_knowledge_base_category`
--

LOCK TABLES `knowledge_base_article_knowledge_base_category` WRITE;
/*!40000 ALTER TABLE `knowledge_base_article_knowledge_base_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `knowledge_base_article_knowledge_base_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `knowledge_base_article_portal`
--

DROP TABLE IF EXISTS `knowledge_base_article_portal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `knowledge_base_article_portal` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `portal_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `knowledge_base_article_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_PORTAL_ID_KNOWLEDGE_BASE_ARTICLE_ID` (`portal_id`,`knowledge_base_article_id`),
  KEY `IDX_PORTAL_ID` (`portal_id`),
  KEY `IDX_KNOWLEDGE_BASE_ARTICLE_ID` (`knowledge_base_article_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `knowledge_base_article_portal`
--

LOCK TABLES `knowledge_base_article_portal` WRITE;
/*!40000 ALTER TABLE `knowledge_base_article_portal` DISABLE KEYS */;
/*!40000 ALTER TABLE `knowledge_base_article_portal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `knowledge_base_category`
--

DROP TABLE IF EXISTS `knowledge_base_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `knowledge_base_category` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `order` int DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`),
  KEY `IDX_PARENT_ID` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `knowledge_base_category`
--

LOCK TABLES `knowledge_base_category` WRITE;
/*!40000 ALTER TABLE `knowledge_base_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `knowledge_base_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `knowledge_base_category_path`
--

DROP TABLE IF EXISTS `knowledge_base_category_path`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `knowledge_base_category_path` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ascendor_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `descendor_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_ASCENDOR_ID` (`ascendor_id`),
  KEY `IDX_DESCENDOR_ID` (`descendor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `knowledge_base_category_path`
--

LOCK TABLES `knowledge_base_category_path` WRITE;
/*!40000 ALTER TABLE `knowledge_base_category_path` DISABLE KEYS */;
/*!40000 ALTER TABLE `knowledge_base_category_path` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `layout_record`
--

DROP TABLE IF EXISTS `layout_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `layout_record` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `data` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `layout_set_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_NAME_LAYOUT_SET_ID` (`name`,`layout_set_id`),
  KEY `IDX_LAYOUT_SET_ID` (`layout_set_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `layout_record`
--

LOCK TABLES `layout_record` WRITE;
/*!40000 ALTER TABLE `layout_record` DISABLE KEYS */;
/*!40000 ALTER TABLE `layout_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `layout_set`
--

DROP TABLE IF EXISTS `layout_set`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `layout_set` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `layout_list` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `layout_set`
--

LOCK TABLES `layout_set` WRITE;
/*!40000 ALTER TABLE `layout_set` DISABLE KEYS */;
INSERT INTO `layout_set` VALUES ('d66569f305a169ea6','AList',0,NULL,'2026-11-20 19:06:54','2026-11-20 19:06:54');
/*!40000 ALTER TABLE `layout_set` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lead`
--

DROP TABLE IF EXISTS `lead`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lead` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint DEFAULT '0',
  `salutation_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `first_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'New',
  `source` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `industry` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `opportunity_amount` double DEFAULT NULL,
  `website` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_street` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_city` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_state` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_country` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_postal_code` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `do_not_call` tinyint NOT NULL DEFAULT '0',
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `converted_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `account_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `middle_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `opportunity_amount_currency` varchar(3) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `stream_updated_at` datetime DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `assigned_user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `campaign_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_account_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_contact_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_opportunity_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_CREATED_AT_ID` (`created_at`,`id`),
  KEY `IDX_FIRST_NAME` (`first_name`,`deleted`),
  KEY `IDX_NAME` (`first_name`,`last_name`),
  KEY `IDX_STATUS` (`status`,`deleted`),
  KEY `IDX_CREATED_AT` (`created_at`,`deleted`),
  KEY `IDX_CREATED_AT_STATUS` (`created_at`,`status`),
  KEY `IDX_ASSIGNED_USER` (`assigned_user_id`,`deleted`),
  KEY `IDX_ASSIGNED_USER_STATUS` (`assigned_user_id`,`status`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`),
  KEY `IDX_ASSIGNED_USER_ID` (`assigned_user_id`),
  KEY `IDX_CAMPAIGN_ID` (`campaign_id`),
  KEY `IDX_CREATED_ACCOUNT_ID` (`created_account_id`),
  KEY `IDX_CREATED_CONTACT_ID` (`created_contact_id`),
  KEY `IDX_CREATED_OPPORTUNITY_ID` (`created_opportunity_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lead`
--

LOCK TABLES `lead` WRITE;
/*!40000 ALTER TABLE `lead` DISABLE KEYS */;
INSERT INTO `lead` VALUES ('064cbaa61185d2fb2',0,'Mr.','Ganesh','Kumar','cinemax','Converted','Campaign','Entertainment & Leisure',65000,'www.cinemaxx.com','chennai','Chennai','TN','India','600122',0,'Cinemax is the SuperMall','2026-11-20 20:16:23','2026-11-20 20:14:53','2026-11-20 20:28:30','CineMax',NULL,'USD','2026-11-20 20:28:30','8975be1e209554aaf','8975be1e209554aaf','8975be1e209554aaf',NULL,'4a097347c0ebd6aff','8795e37e5d45d44a3','7c97eb7ee580bd504');
/*!40000 ALTER TABLE `lead` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lead_capture`
--

DROP TABLE IF EXISTS `lead_capture`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lead_capture` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `is_active` tinyint NOT NULL DEFAULT '1',
  `subscribe_to_target_list` tinyint NOT NULL DEFAULT '1',
  `subscribe_contact_to_target_list` tinyint NOT NULL DEFAULT '1',
  `field_list` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `field_params` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `duplicate_check` tinyint NOT NULL DEFAULT '1',
  `opt_in_confirmation` tinyint NOT NULL DEFAULT '0',
  `opt_in_confirmation_lifetime` int DEFAULT '48',
  `opt_in_confirmation_success_message` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `create_lead_before_opt_in_confirmation` tinyint NOT NULL DEFAULT '0',
  `skip_opt_in_confirmation_if_subscribed` tinyint NOT NULL DEFAULT '0',
  `lead_source` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Web Site',
  `api_key` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `form_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `form_enabled` tinyint NOT NULL DEFAULT '0',
  `form_title` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `form_theme` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `form_text` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `form_success_text` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `form_success_redirect_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `form_language` varchar(5) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `form_frame_ancestors` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `form_captcha` tinyint NOT NULL DEFAULT '0',
  `phone_number_country` varchar(2) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `campaign_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_list_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `opt_in_confirmation_email_template_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pipeline_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_team_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `inbound_email_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_CAMPAIGN_ID` (`campaign_id`),
  KEY `IDX_TARGET_LIST_ID` (`target_list_id`),
  KEY `IDX_OPT_IN_CONFIRMATION_EMAIL_TEMPLATE_ID` (`opt_in_confirmation_email_template_id`),
  KEY `IDX_PIPELINE_ID` (`pipeline_id`),
  KEY `IDX_TARGET_TEAM_ID` (`target_team_id`),
  KEY `IDX_INBOUND_EMAIL_ID` (`inbound_email_id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lead_capture`
--

LOCK TABLES `lead_capture` WRITE;
/*!40000 ALTER TABLE `lead_capture` DISABLE KEYS */;
/*!40000 ALTER TABLE `lead_capture` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lead_capture_log_record`
--

DROP TABLE IF EXISTS `lead_capture_log_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lead_capture_log_record` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint DEFAULT '0',
  `number` int unsigned NOT NULL AUTO_INCREMENT,
  `data` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `is_created` tinyint NOT NULL DEFAULT '0',
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL,
  `lead_capture_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_NUMBER` (`number`),
  KEY `IDX_LEAD_CAPTURE_ID` (`lead_capture_id`),
  KEY `IDX_TARGET` (`target_id`,`target_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lead_capture_log_record`
--

LOCK TABLES `lead_capture_log_record` WRITE;
/*!40000 ALTER TABLE `lead_capture_log_record` DISABLE KEYS */;
/*!40000 ALTER TABLE `lead_capture_log_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lead_meeting`
--

DROP TABLE IF EXISTS `lead_meeting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lead_meeting` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `lead_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meeting_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'None',
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_LEAD_ID_MEETING_ID` (`lead_id`,`meeting_id`),
  KEY `IDX_LEAD_ID` (`lead_id`),
  KEY `IDX_MEETING_ID` (`meeting_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lead_meeting`
--

LOCK TABLES `lead_meeting` WRITE;
/*!40000 ALTER TABLE `lead_meeting` DISABLE KEYS */;
/*!40000 ALTER TABLE `lead_meeting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lead_target_list`
--

DROP TABLE IF EXISTS `lead_target_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lead_target_list` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `lead_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_list_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `opted_out` tinyint DEFAULT '0',
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_LEAD_ID_TARGET_LIST_ID` (`lead_id`,`target_list_id`),
  KEY `IDX_LEAD_ID` (`lead_id`),
  KEY `IDX_TARGET_LIST_ID` (`target_list_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lead_target_list`
--

LOCK TABLES `lead_target_list` WRITE;
/*!40000 ALTER TABLE `lead_target_list` DISABLE KEYS */;
/*!40000 ALTER TABLE `lead_target_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mass_action`
--

DROP TABLE IF EXISTS `mass_action`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mass_action` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint DEFAULT '0',
  `entity_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `action` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Pending',
  `data` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `params` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL,
  `processed_count` int DEFAULT NULL,
  `notify_on_finish` tinyint NOT NULL DEFAULT '0',
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mass_action`
--

LOCK TABLES `mass_action` WRITE;
/*!40000 ALTER TABLE `mass_action` DISABLE KEYS */;
/*!40000 ALTER TABLE `mass_action` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mass_email`
--

DROP TABLE IF EXISTS `mass_email`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mass_email` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Pending',
  `store_sent_emails` tinyint NOT NULL DEFAULT '0',
  `opt_out_entirely` tinyint NOT NULL DEFAULT '0',
  `from_address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `from_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reply_to_address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reply_to_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `start_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `email_template_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `campaign_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `inbound_email_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_EMAIL_TEMPLATE_ID` (`email_template_id`),
  KEY `IDX_CAMPAIGN_ID` (`campaign_id`),
  KEY `IDX_INBOUND_EMAIL_ID` (`inbound_email_id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mass_email`
--

LOCK TABLES `mass_email` WRITE;
/*!40000 ALTER TABLE `mass_email` DISABLE KEYS */;
/*!40000 ALTER TABLE `mass_email` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mass_email_target_list`
--

DROP TABLE IF EXISTS `mass_email_target_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mass_email_target_list` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `mass_email_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_list_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_MASS_EMAIL_ID_TARGET_LIST_ID` (`mass_email_id`,`target_list_id`),
  KEY `IDX_MASS_EMAIL_ID` (`mass_email_id`),
  KEY `IDX_TARGET_LIST_ID` (`target_list_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mass_email_target_list`
--

LOCK TABLES `mass_email_target_list` WRITE;
/*!40000 ALTER TABLE `mass_email_target_list` DISABLE KEYS */;
/*!40000 ALTER TABLE `mass_email_target_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mass_email_target_list_excluding`
--

DROP TABLE IF EXISTS `mass_email_target_list_excluding`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mass_email_target_list_excluding` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `mass_email_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_list_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_MASS_EMAIL_ID_TARGET_LIST_ID` (`mass_email_id`,`target_list_id`),
  KEY `IDX_MASS_EMAIL_ID` (`mass_email_id`),
  KEY `IDX_TARGET_LIST_ID` (`target_list_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mass_email_target_list_excluding`
--

LOCK TABLES `mass_email_target_list_excluding` WRITE;
/*!40000 ALTER TABLE `mass_email_target_list_excluding` DISABLE KEYS */;
/*!40000 ALTER TABLE `mass_email_target_list_excluding` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `meeting`
--

DROP TABLE IF EXISTS `meeting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `meeting` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Planned',
  `date_start` datetime DEFAULT NULL,
  `date_end` datetime DEFAULT NULL,
  `is_all_day` tinyint NOT NULL DEFAULT '0',
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `uid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `join_url` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `external_service` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `date_start_date` date DEFAULT NULL,
  `date_end_date` date DEFAULT NULL,
  `stream_updated_at` datetime DEFAULT NULL,
  `parent_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `account_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `assigned_user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_DATE_START_STATUS` (`date_start`,`status`),
  KEY `IDX_DATE_START` (`date_start`,`deleted`),
  KEY `IDX_STATUS` (`status`,`deleted`),
  KEY `IDX_ASSIGNED_USER` (`assigned_user_id`,`deleted`),
  KEY `IDX_ASSIGNED_USER_STATUS` (`assigned_user_id`,`status`),
  KEY `IDX_UID` (`uid`),
  KEY `IDX_PARENT` (`parent_id`,`parent_type`),
  KEY `IDX_ACCOUNT_ID` (`account_id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`),
  KEY `IDX_ASSIGNED_USER_ID` (`assigned_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `meeting`
--

LOCK TABLES `meeting` WRITE;
/*!40000 ALTER TABLE `meeting` DISABLE KEYS */;
/*!40000 ALTER TABLE `meeting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `meeting_user`
--

DROP TABLE IF EXISTS `meeting_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `meeting_user` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meeting_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'None',
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_USER_ID_MEETING_ID` (`user_id`,`meeting_id`),
  KEY `IDX_USER_ID` (`user_id`),
  KEY `IDX_MEETING_ID` (`meeting_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `meeting_user`
--

LOCK TABLES `meeting_user` WRITE;
/*!40000 ALTER TABLE `meeting_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `meeting_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `next_number`
--

DROP TABLE IF EXISTS `next_number`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `next_number` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint DEFAULT '0',
  `entity_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `field_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `value` int DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `IDX_ENTITY_TYPE_FIELD_NAME` (`entity_type`,`field_name`),
  KEY `IDX_ENTITY_TYPE` (`entity_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `next_number`
--

LOCK TABLES `next_number` WRITE;
/*!40000 ALTER TABLE `next_number` DISABLE KEYS */;
/*!40000 ALTER TABLE `next_number` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `note`
--

DROP TABLE IF EXISTS `note`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `note` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint DEFAULT '0',
  `post` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `data` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `type` varchar(24) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Post',
  `target_type` varchar(7) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `number` bigint unsigned NOT NULL AUTO_INCREMENT,
  `is_global` tinyint NOT NULL DEFAULT '0',
  `is_internal` tinyint NOT NULL DEFAULT '0',
  `is_pinned` tinyint NOT NULL DEFAULT '0',
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `parent_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `related_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `related_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `super_parent_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `super_parent_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_NUMBER` (`number`),
  KEY `IDX_CREATED_AT` (`created_at`),
  KEY `IDX_CREATED_BY_NUMBER` (`created_by_id`,`number`),
  KEY `IDX_TYPE` (`type`),
  KEY `IDX_TARGET_TYPE` (`target_type`),
  KEY `IDX_PARENT_ID` (`parent_id`),
  KEY `IDX_PARENT_TYPE` (`parent_type`),
  KEY `IDX_RELATED_ID` (`related_id`),
  KEY `IDX_RELATED_TYPE` (`related_type`),
  KEY `IDX_SUPER_PARENT_TYPE` (`super_parent_type`),
  KEY `IDX_SUPER_PARENT_ID` (`super_parent_id`),
  KEY `IDX_PARENT` (`parent_id`,`parent_type`),
  KEY `IDX_RELATED` (`related_id`,`related_type`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`),
  KEY `IDX_SUPER_PARENT` (`super_parent_id`,`super_parent_type`),
  FULLTEXT KEY `IDX_SYSTEM_FULL_TEXT_SEARCH` (`post`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `note`
--

LOCK TABLES `note` WRITE;
/*!40000 ALTER TABLE `note` DISABLE KEYS */;
INSERT INTO `note` VALUES ('1234393a083abc55d',0,NULL,'{}','Create',NULL,2,0,0,0,'2026-11-20 12:10:47','2026-11-20 12:10:47','d766f3eec4a784423','CAMC',NULL,NULL,'8975be1e209554aaf',NULL,'fad196603b025835e','Account'),('1eb96f67787a90dd9',0,NULL,'{}','Create',NULL,3,0,0,0,'2026-11-20 12:16:43','2026-11-20 12:16:43','5172ba6f3bf9cf278','CJob',NULL,NULL,'8975be1e209554aaf',NULL,'fad196603b025835e','Account'),('2ba49df5cb635ea49',0,NULL,'{}','Create',NULL,1,0,0,0,'2026-11-20 11:53:11','2026-11-20 11:53:11','fad196603b025835e','Account',NULL,NULL,'8975be1e209554aaf',NULL,NULL,NULL),('32e3de34495282f6e',0,NULL,'{\"fields\":[\"data\"],\"attributes\":{\"was\":{\"data\":{\"CAMC\":{\"create\":\"yes\",\"read\":\"all\",\"edit\":\"all\",\"delete\":\"own\",\"stream\":\"all\"},\"CAttendance\":{\"create\":\"yes\",\"read\":\"own\",\"edit\":\"no\",\"delete\":\"no\",\"stream\":\"no\"},\"CDailyHours\":{\"create\":\"yes\",\"read\":\"own\",\"edit\":\"no\",\"delete\":\"no\",\"stream\":\"no\"},\"CJob\":{\"create\":\"no\",\"read\":\"team\",\"edit\":\"team\",\"delete\":\"no\",\"stream\":\"team\"},\"CWorkOrder\":{\"create\":\"no\",\"read\":\"team\",\"edit\":\"team\",\"delete\":\"no\",\"stream\":\"no\"}}},\"became\":{\"data\":{\"CAMC\":{\"create\":\"yes\",\"read\":\"all\",\"edit\":\"all\",\"delete\":\"own\",\"stream\":\"all\"},\"CAttendance\":{\"create\":\"yes\",\"read\":\"own\",\"edit\":\"no\",\"delete\":\"no\"},\"CDailyHours\":{\"create\":\"yes\",\"read\":\"own\",\"edit\":\"no\",\"delete\":\"no\"},\"CJob\":{\"create\":\"no\",\"read\":\"team\",\"edit\":\"team\",\"delete\":\"no\",\"stream\":\"team\"},\"CWorkOrder\":{\"create\":\"no\",\"read\":\"team\",\"edit\":\"team\",\"delete\":\"no\"}}}}}','Update',NULL,9,0,0,0,'2026-11-20 19:32:37','2026-11-20 19:32:37','76786855438bb890a','Role',NULL,NULL,'8975be1e209554aaf',NULL,NULL,NULL),('344997b47487b176e',0,NULL,'{}','Create',NULL,17,0,0,0,'2026-11-20 20:16:23','2026-11-20 20:16:23','4a097347c0ebd6aff','Account',NULL,NULL,'8975be1e209554aaf',NULL,NULL,NULL),('3a97290105d860087',0,NULL,'{}','Create',NULL,11,0,0,0,'2026-11-20 19:36:56','2026-11-20 19:36:56','26a23642611410415','CJob',NULL,NULL,'8975be1e209554aaf',NULL,'fad196603b025835e','Account'),('446b6bfa0f4dd8fc6',0,NULL,'{}','Create',NULL,18,0,0,0,'2026-11-20 20:16:23','2026-11-20 20:16:23','8795e37e5d45d44a3','Contact',NULL,NULL,'8975be1e209554aaf',NULL,'4a097347c0ebd6aff','Account'),('504a321afee4f251b',0,NULL,'{\"assignedUserId\":\"8975be1e209554aaf\",\"assignedUserName\":\"Admin\"}','Assign',NULL,5,0,0,0,'2026-11-20 12:55:35','2026-11-20 12:55:35','bee574c7672667f9a','CJob',NULL,NULL,'8975be1e209554aaf','8975be1e209554aaf','fad196603b025835e','Account'),('52b9aa0c995c6276a',0,NULL,'{\"statusValue\":\"In Process\",\"statusField\":\"status\"}','Create',NULL,16,0,0,0,'2026-11-20 20:14:53','2026-11-20 20:14:53','064cbaa61185d2fb2','Lead',NULL,NULL,'8975be1e209554aaf',NULL,NULL,NULL),('532aa970883a8d753',0,'Client Visit done\n','{}','Post',NULL,12,0,0,0,'2026-11-20 19:45:09','2026-11-20 19:45:09','26a23642611410415','CJob',NULL,NULL,'3a9d2245f7f443cd5',NULL,NULL,NULL),('56c5c7145f0aea688',0,NULL,'{\"fields\":[\"teams\",\"workingTimeCalendar\",\"layoutSet\"],\"attributes\":{\"was\":{\"teamsIds\":[],\"teamsColumns\":{},\"teamsNames\":{},\"workingTimeCalendarId\":null,\"workingTimeCalendarName\":null,\"layoutSetId\":null,\"layoutSetName\":null},\"became\":{\"teamsIds\":[\"d7b229038af2056a8\"],\"teamsColumns\":{\"d7b229038af2056a8\":{\"role\":null}},\"teamsNames\":{\"d7b229038af2056a8\":\"Sales Group A\"},\"workingTimeCalendarId\":\"0e7b49eaf73de54e3\",\"workingTimeCalendarName\":\"General Shift\",\"layoutSetId\":\"d66569f305a169ea6\",\"layoutSetName\":\"AList\"}}}','Update',NULL,7,0,0,0,'2026-11-20 19:20:05','2026-11-20 19:20:05','3a9d2245f7f443cd5','User',NULL,NULL,'8975be1e209554aaf',NULL,NULL,NULL),('63ae6de06528674b4',0,NULL,'{\"statusValue\":\"Prospecting\",\"statusField\":\"stage\"}','Create',NULL,14,0,0,0,'2026-11-20 20:09:58','2026-11-20 20:09:58','27b31c65ef0c038b5','Opportunity',NULL,NULL,'8975be1e209554aaf',NULL,NULL,NULL),('7a9a1171f912d614e',0,NULL,'{}','Create',NULL,23,0,0,0,'2026-11-20 20:35:27','2026-11-20 20:35:27','2d70128fccb163450','CAMC',NULL,NULL,'8975be1e209554aaf',NULL,'f3041c7f637e8df79','Account'),('7d111eb330fc394ce',0,NULL,'{}','Create',NULL,26,0,0,0,'2026-11-20 20:35:28','2026-11-20 20:35:28','9bbc99d1aaa7e1a4b','CPartService',NULL,NULL,'8975be1e209554aaf',NULL,'f3041c7f637e8df79','Account'),('7ed2a1a8571ecfcf1',0,NULL,'{\"assignedUserId\":\"8975be1e209554aaf\",\"assignedUserName\":\"Admin\"}','Assign',NULL,21,0,0,0,'2026-11-20 20:28:30','2026-11-20 20:28:30','064cbaa61185d2fb2','Lead',NULL,NULL,'8975be1e209554aaf',NULL,NULL,NULL),('8429c9b1d0355fdb0',0,NULL,'{\"fields\":[\"roles\"],\"attributes\":{\"was\":{\"rolesIds\":[],\"rolesNames\":{}},\"became\":{\"rolesIds\":[\"76786855438bb890a\"],\"rolesNames\":{\"76786855438bb890a\":\"Sales\"}}}}','Update',NULL,8,0,0,0,'2026-11-20 19:29:03','2026-11-20 19:29:03','3a9d2245f7f443cd5','User',NULL,NULL,'8975be1e209554aaf',NULL,NULL,NULL),('90ece7a5d36d33b7a',0,NULL,'{\"fields\":[],\"attributes\":{\"was\":{},\"became\":{}},\"value\":\"Converted\"}','Update',NULL,20,0,0,0,'2026-11-20 20:16:23','2026-11-20 20:16:23','064cbaa61185d2fb2','Lead',NULL,NULL,'8975be1e209554aaf',NULL,NULL,NULL),('9496bc208098d2636',0,NULL,'{\"fields\":[\"roles\"],\"attributes\":{\"was\":{\"rolesIds\":[],\"rolesNames\":{}},\"became\":{\"rolesIds\":[\"76786855438bb890a\"],\"rolesNames\":{\"76786855438bb890a\":\"Sales\"}}}}','Update',NULL,10,0,0,0,'2026-11-20 19:33:54','2026-11-20 19:33:54','d7b229038af2056a8','Team',NULL,NULL,'8975be1e209554aaf',NULL,NULL,NULL),('98cfb4d709be82f70',0,NULL,'{}','Create',NULL,24,0,0,0,'2026-11-20 20:35:27','2026-11-20 20:35:27','9b77a6adb5eeeeada','CJob',NULL,NULL,'8975be1e209554aaf',NULL,'f3041c7f637e8df79','Account'),('9dc95a706f8f2b13b',0,NULL,'{\"fields\":[\"userName\"],\"attributes\":{\"was\":{\"userName\":\"sales_1\"},\"became\":{\"userName\":\"sales1\"}}}','Update',NULL,6,0,0,0,'2026-11-20 19:18:03','2026-11-20 19:18:03','3a9d2245f7f443cd5','User',NULL,NULL,'8975be1e209554aaf',NULL,NULL,NULL),('cb8eea32c641d5f1e',0,NULL,'{}','Create',NULL,25,0,0,0,'2026-11-20 20:35:28','2026-11-20 20:35:28','bf551c7f371c4cc8e','CEstimation',NULL,NULL,'8975be1e209554aaf',NULL,'f3041c7f637e8df79','Account'),('cc6a7d50526e621fa',0,NULL,'{}','Create',NULL,28,0,0,0,'2026-11-20 20:35:29','2026-11-20 20:35:29','d393fc43249460ea6','CInvoice',NULL,NULL,'8975be1e209554aaf',NULL,'f3041c7f637e8df79','Account'),('cd47e7ba769064019',0,NULL,'{}','Create',NULL,13,0,0,0,'2026-11-20 19:51:08','2026-11-20 19:51:08','1beaa2ed6d39769fc','CJob',NULL,NULL,'8975be1e209554aaf',NULL,'fad196603b025835e','Account'),('d50ecd34071db948d',0,NULL,'{}','Create',NULL,4,0,0,0,'2026-11-20 12:54:30','2026-11-20 12:55:35','bee574c7672667f9a','CJob',NULL,NULL,'8975be1e209554aaf','8975be1e209554aaf','fad196603b025835e','Account'),('e70bffc10f0bc72c9',0,NULL,'{\"fields\":[],\"attributes\":{\"was\":{},\"became\":{}},\"value\":\"Proposal\"}','Update',NULL,15,0,0,0,'2026-11-20 20:10:31','2026-11-20 20:10:31','27b31c65ef0c038b5','Opportunity',NULL,NULL,'8975be1e209554aaf',NULL,NULL,NULL),('eab188c257bc6cc76',0,NULL,'{\"statusValue\":\"Prospecting\",\"statusField\":\"stage\"}','Create',NULL,19,0,0,0,'2026-11-20 20:16:23','2026-11-20 20:16:23','7c97eb7ee580bd504','Opportunity',NULL,NULL,'8975be1e209554aaf',NULL,'4a097347c0ebd6aff','Account'),('f8660c58bd7f6a2a3',0,NULL,'{}','Create',NULL,22,0,0,0,'2026-11-20 20:35:26','2026-11-20 20:35:26','f3041c7f637e8df79','Account',NULL,NULL,'8975be1e209554aaf',NULL,NULL,NULL),('fb211d9ee505b3ebd',0,NULL,'{}','Create',NULL,27,0,0,0,'2026-11-20 20:35:28','2026-11-20 20:35:28','6f8e92f43265d908e','CPartService',NULL,NULL,'8975be1e209554aaf',NULL,'f3041c7f637e8df79','Account');
/*!40000 ALTER TABLE `note` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `note_portal`
--

DROP TABLE IF EXISTS `note_portal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `note_portal` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `note_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `portal_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_NOTE_ID_PORTAL_ID` (`note_id`,`portal_id`),
  KEY `IDX_NOTE_ID` (`note_id`),
  KEY `IDX_PORTAL_ID` (`portal_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `note_portal`
--

LOCK TABLES `note_portal` WRITE;
/*!40000 ALTER TABLE `note_portal` DISABLE KEYS */;
/*!40000 ALTER TABLE `note_portal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `note_team`
--

DROP TABLE IF EXISTS `note_team`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `note_team` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `note_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `team_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_NOTE_ID_TEAM_ID` (`note_id`,`team_id`),
  KEY `IDX_NOTE_ID` (`note_id`),
  KEY `IDX_TEAM_ID` (`team_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `note_team`
--

LOCK TABLES `note_team` WRITE;
/*!40000 ALTER TABLE `note_team` DISABLE KEYS */;
INSERT INTO `note_team` VALUES (1,'3a97290105d860087','d7b229038af2056a8',0),(2,'cd47e7ba769064019','d7b229038af2056a8',0),(3,'446b6bfa0f4dd8fc6','d7b229038af2056a8',0),(4,'eab188c257bc6cc76','d7b229038af2056a8',0);
/*!40000 ALTER TABLE `note_team` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `note_user`
--

DROP TABLE IF EXISTS `note_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `note_user` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `note_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_NOTE_ID_USER_ID` (`note_id`,`user_id`),
  KEY `IDX_NOTE_ID` (`note_id`),
  KEY `IDX_USER_ID` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `note_user`
--

LOCK TABLES `note_user` WRITE;
/*!40000 ALTER TABLE `note_user` DISABLE KEYS */;
INSERT INTO `note_user` VALUES (1,'504a321afee4f251b','8975be1e209554aaf',0),(2,'d50ecd34071db948d','8975be1e209554aaf',0);
/*!40000 ALTER TABLE `note_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notification`
--

DROP TABLE IF EXISTS `notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notification` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint DEFAULT '0',
  `number` bigint unsigned NOT NULL AUTO_INCREMENT,
  `data` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `read` tinyint NOT NULL DEFAULT '0',
  `email_is_processed` tinyint NOT NULL DEFAULT '0',
  `created_at` datetime DEFAULT NULL,
  `message` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `action_id` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_featured` tinyint NOT NULL DEFAULT '0',
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `related_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `related_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `related_parent_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `related_parent_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_NUMBER` (`number`),
  KEY `IDX_CREATED_AT` (`created_at`),
  KEY `IDX_USER` (`user_id`,`number`),
  KEY `IDX_USER_ID_READ_RELATED_PARENT_TYPE` (`user_id`,`deleted`,`read`,`related_parent_type`),
  KEY `IDX_ACTION_ID` (`action_id`),
  KEY `IDX_USER_ID` (`user_id`),
  KEY `IDX_RELATED` (`related_id`,`related_type`),
  KEY `IDX_RELATED_PARENT` (`related_parent_id`,`related_parent_type`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification`
--

LOCK TABLES `notification` WRITE;
/*!40000 ALTER TABLE `notification` DISABLE KEYS */;
/*!40000 ALTER TABLE `notification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `o_auth_access_token`
--

DROP TABLE IF EXISTS `o_auth_access_token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `o_auth_access_token` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint DEFAULT '0',
  `hash` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(7) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Active',
  `expires_at` datetime DEFAULT NULL,
  `scopes` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `client_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_HASH` (`hash`),
  KEY `IDX_CREATED_AT` (`created_at`),
  KEY `IDX_EXPIRES_AT_STATUS` (`expires_at`,`status`),
  KEY `IDX_USER_ID` (`user_id`),
  KEY `IDX_CLIENT_ID` (`client_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `o_auth_access_token`
--

LOCK TABLES `o_auth_access_token` WRITE;
/*!40000 ALTER TABLE `o_auth_access_token` DISABLE KEYS */;
/*!40000 ALTER TABLE `o_auth_access_token` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `o_auth_account`
--

DROP TABLE IF EXISTS `o_auth_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `o_auth_account` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `access_token` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `refresh_token` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `expires_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `provider_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_PROVIDER_ID` (`provider_id`),
  KEY `IDX_USER_ID` (`user_id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `o_auth_account`
--

LOCK TABLES `o_auth_account` WRITE;
/*!40000 ALTER TABLE `o_auth_account` DISABLE KEYS */;
/*!40000 ALTER TABLE `o_auth_account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `o_auth_authorization_code`
--

DROP TABLE IF EXISTS `o_auth_authorization_code`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `o_auth_authorization_code` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint DEFAULT '0',
  `hash` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(7) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Active',
  `redirect_uri` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `expires_at` datetime DEFAULT NULL,
  `scopes` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `client_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_HASH` (`hash`),
  KEY `IDX_CREATED_AT` (`created_at`),
  KEY `IDX_EXPIRES_AT_STATUS` (`expires_at`,`status`),
  KEY `IDX_USER_ID` (`user_id`),
  KEY `IDX_CLIENT_ID` (`client_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `o_auth_authorization_code`
--

LOCK TABLES `o_auth_authorization_code` WRITE;
/*!40000 ALTER TABLE `o_auth_authorization_code` DISABLE KEYS */;
/*!40000 ALTER TABLE `o_auth_authorization_code` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `o_auth_client`
--

DROP TABLE IF EXISTS `o_auth_client`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `o_auth_client` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `status` varchar(8) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Active',
  `client_type` varchar(12) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Confidential',
  `identifier` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `redirect_uris` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `scopes` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_IDENTIFIER` (`identifier`),
  KEY `IDX_NAME` (`name`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `o_auth_client`
--

LOCK TABLES `o_auth_client` WRITE;
/*!40000 ALTER TABLE `o_auth_client` DISABLE KEYS */;
/*!40000 ALTER TABLE `o_auth_client` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `o_auth_client_secret`
--

DROP TABLE IF EXISTS `o_auth_client_secret`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `o_auth_client_secret` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `hash` tinytext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `status` varchar(7) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Active',
  `expiration_date` date DEFAULT NULL,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `client_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_STATUS_EXPIRATION_DATE` (`status`,`expiration_date`),
  KEY `IDX_CLIENT_ID_STATUS_CREATED_AT` (`client_id`,`status`,`created_at`),
  KEY `IDX_CLIENT_ID` (`client_id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `o_auth_client_secret`
--

LOCK TABLES `o_auth_client_secret` WRITE;
/*!40000 ALTER TABLE `o_auth_client_secret` DISABLE KEYS */;
/*!40000 ALTER TABLE `o_auth_client_secret` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `o_auth_provider`
--

DROP TABLE IF EXISTS `o_auth_provider`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `o_auth_provider` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `is_active` tinyint NOT NULL DEFAULT '1',
  `client_id` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `client_secret` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `authorization_endpoint` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `token_endpoint` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `authorization_prompt` varchar(14) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'none',
  `authorization_pkce` tinyint NOT NULL DEFAULT '0',
  `scopes` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `authorization_params` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `scope_separator` varchar(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `o_auth_provider`
--

LOCK TABLES `o_auth_provider` WRITE;
/*!40000 ALTER TABLE `o_auth_provider` DISABLE KEYS */;
/*!40000 ALTER TABLE `o_auth_provider` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `o_auth_refresh_token`
--

DROP TABLE IF EXISTS `o_auth_refresh_token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `o_auth_refresh_token` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint DEFAULT '0',
  `hash` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(7) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Active',
  `expires_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `client_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `access_token_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_HASH` (`hash`),
  KEY `IDX_CREATED_AT` (`created_at`),
  KEY `IDX_EXPIRES_AT_STATUS` (`expires_at`,`status`),
  KEY `IDX_USER_ID` (`user_id`),
  KEY `IDX_CLIENT_ID` (`client_id`),
  KEY `IDX_ACCESS_TOKEN_ID` (`access_token_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `o_auth_refresh_token`
--

LOCK TABLES `o_auth_refresh_token` WRITE;
/*!40000 ALTER TABLE `o_auth_refresh_token` DISABLE KEYS */;
/*!40000 ALTER TABLE `o_auth_refresh_token` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `opportunity`
--

DROP TABLE IF EXISTS `opportunity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `opportunity` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `amount` double DEFAULT NULL,
  `stage` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Prospecting',
  `last_stage` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `probability` int DEFAULT NULL,
  `lead_source` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `close_date` date DEFAULT NULL,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `amount_currency` varchar(3) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `stream_updated_at` datetime DEFAULT NULL,
  `account_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `campaign_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `assigned_user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `version_number` bigint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_CREATED_AT_ID` (`created_at`,`id`),
  KEY `IDX_STAGE` (`stage`,`deleted`),
  KEY `IDX_LAST_STAGE` (`last_stage`),
  KEY `IDX_ASSIGNED_USER` (`assigned_user_id`,`deleted`),
  KEY `IDX_CREATED_AT` (`created_at`,`deleted`),
  KEY `IDX_STAGE_CREATED_AT` (`stage`,`created_at`),
  KEY `IDX_ASSIGNED_USER_STAGE` (`assigned_user_id`,`stage`),
  KEY `IDX_ACCOUNT_ID` (`account_id`),
  KEY `IDX_CONTACT_ID` (`contact_id`),
  KEY `IDX_CAMPAIGN_ID` (`campaign_id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`),
  KEY `IDX_ASSIGNED_USER_ID` (`assigned_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `opportunity`
--

LOCK TABLES `opportunity` WRITE;
/*!40000 ALTER TABLE `opportunity` DISABLE KEYS */;
INSERT INTO `opportunity` VALUES ('27b31c65ef0c038b5','CineMall',0,55000,'Proposal','Proposal',50,NULL,'2026-12-30',NULL,'2026-11-20 20:09:58','2026-11-20 20:10:30','USD','2026-11-20 20:10:30',NULL,NULL,NULL,'8975be1e209554aaf','8975be1e209554aaf',NULL,2),('7c97eb7ee580bd504','CineMaxx',0,65000,'Prospecting','Prospecting',50,'Campaign','2026-12-31','Cinemax is the SuperMall','2026-11-20 20:16:23','2026-11-20 20:16:23','USD','2026-11-20 20:16:23','4a097347c0ebd6aff','8795e37e5d45d44a3',NULL,'8975be1e209554aaf',NULL,NULL,1);
/*!40000 ALTER TABLE `opportunity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_change_request`
--

DROP TABLE IF EXISTS `password_change_request`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_change_request` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint DEFAULT '0',
  `request_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_REQUEST_ID` (`request_id`),
  KEY `IDX_USER_ID` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_change_request`
--

LOCK TABLES `password_change_request` WRITE;
/*!40000 ALTER TABLE `password_change_request` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_change_request` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phone_number`
--

DROP TABLE IF EXISTS `phone_number`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `phone_number` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `numeric` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `invalid` tinyint NOT NULL DEFAULT '0',
  `opt_out` tinyint NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `IDX_NAME` (`name`),
  KEY `IDX_NUMERIC` (`numeric`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phone_number`
--

LOCK TABLES `phone_number` WRITE;
/*!40000 ALTER TABLE `phone_number` DISABLE KEYS */;
INSERT INTO `phone_number` VALUES ('177e08ab14964cd46','+919600267723',0,'Mobile','919600267723',0,0);
/*!40000 ALTER TABLE `phone_number` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pipeline`
--

DROP TABLE IF EXISTS `pipeline`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pipeline` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `order` int DEFAULT NULL,
  `status` varchar(8) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Active',
  `entity_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `field` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `color` int DEFAULT NULL,
  `is_available_for_all` tinyint NOT NULL DEFAULT '1',
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_ENTITY_TYPE_STATUS` (`entity_type`,`status`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pipeline`
--

LOCK TABLES `pipeline` WRITE;
/*!40000 ALTER TABLE `pipeline` DISABLE KEYS */;
/*!40000 ALTER TABLE `pipeline` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pipeline_stage`
--

DROP TABLE IF EXISTS `pipeline_stage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pipeline_stage` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `order` int DEFAULT NULL,
  `mapped_status` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `pipeline_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_PIPELINE_ID` (`pipeline_id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pipeline_stage`
--

LOCK TABLES `pipeline_stage` WRITE;
/*!40000 ALTER TABLE `pipeline_stage` DISABLE KEYS */;
/*!40000 ALTER TABLE `pipeline_stage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `portal`
--

DROP TABLE IF EXISTS `portal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `portal` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `custom_id` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint NOT NULL DEFAULT '1',
  `tab_list` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `quick_create_list` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `application_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `theme` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `theme_params` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `language` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `time_zone` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date_format` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `time_format` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `week_start` int DEFAULT '-1',
  `default_currency` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dashboard_layout` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `dashlets_options` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `custom_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `auth_token_lifetime` double DEFAULT NULL,
  `auth_token_max_idle_time` double DEFAULT NULL,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `modified_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `logo_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_logo_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `layout_set_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `authentication_provider_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_CUSTOM_ID` (`custom_id`),
  KEY `IDX_LAYOUT_SET_ID` (`layout_set_id`),
  KEY `IDX_AUTHENTICATION_PROVIDER_ID` (`authentication_provider_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `portal`
--

LOCK TABLES `portal` WRITE;
/*!40000 ALTER TABLE `portal` DISABLE KEYS */;
/*!40000 ALTER TABLE `portal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `portal_portal_role`
--

DROP TABLE IF EXISTS `portal_portal_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `portal_portal_role` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `portal_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `portal_role_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_PORTAL_ID_PORTAL_ROLE_ID` (`portal_id`,`portal_role_id`),
  KEY `IDX_PORTAL_ID` (`portal_id`),
  KEY `IDX_PORTAL_ROLE_ID` (`portal_role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `portal_portal_role`
--

LOCK TABLES `portal_portal_role` WRITE;
/*!40000 ALTER TABLE `portal_portal_role` DISABLE KEYS */;
/*!40000 ALTER TABLE `portal_portal_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `portal_role`
--

DROP TABLE IF EXISTS `portal_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `portal_role` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `data` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `field_data` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `export_permission` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'not-set',
  `mass_update_permission` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'not-set',
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `portal_role`
--

LOCK TABLES `portal_role` WRITE;
/*!40000 ALTER TABLE `portal_role` DISABLE KEYS */;
/*!40000 ALTER TABLE `portal_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `portal_role_user`
--

DROP TABLE IF EXISTS `portal_role_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `portal_role_user` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `portal_role_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_PORTAL_ROLE_ID_USER_ID` (`portal_role_id`,`user_id`),
  KEY `IDX_PORTAL_ROLE_ID` (`portal_role_id`),
  KEY `IDX_USER_ID` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `portal_role_user`
--

LOCK TABLES `portal_role_user` WRITE;
/*!40000 ALTER TABLE `portal_role_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `portal_role_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `portal_user`
--

DROP TABLE IF EXISTS `portal_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `portal_user` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `portal_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_PORTAL_ID_USER_ID` (`portal_id`,`user_id`),
  KEY `IDX_PORTAL_ID` (`portal_id`),
  KEY `IDX_USER_ID` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `portal_user`
--

LOCK TABLES `portal_user` WRITE;
/*!40000 ALTER TABLE `portal_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `portal_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `preferences`
--

DROP TABLE IF EXISTS `preferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `preferences` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `data` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `preferences`
--

LOCK TABLES `preferences` WRITE;
/*!40000 ALTER TABLE `preferences` DISABLE KEYS */;
INSERT INTO `preferences` VALUES ('3a9d2245f7f443cd5','{\n    \"id\": \"3a9d2245f7f443cd5\",\n    \"weekStart\": -1,\n    \"thousandSeparator\": \",\",\n    \"decimalMark\": \".\",\n    \"dashboardLayout\": [\n        {\n            \"name\": \"My Espo\",\n            \"layout\": [\n                {\n                    \"id\": \"d566253\",\n                    \"name\": \"CheckIn\",\n                    \"x\": 0,\n                    \"y\": 0,\n                    \"width\": 1.3333333333333333,\n                    \"height\": 1.75\n                },\n                {\n                    \"id\": \"d557461\",\n                    \"name\": \"Stream\",\n                    \"x\": 1.3333333333333333,\n                    \"y\": 0,\n                    \"width\": 1.3333333333333333,\n                    \"height\": 1.75\n                },\n                {\n                    \"id\": \"d235921\",\n                    \"name\": \"Activities\",\n                    \"x\": 2.6666666666666665,\n                    \"y\": 0,\n                    \"width\": 1.3333333333333333,\n                    \"height\": 1.75\n                },\n                {\n                    \"id\": \"d832061\",\n                    \"name\": \"Calendar\",\n                    \"x\": 0,\n                    \"y\": 1.75,\n                    \"width\": 4,\n                    \"height\": 2.25\n                }\n            ],\n            \"id\": \"9612022\"\n        }\n    ],\n    \"dashletsOptions\": {},\n    \"dashboardLocked\": true,\n    \"exportDelimiter\": \",\",\n    \"receiveAssignmentEmailNotifications\": true,\n    \"receiveMentionEmailNotifications\": true,\n    \"receiveStreamEmailNotifications\": true,\n    \"assignmentNotificationsIgnoreEntityTypeList\": [],\n    \"reactionNotifications\": true,\n    \"reactionNotificationsNotFollowed\": false,\n    \"notificationGrouping\": true,\n    \"notificationSound\": false,\n    \"defaultReminders\": [],\n    \"defaultRemindersTask\": [],\n    \"pageContentWidth\": null,\n    \"recordContentWidth\": null,\n    \"useCustomTabList\": false,\n    \"addCustomTabs\": false,\n    \"emailReplyToAllByDefault\": true,\n    \"emailReplyForceHtml\": true,\n    \"doNotFillAssignedUserIfNotRequired\": true,\n    \"followEntityOnStreamPost\": true,\n    \"followCreatedEntities\": false,\n    \"followCreatedEntityTypeList\": [],\n    \"followAsCollaborator\": true,\n    \"emailUseExternalClient\": false,\n    \"scopeColorsDisabled\": false,\n    \"tabColorsDisabled\": false,\n    \"textSearchStoringDisabled\": false,\n    \"calendarSlotDuration\": null,\n    \"calendarScrollHour\": null\n}'),('8975be1e209554aaf','{\n    \"id\": \"8975be1e209554aaf\",\n    \"timeZone\": null,\n    \"dateFormat\": null,\n    \"timeFormat\": null,\n    \"weekStart\": -1,\n    \"defaultCurrency\": null,\n    \"thousandSeparator\": \",\",\n    \"decimalMark\": \".\",\n    \"dashboardLayout\": [\n        {\n            \"name\": \"Home\",\n            \"layout\": [\n                {\n                    \"id\": \"d-checkin\",\n                    \"name\": \"CheckIn\",\n                    \"x\": 0,\n                    \"y\": 0,\n                    \"width\": 1,\n                    \"height\": 4\n                },\n                {\n                    \"id\": \"d-hours\",\n                    \"name\": \"Records\",\n                    \"x\": 1,\n                    \"y\": 0,\n                    \"width\": 2,\n                    \"height\": 4\n                },\n                {\n                    \"id\": \"d-mine\",\n                    \"name\": \"Records\",\n                    \"x\": 3,\n                    \"y\": 0,\n                    \"width\": 1,\n                    \"height\": 4\n                },\n                {\n                    \"id\": \"d-jobs\",\n                    \"name\": \"Records\",\n                    \"x\": 0,\n                    \"y\": 4,\n                    \"width\": 2,\n                    \"height\": 4\n                },\n                {\n                    \"id\": \"d-track\",\n                    \"name\": \"Records\",\n                    \"x\": 2,\n                    \"y\": 4,\n                    \"width\": 2,\n                    \"height\": 4\n                }\n            ]\n        }\n    ],\n    \"dashletsOptions\": {\n        \"d-checkin\": {\n            \"title\": \"Check In \\/ Out\"\n        },\n        \"d-jobs\": {\n            \"title\": \"Current Jobs\",\n            \"autorefreshInterval\": 0,\n            \"entityType\": \"CJob\",\n            \"displayRecords\": 8,\n            \"primaryFilter\": \"active\",\n            \"sortBy\": \"createdAt\",\n            \"boolFilterList\": [],\n            \"sortDirection\": \"desc\",\n            \"expandedLayout\": {\n                \"rows\": [\n                    [\n                        {\n                            \"name\": \"name\",\n                            \"link\": true,\n                            \"soft\": false,\n                            \"small\": false\n                        },\n                        {\n                            \"name\": \"assignedUser\",\n                            \"soft\": false,\n                            \"small\": false\n                        },\n                        {\n                            \"name\": \"priority\",\n                            \"soft\": false,\n                            \"small\": false\n                        }\n                    ],\n                    [\n                        {\n                            \"name\": \"status\",\n                            \"soft\": false,\n                            \"small\": false\n                        },\n                        {\n                            \"name\": \"account\",\n                            \"soft\": false,\n                            \"small\": false\n                        },\n                        {\n                            \"name\": \"dueDate\",\n                            \"soft\": false,\n                            \"small\": false\n                        }\n                    ]\n                ]\n            }\n        },\n        \"d-mine\": {\n            \"title\": \"Assigned to Me\",\n            \"entityType\": \"CWorkOrder\",\n            \"primaryFilter\": \"active\",\n            \"boolFilterList\": [\n                \"onlyMy\"\n            ],\n            \"displayRecords\": 8,\n            \"sortBy\": \"dateStart\",\n            \"sortDirection\": \"asc\",\n            \"expandedLayout\": {\n                \"rows\": [\n                    [\n                        {\n                            \"name\": \"name\",\n                            \"link\": true\n                        }\n                    ],\n                    [\n                        {\n                            \"name\": \"status\"\n                        },\n                        {\n                            \"name\": \"dateStart\"\n                        },\n                        {\n                            \"name\": \"account\"\n                        }\n                    ]\n                ]\n            }\n        },\n        \"d-track\": {\n            \"title\": \"Employee Tracking - Today\",\n            \"entityType\": \"CAttendance\",\n            \"primaryFilter\": \"today\",\n            \"displayRecords\": 15,\n            \"sortBy\": \"createdAt\",\n            \"sortDirection\": \"desc\",\n            \"autorefreshInterval\": 1,\n            \"expandedLayout\": {\n                \"rows\": [\n                    [\n                        {\n                            \"name\": \"employee\",\n                            \"link\": true\n                        }\n                    ],\n                    [\n                        {\n                            \"name\": \"status\"\n                        },\n                        {\n                            \"name\": \"checkIn\"\n                        },\n                        {\n                            \"name\": \"checkOut\"\n                        },\n                        {\n                            \"name\": \"checkInMap\"\n                        }\n                    ]\n                ]\n            }\n        },\n        \"d-hours\": {\n            \"title\": \"Daily Hours\",\n            \"entityType\": \"CDailyHours\",\n            \"displayRecords\": 10,\n            \"sortBy\": \"date\",\n            \"sortDirection\": \"desc\",\n            \"expandedLayout\": {\n                \"rows\": [\n                    [\n                        {\n                            \"name\": \"employee\",\n                            \"link\": true\n                        }\n                    ],\n                    [\n                        {\n                            \"name\": \"date\"\n                        },\n                        {\n                            \"name\": \"totalHours\"\n                        },\n                        {\n                            \"name\": \"sessionCount\"\n                        }\n                    ]\n                ]\n            }\n        }\n    },\n    \"dashboardLocked\": false,\n    \"language\": null,\n    \"exportDelimiter\": \",\",\n    \"receiveAssignmentEmailNotifications\": true,\n    \"receiveMentionEmailNotifications\": true,\n    \"receiveStreamEmailNotifications\": true,\n    \"assignmentNotificationsIgnoreEntityTypeList\": [],\n    \"reactionNotifications\": true,\n    \"reactionNotificationsNotFollowed\": false,\n    \"notificationGrouping\": true,\n    \"notificationSound\": false,\n    \"signature\": null,\n    \"defaultReminders\": [],\n    \"defaultRemindersTask\": [],\n    \"theme\": \"Light\",\n    \"themeParams\": {\n        \"navbar\": \"side\",\n        \"direction\": \"ltr\"\n    },\n    \"pageContentWidth\": null,\n    \"recordContentWidth\": null,\n    \"useCustomTabList\": false,\n    \"addCustomTabs\": false,\n    \"emailReplyToAllByDefault\": true,\n    \"emailReplyForceHtml\": true,\n    \"doNotFillAssignedUserIfNotRequired\": true,\n    \"followEntityOnStreamPost\": true,\n    \"followCreatedEntities\": false,\n    \"followCreatedEntityTypeList\": [],\n    \"followAsCollaborator\": true,\n    \"emailUseExternalClient\": false,\n    \"scopeColorsDisabled\": false,\n    \"tabColorsDisabled\": false,\n    \"textSearchStoringDisabled\": false,\n    \"calendarSlotDuration\": null,\n    \"calendarScrollHour\": null\n}');
/*!40000 ALTER TABLE `preferences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reminder`
--

DROP TABLE IF EXISTS `reminder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reminder` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint DEFAULT '0',
  `remind_at` datetime DEFAULT NULL,
  `start_at` datetime DEFAULT NULL,
  `type` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Popup',
  `seconds` int DEFAULT '0',
  `is_submitted` tinyint NOT NULL DEFAULT '0',
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `entity_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `entity_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_REMIND_AT` (`remind_at`),
  KEY `IDX_START_AT` (`start_at`),
  KEY `IDX_TYPE` (`type`),
  KEY `IDX_USER_ID` (`user_id`),
  KEY `IDX_ENTITY` (`entity_id`,`entity_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reminder`
--

LOCK TABLES `reminder` WRITE;
/*!40000 ALTER TABLE `reminder` DISABLE KEYS */;
/*!40000 ALTER TABLE `reminder` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role`
--

DROP TABLE IF EXISTS `role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `assignment_permission` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'not-set',
  `user_permission` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'not-set',
  `message_permission` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'not-set',
  `portal_permission` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'not-set',
  `group_email_account_permission` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'not-set',
  `export_permission` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'not-set',
  `mass_update_permission` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'not-set',
  `data_privacy_permission` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'not-set',
  `follower_management_permission` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'not-set',
  `audit_permission` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'not-set',
  `mention_permission` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'not-set',
  `user_calendar_permission` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'not-set',
  `lock_permission` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'not-set',
  `data` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `field_data` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role`
--

LOCK TABLES `role` WRITE;
/*!40000 ALTER TABLE `role` DISABLE KEYS */;
INSERT INTO `role` VALUES ('76786855438bb890a','Sales',0,'not-set','not-set','not-set','not-set','not-set','yes','not-set','not-set','not-set','not-set','all','not-set','not-set','{\"CAMC\":{\"create\":\"yes\",\"read\":\"all\",\"edit\":\"all\",\"delete\":\"own\",\"stream\":\"all\"},\"CAttendance\":{\"create\":\"yes\",\"read\":\"own\",\"edit\":\"no\",\"delete\":\"no\"},\"CDailyHours\":{\"create\":\"yes\",\"read\":\"own\",\"edit\":\"no\",\"delete\":\"no\"},\"CJob\":{\"create\":\"no\",\"read\":\"team\",\"edit\":\"team\",\"delete\":\"no\",\"stream\":\"team\"},\"CWorkOrder\":{\"create\":\"no\",\"read\":\"team\",\"edit\":\"team\",\"delete\":\"no\"}}','{\"Email\":{},\"Team\":{},\"User\":{},\"Account\":{},\"Call\":{},\"Campaign\":{},\"Case\":{},\"Contact\":{},\"DocumentFolder\":{},\"Document\":{},\"KnowledgeBaseArticle\":{},\"KnowledgeBaseCategory\":{},\"Lead\":{},\"Meeting\":{},\"Opportunity\":{},\"TargetListCategory\":{},\"TargetList\":{},\"Task\":{},\"CAMC\":{},\"CAttendance\":{},\"CDailyHours\":{},\"CJob\":{},\"CWorkOrder\":{}}','2026-11-20 19:27:44','2026-11-20 19:32:37');
/*!40000 ALTER TABLE `role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_team`
--

DROP TABLE IF EXISTS `role_team`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_team` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `role_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `team_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_ROLE_ID_TEAM_ID` (`role_id`,`team_id`),
  KEY `IDX_ROLE_ID` (`role_id`),
  KEY `IDX_TEAM_ID` (`team_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_team`
--

LOCK TABLES `role_team` WRITE;
/*!40000 ALTER TABLE `role_team` DISABLE KEYS */;
INSERT INTO `role_team` VALUES (1,'76786855438bb890a','d7b229038af2056a8',0);
/*!40000 ALTER TABLE `role_team` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_user`
--

DROP TABLE IF EXISTS `role_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_user` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `role_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_ROLE_ID_USER_ID` (`role_id`,`user_id`),
  KEY `IDX_ROLE_ID` (`role_id`),
  KEY `IDX_USER_ID` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_user`
--

LOCK TABLES `role_user` WRITE;
/*!40000 ALTER TABLE `role_user` DISABLE KEYS */;
INSERT INTO `role_user` VALUES (1,'76786855438bb890a','3a9d2245f7f443cd5',0);
/*!40000 ALTER TABLE `role_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `scheduled_job`
--

DROP TABLE IF EXISTS `scheduled_job`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `scheduled_job` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `job` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Active',
  `scheduling` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_run` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `is_internal` tinyint NOT NULL DEFAULT '0',
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `scheduled_job`
--

LOCK TABLES `scheduled_job` WRITE;
/*!40000 ALTER TABLE `scheduled_job` DISABLE KEYS */;
INSERT INTO `scheduled_job` VALUES ('0a6162d8e8a4f7693','Send Email Notifications',0,'SendEmailNotifications','Active','*/2 * * * *',NULL,'2026-11-20 11:11:51','2026-11-20 11:11:51',0,'system',NULL),('1a32d14adfeb0ff70','Process Webhook Queue',0,'ProcessWebhookQueue','Active','*/2 * * * *',NULL,'2026-11-20 11:11:51','2026-11-20 11:11:51',0,'system',NULL),('1eab1fd3f73bd26f8','Send Mass Emails',0,'ProcessMassEmail','Active','10,30,50 * * * *',NULL,'2026-11-20 11:11:51','2026-11-20 11:11:51',0,'system',NULL),('2ce72ee5840e8610c','Dummy',0,'Dummy','Active','1 */12 * * *',NULL,'2026-11-20 11:11:50','2026-11-20 11:11:50',1,NULL,NULL),('34cf71cf70ffb8f5b','Send Scheduled Emails',0,'SendScheduledEmails','Active','*/10 * * * *',NULL,'2026-11-20 11:11:51','2026-11-20 11:11:51',0,'system',NULL),('3aa321886c04b202f','Clean-up',0,'Cleanup','Active','1 1 * * 0',NULL,'2026-11-20 11:11:51','2026-11-20 11:11:51',0,'system',NULL),('54b5600a76a33cc1c','Process Job Queue q0',0,'ProcessJobQueueQ0','Active','* * * * *',NULL,'2026-11-20 11:11:49','2026-11-20 11:11:49',1,NULL,NULL),('5a681e82f288ea6c1','Check for New Versions of Installed Extensions',0,'CheckNewExtensionVersion','Active','25 5 * * *',NULL,'2026-11-20 11:11:50','2026-11-20 11:11:50',1,NULL,NULL),('5de3a430ce1afab69','OAuth Server Control',0,'OAuthServerControl','Active','3 0 * * *',NULL,'2026-11-20 11:11:50','2026-11-20 11:11:50',1,NULL,NULL),('60c43de1de3f391ab','Control Knowledge Base Article Status',0,'ControlKnowledgeBaseArticleStatus','Active','10 1 * * *',NULL,'2026-11-20 11:11:51','2026-11-20 11:11:51',0,'system',NULL),('6448a262813e03509','Process Job Queue q1',0,'ProcessJobQueueQ1','Active','*/1 * * * *',NULL,'2026-11-20 11:11:49','2026-11-20 11:11:49',1,NULL,NULL),('aca37ce1f739c6fd4','Send Email Reminders',0,'SendEmailReminders','Active','*/2 * * * *',NULL,'2026-11-20 11:11:51','2026-11-20 11:11:51',0,'system',NULL),('b7292e66d54e75727','Process Job Group',0,'ProcessJobGroup','Active','* * * * *',NULL,'2026-11-20 11:11:49','2026-11-20 11:11:49',1,NULL,NULL),('c1e806f3ee8dc901a','Submit Popup Reminders',0,'SubmitPopupReminders','Active','* * * * *',NULL,'2026-11-20 11:11:49','2026-11-20 11:11:49',1,NULL,NULL),('c404ff4fd439aa464','Check Personal Email Accounts',0,'CheckEmailAccounts','Active','*/1 * * * *',NULL,'2026-11-20 11:11:51','2026-11-20 11:11:51',0,'system',NULL),('d69385d2de7981ac0','Auth Token Control',0,'AuthTokenControl','Active','*/6 * * * *',NULL,'2026-11-20 11:11:51','2026-11-20 11:11:51',0,'system',NULL),('e4a68bb77872ab417','Process Job Queue e0',0,'ProcessJobQueueE0','Active','* * * * *',NULL,'2026-11-20 11:11:50','2026-11-20 11:11:50',1,NULL,NULL),('e7d0b81610aa104df','Check for New Version',0,'CheckNewVersion','Active','15 5 * * *',NULL,'2026-11-20 11:11:50','2026-11-20 11:11:50',1,NULL,NULL),('f5d4ba7e649b19eac','Sync Currency Rates',0,'SyncCurrencyRates','Active','2 0 * * *',NULL,'2026-11-20 11:11:50','2026-11-20 11:11:50',1,NULL,NULL),('f9cfabac945fbc8c7','Check Group Email Accounts',0,'CheckInboundEmails','Active','*/1 * * * *',NULL,'2026-11-20 11:11:51','2026-11-20 11:11:51',0,'system',NULL);
/*!40000 ALTER TABLE `scheduled_job` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `scheduled_job_log_record`
--

DROP TABLE IF EXISTS `scheduled_job_log_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `scheduled_job_log_record` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `execution_time` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `scheduled_job_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_SCHEDULED_JOB_ID_EXECUTION_TIME` (`scheduled_job_id`,`execution_time`),
  KEY `IDX_SCHEDULED_JOB_ID` (`scheduled_job_id`),
  KEY `IDX_TARGET` (`target_id`,`target_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `scheduled_job_log_record`
--

LOCK TABLES `scheduled_job_log_record` WRITE;
/*!40000 ALTER TABLE `scheduled_job_log_record` DISABLE KEYS */;
/*!40000 ALTER TABLE `scheduled_job_log_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sms`
--

DROP TABLE IF EXISTS `sms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sms` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint DEFAULT '0',
  `from_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `body` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Archived',
  `date_sent` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `from_phone_number_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `replied_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_DATE_SENT` (`date_sent`,`deleted`),
  KEY `IDX_DATE_SENT_STATUS` (`date_sent`,`status`,`deleted`),
  KEY `IDX_FROM_PHONE_NUMBER_ID` (`from_phone_number_id`),
  KEY `IDX_PARENT` (`parent_id`,`parent_type`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`),
  KEY `IDX_REPLIED_ID` (`replied_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sms`
--

LOCK TABLES `sms` WRITE;
/*!40000 ALTER TABLE `sms` DISABLE KEYS */;
/*!40000 ALTER TABLE `sms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sms_phone_number`
--

DROP TABLE IF EXISTS `sms_phone_number`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sms_phone_number` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `sms_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone_number_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_type` varchar(4) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_SMS_ID_PHONE_NUMBER_ID_ADDRESS_TYPE` (`sms_id`,`phone_number_id`,`address_type`),
  KEY `IDX_SMS_ID` (`sms_id`),
  KEY `IDX_PHONE_NUMBER_ID` (`phone_number_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sms_phone_number`
--

LOCK TABLES `sms_phone_number` WRITE;
/*!40000 ALTER TABLE `sms_phone_number` DISABLE KEYS */;
/*!40000 ALTER TABLE `sms_phone_number` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `star_subscription`
--

DROP TABLE IF EXISTS `star_subscription`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `star_subscription` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `deleted` tinyint DEFAULT '0',
  `created_at` datetime DEFAULT NULL,
  `entity_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `entity_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_USER_ENTITY` (`user_id`,`entity_id`,`entity_type`),
  KEY `IDX_USER_ENTITY_TYPE` (`user_id`,`entity_type`),
  KEY `IDX_ENTITY` (`entity_id`,`entity_type`),
  KEY `IDX_USER` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `star_subscription`
--

LOCK TABLES `star_subscription` WRITE;
/*!40000 ALTER TABLE `star_subscription` DISABLE KEYS */;
/*!40000 ALTER TABLE `star_subscription` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stream_subscription`
--

DROP TABLE IF EXISTS `stream_subscription`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stream_subscription` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `deleted` tinyint DEFAULT '0',
  `entity_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `entity_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_USER_ENTITY` (`user_id`,`entity_id`,`entity_type`),
  KEY `IDX_ENTITY` (`entity_id`,`entity_type`),
  KEY `IDX_USER` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stream_subscription`
--

LOCK TABLES `stream_subscription` WRITE;
/*!40000 ALTER TABLE `stream_subscription` DISABLE KEYS */;
INSERT INTO `stream_subscription` VALUES (1,0,'bee574c7672667f9a','CJob','8975be1e209554aaf'),(2,0,'26a23642611410415','CJob','3a9d2245f7f443cd5'),(3,0,'064cbaa61185d2fb2','Lead','8975be1e209554aaf');
/*!40000 ALTER TABLE `stream_subscription` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_data`
--

DROP TABLE IF EXISTS `system_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `system_data` (
  `id` varchar(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint DEFAULT '0',
  `last_password_recovery_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_data`
--

LOCK TABLES `system_data` WRITE;
/*!40000 ALTER TABLE `system_data` DISABLE KEYS */;
INSERT INTO `system_data` VALUES ('1',0,NULL);
/*!40000 ALTER TABLE `system_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_state`
--

DROP TABLE IF EXISTS `system_state`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `system_state` (
  `id` varchar(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `version_number` bigint DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_state`
--

LOCK TABLES `system_state` WRITE;
/*!40000 ALTER TABLE `system_state` DISABLE KEYS */;
INSERT INTO `system_state` VALUES ('1',3);
/*!40000 ALTER TABLE `system_state` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `target`
--

DROP TABLE IF EXISTS `target`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `target` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint DEFAULT '0',
  `salutation_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `first_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `last_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `title` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `account_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `website` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_street` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_city` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_state` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_country` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_postal_code` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `do_not_call` tinyint NOT NULL DEFAULT '0',
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `middle_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `assigned_user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_FIRST_NAME` (`first_name`,`deleted`),
  KEY `IDX_NAME` (`first_name`,`last_name`),
  KEY `IDX_ASSIGNED_USER` (`assigned_user_id`,`deleted`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`),
  KEY `IDX_ASSIGNED_USER_ID` (`assigned_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `target`
--

LOCK TABLES `target` WRITE;
/*!40000 ALTER TABLE `target` DISABLE KEYS */;
/*!40000 ALTER TABLE `target` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `target_list`
--

DROP TABLE IF EXISTS `target_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `target_list` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `category_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `assigned_user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_CREATED_AT` (`created_at`,`deleted`),
  KEY `IDX_CATEGORY_ID` (`category_id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`),
  KEY `IDX_ASSIGNED_USER_ID` (`assigned_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `target_list`
--

LOCK TABLES `target_list` WRITE;
/*!40000 ALTER TABLE `target_list` DISABLE KEYS */;
/*!40000 ALTER TABLE `target_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `target_list_category`
--

DROP TABLE IF EXISTS `target_list_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `target_list_category` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `order` int DEFAULT NULL,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`),
  KEY `IDX_PARENT_ID` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `target_list_category`
--

LOCK TABLES `target_list_category` WRITE;
/*!40000 ALTER TABLE `target_list_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `target_list_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `target_list_category_path`
--

DROP TABLE IF EXISTS `target_list_category_path`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `target_list_category_path` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ascendor_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `descendor_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_ASCENDOR_ID` (`ascendor_id`),
  KEY `IDX_DESCENDOR_ID` (`descendor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `target_list_category_path`
--

LOCK TABLES `target_list_category_path` WRITE;
/*!40000 ALTER TABLE `target_list_category_path` DISABLE KEYS */;
/*!40000 ALTER TABLE `target_list_category_path` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `target_list_user`
--

DROP TABLE IF EXISTS `target_list_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `target_list_user` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_list_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `opted_out` tinyint DEFAULT '0',
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_USER_ID_TARGET_LIST_ID` (`user_id`,`target_list_id`),
  KEY `IDX_USER_ID` (`user_id`),
  KEY `IDX_TARGET_LIST_ID` (`target_list_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `target_list_user`
--

LOCK TABLES `target_list_user` WRITE;
/*!40000 ALTER TABLE `target_list_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `target_list_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `task`
--

DROP TABLE IF EXISTS `task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `task` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Not Started',
  `priority` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Normal',
  `date_start` datetime DEFAULT NULL,
  `date_end` datetime DEFAULT NULL,
  `date_start_date` date DEFAULT NULL,
  `date_end_date` date DEFAULT NULL,
  `date_completed` datetime DEFAULT NULL,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `stream_updated_at` datetime DEFAULT NULL,
  `parent_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `account_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `assigned_user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `version_number` bigint DEFAULT '0',
  `email_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_DATE_START_STATUS` (`date_start`,`status`),
  KEY `IDX_DATE_END_STATUS` (`date_end`,`status`),
  KEY `IDX_DATE_START` (`date_start`,`deleted`),
  KEY `IDX_STATUS` (`status`,`deleted`),
  KEY `IDX_ASSIGNED_USER` (`assigned_user_id`,`deleted`),
  KEY `IDX_ASSIGNED_USER_STATUS` (`assigned_user_id`,`status`),
  KEY `IDX_PARENT` (`parent_id`,`parent_type`),
  KEY `IDX_ACCOUNT_ID` (`account_id`),
  KEY `IDX_CONTACT_ID` (`contact_id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`),
  KEY `IDX_ASSIGNED_USER_ID` (`assigned_user_id`),
  KEY `IDX_EMAIL_ID` (`email_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `task`
--

LOCK TABLES `task` WRITE;
/*!40000 ALTER TABLE `task` DISABLE KEYS */;
/*!40000 ALTER TABLE `task` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `team`
--

DROP TABLE IF EXISTS `team`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `team` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `position_list` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `layout_set_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `working_time_calendar_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_LAYOUT_SET_ID` (`layout_set_id`),
  KEY `IDX_WORKING_TIME_CALENDAR_ID` (`working_time_calendar_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `team`
--

LOCK TABLES `team` WRITE;
/*!40000 ALTER TABLE `team` DISABLE KEYS */;
INSERT INTO `team` VALUES ('d7b229038af2056a8','Sales Group A',0,'[\"Rank Pos\"]','General Shift','2026-11-20 19:07:49','2026-11-20 19:33:54','d66569f305a169ea6','0e7b49eaf73de54e3'),('ec10c8c9d8816d7ed','Sales Group B',0,'[\"BList\"]',NULL,'2026-11-20 19:09:02','2026-11-20 19:09:02','d66569f305a169ea6','0e7b49eaf73de54e3');
/*!40000 ALTER TABLE `team` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `team_user`
--

DROP TABLE IF EXISTS `team_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `team_user` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `team_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_TEAM_ID_USER_ID` (`team_id`,`user_id`),
  KEY `IDX_TEAM_ID` (`team_id`),
  KEY `IDX_USER_ID` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `team_user`
--

LOCK TABLES `team_user` WRITE;
/*!40000 ALTER TABLE `team_user` DISABLE KEYS */;
INSERT INTO `team_user` VALUES (1,'d7b229038af2056a8','3a9d2245f7f443cd5',NULL,0);
/*!40000 ALTER TABLE `team_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `template`
--

DROP TABLE IF EXISTS `template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `template` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `body` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `header` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `footer` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `entity_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(8) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Active',
  `left_margin` double DEFAULT '10',
  `right_margin` double DEFAULT '10',
  `top_margin` double DEFAULT '10',
  `bottom_margin` double DEFAULT '20',
  `print_footer` tinyint NOT NULL DEFAULT '0',
  `print_header` tinyint NOT NULL DEFAULT '0',
  `footer_position` double DEFAULT '10',
  `header_position` double DEFAULT '0',
  `style` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `page_orientation` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Portrait',
  `page_format` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'A4',
  `page_width` double DEFAULT NULL,
  `page_height` double DEFAULT NULL,
  `font_face` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `filename` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `version_number` bigint DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `template`
--

LOCK TABLES `template` WRITE;
/*!40000 ALTER TABLE `template` DISABLE KEYS */;
/*!40000 ALTER TABLE `template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `two_factor_code`
--

DROP TABLE IF EXISTS `two_factor_code`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `two_factor_code` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint DEFAULT '0',
  `code` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `method` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attempts_left` int DEFAULT NULL,
  `is_active` tinyint NOT NULL DEFAULT '1',
  `created_at` datetime DEFAULT NULL,
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_CREATED_AT` (`created_at`),
  KEY `IDX_USER_ID_METHOD` (`user_id`,`method`),
  KEY `IDX_USER_ID_METHOD_IS_ACTIVE` (`user_id`,`method`,`is_active`),
  KEY `IDX_USER_ID_METHOD_CREATED_AT` (`user_id`,`method`,`created_at`),
  KEY `IDX_USER_ID` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `two_factor_code`
--

LOCK TABLES `two_factor_code` WRITE;
/*!40000 ALTER TABLE `two_factor_code` DISABLE KEYS */;
/*!40000 ALTER TABLE `two_factor_code` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `unique_id`
--

DROP TABLE IF EXISTS `unique_id`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `unique_id` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `data` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL,
  `terminate_at` datetime DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_NAME` (`name`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_TARGET` (`target_id`,`target_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `unique_id`
--

LOCK TABLES `unique_id` WRITE;
/*!40000 ALTER TABLE `unique_id` DISABLE KEYS */;
/*!40000 ALTER TABLE `unique_id` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint DEFAULT '0',
  `user_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(24) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'regular',
  `password` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password_version` int NOT NULL DEFAULT '0',
  `auth_method` varchar(24) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `api_key` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `salutation_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `first_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint NOT NULL DEFAULT '1',
  `title` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `avatar_color` varchar(7) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gender` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `middle_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `delete_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `default_team_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `avatar_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dashboard_template_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `working_time_calendar_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `layout_set_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_USER_NAME_DELETE_ID` (`user_name`,`delete_id`),
  KEY `IDX_USER_NAME` (`user_name`),
  KEY `IDX_TYPE` (`type`),
  KEY `IDX_DEFAULT_TEAM_ID` (`default_team_id`),
  KEY `IDX_CONTACT_ID` (`contact_id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_DASHBOARD_TEMPLATE_ID` (`dashboard_template_id`),
  KEY `IDX_WORKING_TIME_CALENDAR_ID` (`working_time_calendar_id`),
  KEY `IDX_LAYOUT_SET_ID` (`layout_set_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES ('3a9d2245f7f443cd5',0,'sales1','regular','$2y$12$uSV54R/PPrPL1GCF2BVlAuve0z5GeL4gozGogzZSKizMUIXKPjwUm',2,NULL,NULL,'Mr.','Sales 1','User',1,NULL,NULL,NULL,'2026-11-20 19:10:11','2026-11-20 19:34:21',NULL,'0',NULL,NULL,NULL,'8975be1e209554aaf',NULL,'0e7b49eaf73de54e3','d66569f305a169ea6'),('8975be1e209554aaf',0,'admin','admin','$2y$12$k8/w44rE0vtR25loqukLJObxvFaiOQ41eBDowpNlUXsgT5WKYJiV.',1,NULL,NULL,NULL,NULL,'Admin',1,NULL,NULL,NULL,'2026-11-20 11:11:50','2026-11-20 11:11:50',NULL,'0',NULL,NULL,NULL,'system',NULL,NULL,NULL),('fc6e11cea4752c54f',0,'sales2','regular','$2y$12$PJ3sKzgGrLbfS.tMhWrvN.lFpk4qPUqFLEqiyXrJ8wxt/hcL3n0iO',2,NULL,NULL,'Mr.','Sales 2','User',1,NULL,NULL,NULL,'2026-11-20 19:17:51','2026-11-20 19:20:17',NULL,'0',NULL,NULL,NULL,'8975be1e209554aaf',NULL,NULL,NULL),('system',0,'system','system',NULL,0,NULL,NULL,NULL,NULL,'System',1,NULL,NULL,NULL,'2026-11-20 11:11:49','2026-11-20 11:11:49',NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_data`
--

DROP TABLE IF EXISTS `user_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_data` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint DEFAULT '0',
  `auth2_f_a` tinyint NOT NULL DEFAULT '0',
  `auth2_f_a_method` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `auth2_f_a_totp_secret` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `auth2_f_a_email_address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_USER_ID` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_data`
--

LOCK TABLES `user_data` WRITE;
/*!40000 ALTER TABLE `user_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_reaction`
--

DROP TABLE IF EXISTS `user_reaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_reaction` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_PARENT_USER_TYPE` (`parent_id`,`parent_type`,`user_id`,`type`),
  KEY `IDX_USER_ID` (`user_id`),
  KEY `IDX_PARENT` (`parent_id`,`parent_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_reaction`
--

LOCK TABLES `user_reaction` WRITE;
/*!40000 ALTER TABLE `user_reaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_reaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_state`
--

DROP TABLE IF EXISTS `user_state`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_state` (
  `id` int NOT NULL AUTO_INCREMENT,
  `email_filters_version_number` bigint DEFAULT '0',
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_USER_ID` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_state`
--

LOCK TABLES `user_state` WRITE;
/*!40000 ALTER TABLE `user_state` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_state` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_working_time_range`
--

DROP TABLE IF EXISTS `user_working_time_range`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_working_time_range` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `working_time_range_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_USER_ID_WORKING_TIME_RANGE_ID` (`user_id`,`working_time_range_id`),
  KEY `IDX_USER_ID` (`user_id`),
  KEY `IDX_WORKING_TIME_RANGE_ID` (`working_time_range_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_working_time_range`
--

LOCK TABLES `user_working_time_range` WRITE;
/*!40000 ALTER TABLE `user_working_time_range` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_working_time_range` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `webhook`
--

DROP TABLE IF EXISTS `webhook`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `webhook` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint DEFAULT '0',
  `event` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint NOT NULL DEFAULT '1',
  `entity_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `field` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `secret_key` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `skip_own` tinyint NOT NULL DEFAULT '0',
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_EVENT` (`event`),
  KEY `IDX_ENTITY_TYPE_TYPE` (`entity_type`,`type`),
  KEY `IDX_ENTITY_TYPE_FIELD` (`entity_type`,`field`),
  KEY `IDX_USER_ID` (`user_id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `webhook`
--

LOCK TABLES `webhook` WRITE;
/*!40000 ALTER TABLE `webhook` DISABLE KEYS */;
/*!40000 ALTER TABLE `webhook` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `webhook_event_queue_item`
--

DROP TABLE IF EXISTS `webhook_event_queue_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `webhook_event_queue_item` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint DEFAULT '0',
  `number` bigint unsigned NOT NULL AUTO_INCREMENT,
  `event` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL,
  `is_processed` tinyint NOT NULL DEFAULT '0',
  `target_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_NUMBER` (`number`),
  KEY `IDX_TARGET` (`target_id`,`target_type`),
  KEY `IDX_USER_ID` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `webhook_event_queue_item`
--

LOCK TABLES `webhook_event_queue_item` WRITE;
/*!40000 ALTER TABLE `webhook_event_queue_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `webhook_event_queue_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `webhook_queue_item`
--

DROP TABLE IF EXISTS `webhook_queue_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `webhook_queue_item` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint DEFAULT '0',
  `number` bigint unsigned NOT NULL AUTO_INCREMENT,
  `event` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL,
  `status` varchar(7) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Pending',
  `processed_at` datetime DEFAULT NULL,
  `attempts` int DEFAULT '0',
  `process_at` datetime DEFAULT NULL,
  `webhook_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_NUMBER` (`number`),
  KEY `IDX_WEBHOOK_ID` (`webhook_id`),
  KEY `IDX_TARGET` (`target_id`,`target_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `webhook_queue_item`
--

LOCK TABLES `webhook_queue_item` WRITE;
/*!40000 ALTER TABLE `webhook_queue_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `webhook_queue_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `working_time_calendar`
--

DROP TABLE IF EXISTS `working_time_calendar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `working_time_calendar` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `time_zone` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `time_ranges` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `weekday0` tinyint NOT NULL DEFAULT '0',
  `weekday1` tinyint NOT NULL DEFAULT '1',
  `weekday2` tinyint NOT NULL DEFAULT '1',
  `weekday3` tinyint NOT NULL DEFAULT '1',
  `weekday4` tinyint NOT NULL DEFAULT '1',
  `weekday5` tinyint NOT NULL DEFAULT '1',
  `weekday6` tinyint NOT NULL DEFAULT '0',
  `weekday0_time_ranges` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `weekday1_time_ranges` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `weekday2_time_ranges` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `weekday3_time_ranges` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `weekday4_time_ranges` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `weekday5_time_ranges` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `weekday6_time_ranges` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `working_time_calendar`
--

LOCK TABLES `working_time_calendar` WRITE;
/*!40000 ALTER TABLE `working_time_calendar` DISABLE KEYS */;
INSERT INTO `working_time_calendar` VALUES ('0e7b49eaf73de54e3','General Shift',0,'working time','Asia/Kolkata','[[\"09:00\",\"17:30\"]]',0,1,1,1,1,1,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-20 19:07:38','2026-11-20 19:07:38','8975be1e209554aaf',NULL);
/*!40000 ALTER TABLE `working_time_calendar` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `working_time_calendar_working_time_range`
--

DROP TABLE IF EXISTS `working_time_calendar_working_time_range`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `working_time_calendar_working_time_range` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `working_time_calendar_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `working_time_range_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_WORKING_TIME_CALENDAR_ID_WORKING_TIME_RANGE_ID` (`working_time_calendar_id`,`working_time_range_id`),
  KEY `IDX_WORKING_TIME_CALENDAR_ID` (`working_time_calendar_id`),
  KEY `IDX_WORKING_TIME_RANGE_ID` (`working_time_range_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `working_time_calendar_working_time_range`
--

LOCK TABLES `working_time_calendar_working_time_range` WRITE;
/*!40000 ALTER TABLE `working_time_calendar_working_time_range` DISABLE KEYS */;
/*!40000 ALTER TABLE `working_time_calendar_working_time_range` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `working_time_range`
--

DROP TABLE IF EXISTS `working_time_range`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `working_time_range` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `time_ranges` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `date_start` date DEFAULT NULL,
  `date_end` date DEFAULT NULL,
  `type` varchar(11) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Non-working',
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_TYPE_RANGE` (`type`,`date_start`,`date_end`),
  KEY `IDX_TYPE` (`type`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `working_time_range`
--

LOCK TABLES `working_time_range` WRITE;
/*!40000 ALTER TABLE `working_time_range` DISABLE KEYS */;
/*!40000 ALTER TABLE `working_time_range` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-20 20:41:15
