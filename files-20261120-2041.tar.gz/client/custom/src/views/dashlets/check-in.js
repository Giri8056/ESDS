define('custom:views/dashlets/check-in', ['views/dashlets/abstract/base'], function (Dep) {

    return Dep.extend({

        name: 'CheckIn',

        templateContent:
            '<div class="cc" style="padding:12px 14px">' +
            '<div class="cc-status" style="margin-bottom:10px;font-size:14px;color:#666">Loading...</div>' +
            '<button class="btn btn-primary btn-block" data-action="ccIn" style="margin-bottom:8px;padding:12px">Check in</button>' +
            '<button class="btn btn-danger btn-block" data-action="ccOut" style="padding:12px">Check out</button>' +
            '<div class="cc-msg small text-muted" style="margin-top:10px;min-height:18px"></div>' +
            '</div>',

        events: {
            'click [data-action="ccIn"]': function () { this.act('in'); },
            'click [data-action="ccOut"]': function () { this.act('out'); },
        },

        afterRender: function () {
            this.refreshStatus();
        },

        actionRefresh: function () {
            this.refreshStatus();
        },

        todayStr: function () {
            var d = new Date(), p = function (n) { return String(n).padStart(2, '0'); };
            return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate());
        },

        nowUtc: function () {
            return new Date().toISOString().slice(0, 19).replace('T', ' ');
        },

        msg: function (t) {
            this.$el.find('.cc-msg').text(t);
        },

        latest: function () {
            return Espo.Ajax.getRequest('CAttendance', {
                maxSize: 1, orderBy: 'createdAt', order: 'desc',
                where: [
                    {type: 'equals', attribute: 'employeeId', value: this.getUser().id},
                    {type: 'equals', attribute: 'date', value: this.todayStr()},
                ],
            }).then(function (r) { return r.list[0] || null; });
        },

        refreshStatus: function () {
            return this.latest().then(function (r) {
                var open = r && r.checkIn && !r.checkOut;
                var text = this.getUser().get('name') + ' - ' +
                    (r ? (r.checkOut ? 'Checked out (' + (r.hoursWorked || 0) + ' h)' : 'Checked in') : 'Not checked in today');
                this.$el.find('.cc-status').text(text);
                this.$el.find('[data-action="ccIn"]').prop('disabled', !!open);
                this.$el.find('[data-action="ccOut"]').prop('disabled', !open);
            }.bind(this));
        },

        position: function () {
            return new Promise(function (resolve) {
                if (!navigator.geolocation) { return resolve({}); }
                navigator.geolocation.getCurrentPosition(
                    function (p) { resolve({lat: p.coords.latitude, lng: p.coords.longitude}); },
                    function () { resolve({}); },
                    {timeout: 8000}
                );
            });
        },

        act: function (kind) {
            this.msg('Getting location...');
            this.$el.find('button').prop('disabled', true);

            this.position().then(function (g) {
                var now = this.nowUtc();

                if (kind === 'in') {
                    return Espo.Ajax.postRequest('CAttendance', {
                        name: this.getUser().get('name') + ' ' + this.todayStr(),
                        employeeId: this.getUser().id,
                        date: this.todayStr(),
                        checkIn: now,
                        status: 'Present',
                        checkInLat: g.lat,
                        checkInLng: g.lng,
                    }).then(function () { return g; });
                }

                return this.latest().then(function (r) {
                    return Espo.Ajax.putRequest('CAttendance/' + r.id, {
                        checkOut: now, checkOutLat: g.lat, checkOutLng: g.lng,
                    });
                }).then(function () { return g; });
            }.bind(this)).then(function (g) {
                this.msg((kind === 'in' ? 'Checked in' : 'Checked out') + (g.lat ? ' with location' : ' (no location)'));
                return this.refreshStatus();
            }.bind(this)).catch(function () {
                this.msg('Failed. Try again.');
                return this.refreshStatus();
            }.bind(this));
        },
    });
});
