Fieldy extension for EspoCRM 9+
Files:
  Fieldy-1.0.0.zip              the extension package (Administration > Extensions can upload this too)
  Fieldy-1.0.0.upload.txt       same zip as a data:application/zip;base64 string, used as the Postman upload body
  Fieldy.postman_collection.json  import into Postman; set baseUrl, username, password
Order: 1 Check connection, 2 Upload (binary body = the .upload.txt file), 3 Install.
