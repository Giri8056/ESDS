<?php

namespace Espo\Custom\Classes\Select\CWorkOrder\PrimaryFilters;

use Espo\Core\Select\Primary\Filter;
use Espo\ORM\Query\SelectBuilder;

class Active implements Filter
{
    public function apply(SelectBuilder $queryBuilder): void
    {
        $queryBuilder->where(['status' => ['New','Scheduled','En Route','In Progress','On Hold']]);
    }
}
