<?php

namespace Espo\Custom\Classes\Select\CJob\PrimaryFilters;

use Espo\Core\Select\Primary\Filter;
use Espo\ORM\Query\SelectBuilder;

class Active implements Filter
{
    public function apply(SelectBuilder $queryBuilder): void
    {
        $queryBuilder->where(['status' => ['Open','In Progress','On Hold']]);
    }
}
