<?php

namespace Espo\Custom\Classes\Select\CAttendance\PrimaryFilters;

use Espo\Core\Field\Date;
use Espo\Core\Select\Primary\Filter;
use Espo\ORM\Query\SelectBuilder;

class Today implements Filter
{
    public function apply(SelectBuilder $queryBuilder): void
    {
        $queryBuilder->where(['date' => Date::createToday()->toString()]);
    }
}
