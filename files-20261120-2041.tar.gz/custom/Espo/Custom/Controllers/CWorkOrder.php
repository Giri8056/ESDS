<?php

namespace Espo\Custom\Controllers;

class CWorkOrder extends \Espo\Core\Templates\Controllers\Event
{
}
