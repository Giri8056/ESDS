<?php

namespace Espo\Custom\Controllers;

class CAMC extends \Espo\Core\Templates\Controllers\BasePlus
{
}
