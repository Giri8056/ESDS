<?php

namespace Espo\Custom\Controllers;

class CDailyHours extends \Espo\Core\Templates\Controllers\Base
{
}
