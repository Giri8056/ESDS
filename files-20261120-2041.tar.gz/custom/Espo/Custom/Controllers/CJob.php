<?php

namespace Espo\Custom\Controllers;

class CJob extends \Espo\Core\Templates\Controllers\BasePlus
{
}
