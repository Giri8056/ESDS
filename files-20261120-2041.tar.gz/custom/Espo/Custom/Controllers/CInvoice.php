<?php

namespace Espo\Custom\Controllers;

class CInvoice extends \Espo\Core\Templates\Controllers\Base
{
}
