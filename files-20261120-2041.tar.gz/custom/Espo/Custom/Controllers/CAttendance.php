<?php

namespace Espo\Custom\Controllers;

class CAttendance extends \Espo\Core\Templates\Controllers\Base
{
}
