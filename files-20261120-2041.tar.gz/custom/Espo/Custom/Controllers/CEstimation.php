<?php

namespace Espo\Custom\Controllers;

class CEstimation extends \Espo\Core\Templates\Controllers\Base
{
}
