<?php

namespace Espo\Custom\Hooks\CAttendance;

use Espo\Core\Hook\Hook\AfterRemove;
use Espo\Core\Hook\Hook\AfterSave;
use Espo\ORM\Entity;
use Espo\ORM\EntityManager;
use Espo\ORM\Query\UpdateBuilder;
use Espo\ORM\Repository\Option\RemoveOptions;
use Espo\ORM\Repository\Option\SaveOptions;

/**
 * Rolls attendance sessions up into one CDailyHours record per employee per day.
 *
 * @implements AfterSave<Entity>
 * @implements AfterRemove<Entity>
 */
class DailyHoursRollup implements AfterSave, AfterRemove
{
    public static int $order = 20;

    public function __construct(private EntityManager $entityManager) {}

    public function afterSave(Entity $entity, SaveOptions $options): void
    {
        $this->rollup($entity->get('employeeId'), $entity->get('date'));

        $oldEmployee = $entity->getFetched('employeeId');
        $oldDate = $entity->getFetched('date');

        if (
            !$entity->isNew() &&
            ($oldEmployee !== $entity->get('employeeId') || $oldDate !== $entity->get('date'))
        ) {
            $this->rollup($oldEmployee, $oldDate);
        }
    }

    public function afterRemove(Entity $entity, RemoveOptions $options): void
    {
        $this->rollup($entity->get('employeeId'), $entity->get('date'));
    }

    private function rollup(?string $employeeId, ?string $date): void
    {
        if (!$employeeId || !$date) {
            return;
        }

        $sessions = $this->entityManager
            ->getRDBRepository('CAttendance')
            ->where(['employeeId' => $employeeId, 'date' => $date])
            ->find();

        $total = 0.0;
        $count = 0;
        $open = 0;
        $first = null;
        $last = null;
        $ids = [];

        foreach ($sessions as $s) {
            $count++;
            $ids[] = $s->get('id');
            $in = $s->get('checkIn');
            $out = $s->get('checkOut');

            if ($in && (!$first || $in < $first)) {
                $first = $in;
            }
            if ($out && (!$last || $out > $last)) {
                $last = $out;
            }
            if ($in && $out) {
                $total += max(0, (strtotime($out) - strtotime($in)) / 3600);
            } elseif ($in) {
                $open++;
            }
        }

        $repo = $this->entityManager->getRDBRepository('CDailyHours');
        $daily = $repo->where(['employeeId' => $employeeId, 'date' => $date])->findOne();

        if ($count === 0) {
            if ($daily) {
                $this->entityManager->removeEntity($daily);
            }
            return;
        }

        if (!$daily) {
            $daily = $this->entityManager->getNewEntity('CDailyHours');
            $daily->set(['employeeId' => $employeeId, 'date' => $date]);
        }

        $user = $this->entityManager->getEntityById('User', $employeeId);
        $daily->set([
            'name' => ($user ? $user->get('name') : $employeeId) . ' - ' . $date,
            'totalHours' => round($total, 2),
            'sessionCount' => $count,
            'openSessions' => $open,
            'firstCheckIn' => $first,
            'lastCheckOut' => $last,
        ]);
        $this->entityManager->saveEntity($daily);

        $update = UpdateBuilder::create()
            ->in('CAttendance')
            ->set(['dailyHoursId' => $daily->get('id')])
            ->where(['id' => $ids])
            ->build();
        $this->entityManager->getQueryExecutor()->execute($update);
    }
}
