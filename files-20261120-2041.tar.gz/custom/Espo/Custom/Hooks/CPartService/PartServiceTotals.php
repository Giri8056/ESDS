<?php

namespace Espo\Custom\Hooks\CPartService;

use Espo\Core\Hook\Hook\AfterRemove;
use Espo\Core\Hook\Hook\AfterSave;
use Espo\ORM\Entity;
use Espo\ORM\EntityManager;
use Espo\ORM\Repository\Option\RemoveOptions;
use Espo\ORM\Repository\Option\SaveOptions;

/**
 * Keeps Estimation and Invoice subtotals equal to the sum of their Parts & Service lines.
 * Saving the parent re-runs its formula, so tax, total and balance update too.
 *
 * @implements AfterSave<Entity>
 * @implements AfterRemove<Entity>
 */
class PartServiceTotals implements AfterSave, AfterRemove
{
    public static int $order = 20;

    public function __construct(private EntityManager $entityManager) {}

    public function afterSave(Entity $entity, SaveOptions $options): void
    {
        $this->sync($entity);
    }

    public function afterRemove(Entity $entity, RemoveOptions $options): void
    {
        $this->sync($entity);
    }

    private function sync(Entity $entity): void
    {
        foreach ([['estimation', 'CEstimation'], ['invoice', 'CInvoice']] as [$link, $type]) {
            $ids = array_unique(array_filter([
                $entity->get($link . 'Id'),
                $entity->isNew() ? null : $entity->getFetched($link . 'Id'),
            ]));

            foreach ($ids as $id) {
                $this->recalc($type, $link, $id);
            }
        }
    }

    private function recalc(string $type, string $link, string $id): void
    {
        $parent = $this->entityManager->getEntityById($type, $id);

        if (!$parent) {
            return;
        }

        $sum = 0.0;

        $lines = $this->entityManager
            ->getRDBRepository('CPartService')
            ->where([$link . 'Id' => $id])
            ->find();

        foreach ($lines as $line) {
            $sum += (float) $line->get('lineTotal');
        }

        $parent->set('subtotal', round($sum, 2));
        $this->entityManager->saveEntity($parent);
    }
}
